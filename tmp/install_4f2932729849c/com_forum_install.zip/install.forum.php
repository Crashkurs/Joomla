<?
function com_install(){
	print"<a href=\"index2.php?option=com_forum&task=install\">Click here to start phpBB install</a>";
} 



?>