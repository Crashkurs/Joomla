<?
function com_uninstall(){
	global $database;
	
	?>
	
	<script language="JavaScript1.2">
	<!--

	if( !confirm('Uninstalling this component will delete ALL phpBB tables and the content that`s in them.\nPress OK to continue') ){
	  history.go(-1);
	}
	//-->
	</script>
	
	<?
	
	$query = "DROP TABLE `phpbb_auth_access` ,
	`phpbb_banlist` ,
	`phpbb_categories` ,
	`phpbb_config` ,
	`phpbb_confirm` ,
	`phpbb_disallow` ,
	`phpbb_forum_prune` ,
	`phpbb_forums` ,
	`phpbb_groups` ,
	`phpbb_posts` ,
	`phpbb_posts_text` ,
	`phpbb_privmsgs` ,
	`phpbb_privmsgs_text` ,
	`phpbb_ranks` ,
	`phpbb_search_results` ,
	`phpbb_search_wordlist` ,
	`phpbb_search_wordmatch` ,
	`phpbb_sessions` ,
	`phpbb_smilies` ,
	`phpbb_themes` ,
	`phpbb_themes_name` ,
	`phpbb_topics` ,
	`phpbb_topics_watch` ,
	`phpbb_user_group` ,
	`mos_users` ,
	`phpbb_vote_desc` ,
	`phpbb_vote_results` ,
	`phpbb_vote_voters` ,
	`phpbb_words`,
	`phpbb_attachments_config`,
	`phpbb_forbidden_extensions`,
	`phpbb_extension_groups`,
	`phpbb_extensions`,
	`phpbb_attachments_desc`,
	`phpbb_attachments`,
	`phpbb_quota_limits`,
	`phpbb_attach_quota`, 
	`phpbb_flags`
	";
	$database->openConnectionNoReturn($query);
	
	$query = "ALTER TABLE `mos_users_backup` RENAME `mos_users`;";
	$database->openConnectionNoReturn($query);
	
	print"Successfully uninstalled";
}
?>