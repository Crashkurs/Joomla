<?php
set_time_limit(0);

if($_GET['task'] == "install"){
  print"<img src=\"" . $mosConfig_live_site . "/administrator/components/com_forum/logo_phpBB_v3.png\" align=\"right\">";
  print"<h1 class=\"sectionname\">phpBB :: Installation</h1>
  <div align=\"left\">";
  
  if(($_SERVER['REQUEST_METHOD'] == "POST") && ($_POST['submit'] == "Step 1")){
    //unzip files
    if(is_writable($mosConfig_absolute_path . "/components/")){
      if(is_writable($mosConfig_absolute_path . "/administrator/components/")){
    
        include("includes/installer_common.php");

      	$iswin = (substr(PHP_OS, 0, 3) == 'WIN' && stristr ( $_SERVER["SERVER_SOFTWARE"], "microsoft"));
      	
      	$zipfile = new PclZip($mosConfig_absolute_path . "/components/com_forum/com_forum.zip");
  			if($iswin) {
  				define('OS_WINDOWS',1);
  			} else {
  				define('OS_WINDOWS',0);
  			}
  
  			$ret = $zipfile->extract(PCLZIP_OPT_PATH,$mosConfig_absolute_path . "/components/");
  			if($ret == 0)
  			{
  				echo "Unrecoverable error '".$zipfile->errorName(true)."'","Unzip error";
  				return false;
  			}

      	if(file_exists($mosConfig_absolute_path . "/components/com_forum/includes/sql_parse.php")){
      	  unlink($mosConfig_absolute_path . "/components/com_forum/com_forum.zip");
      	    
      	  print'In this step you can set up your database. If you wish to create a new phpBB forum you will have to choose the "Create Database" option, this will insert all mambo users into phpBB.<br />
      	  If you wish to import users from an existing phpBB forum, please select the second button.<br /><br />';
          print"<form method=\"POST\">";
          print"<input type=\"hidden\" name=\"submit\" value=\"Step 2\">";
          print"<input type=\"submit\" name=\"tekst\" value=\"Step 2: Create database\" class=\"button\" onClick=\"if(!confirm('IF a phpBB database exists, it will be deleted. Continue?')){ return false;}\"><br />";
    
          print"<hr width=\"25%\"><br>";
          
          print"<input type=\"submit\" name=\"tekst\" value=\"Step 2: Import phpbb2.0.x posts and users\" class=\"button\">";
          print"</form>";
      	}
        
      }
      else{
        print"<font class=\"error\">" . $mosConfig_absolute_path . "/administrator/components/ is not writable</font>";
      }
    }
    else{
      print"<font class=\"error\">" . $mosConfig_absolute_path . "/components/ is not writable</font>";
    }
  }
  else if(($_SERVER['REQUEST_METHOD'] == "POST") && ($_POST['submit'] == "Step 2")){
    if(file_exists($mosConfig_absolute_path . "/components/com_forum/includes/sql_parse.php")){
	    require($mosConfig_absolute_path . "/components/com_forum/includes/sql_parse.php");
	  	
	    if($_POST['tekst'] == "Step 2: Create database"){
	      //create database
	      
		  	$sql_query = fread(fopen($mosConfig_absolute_path . "/administrator/components/com_forum/mysql_schema.sql", 'r'), @filesize($mosConfig_absolute_path . "/administrator/components/com_forum/mysql_schema.sql"));
		  	$sql_query = preg_replace('/phpbb_/', 'phpbb_', $sql_query);
		  	
		  	$sql_query = remove_remarks($sql_query);
		  	$sql_query = split_sql_file($sql_query, ";");
		  	
		  	for($i = 0; $i < sizeof($sql_query); $i++){
		  		if (trim($sql_query[$i]) != ''){
		  			$database->setQuery( $sql_query[$i] );
		  			if (!($result = $database->query())){
		  				echo $database->stderr(true);
		  				exit;
		  			}
		  		}
		  	}
		  	
		  	//insert other data
		  	// Ok tables have been built, let's fill in the basic information
		  	$sql_query = fread(fopen($mosConfig_absolute_path . "/administrator/components/com_forum/mysql_basic.sql", 'r'), @filesize($mosConfig_absolute_path . "/administrator/components/com_forum/mysql_basic.sql"));
		  	$sql_query = preg_replace('/phpbb_/', 'phpbb_', $sql_query);
		  	
		  	$sql_query = remove_remarks($sql_query);
		  	$sql_query = split_sql_file($sql_query, ";");
		  	
		  	for($i = 0; $i < sizeof($sql_query); $i++){
		  		if (trim($sql_query[$i]) != ''){
		  			$database->setQuery( $sql_query[$i] );
		  			if (!($result = $database->query())){
		  				echo $database->stderr(true);
		  				exit;
		  			}
		  		}
		  	}
		  	
  	    //insert old users into phpbb
  	  	
  	  	$query = "SELECT * FROM mos_users_backup ORDER BY id";
  	  	$database->setQuery($query);
	  		if (!$database->query()) {
    			echo $database->getErrorMsg()."<br />";
    		}
  	  	$result = $database->_cursor;
  	  	
  	  	$i=1;
  	  	//print $query;
  	  	while($row = mysql_fetch_array($result)){
  	  		
  	  		if($row['usertype'] == "superadministrator"){
  	  			$userlevel = 1;
  	  			$adminemail = $row['email'];
  	  		}
  	  		else {
  	  			$userlevel = 0;
  	  		}
  	  
  	  		$sql = "INSERT INTO mos_users (
  	  		id, 
  	  		user_active, 
  	  		username, 
  	  		password, 
  	  		name, 
  	  		usertype, 
  	  		block, 
  	  		sendEmail, 
  	  		gid, 
  	  		registerdate, 
  	  		user_lastvisit, 
  	  		user_regdate, 
  	  		user_level, 
  	  		user_posts, 
  	  		user_viewemail, 
  	  		user_attachsig, 
  	  		user_allowhtml, 
  	  		user_allow_viewonline, 
  	  		user_notify, 
  	  		user_notify_pm, 
  	  		user_popup_pm, 
  	  		email
  	  		) VALUES (
  	  		'" . $row['id'] . "', 
  	  		1, 
  	  		'" . $row['username'] . "', 
  	  		'" . $row['password'] . "', 
  	  		'" . $row['name'] . "', 
  	  		'" . $row['usertype'] . "', 
  	  		0, 
  	  		" . $row['sendEmail'] . ", 
  	  		" . $row['gid'] . ", 
  	  		'" . $row['registerDate'] . "', 
  	  		0, 
  	  		" . strtotime($row['registerDate']) . ", 
  	  		'" . $userlevel . "', 
  	  		0, 
  	  		0, 
  	  		1, 
  	  		0, 
  	  		1, 
  	  		0, 
  	  		1, 
  	  		1, 
  	  		'" . $row['email'] . "'
  	  		);";
  	  		
//  	  		echo $sql . "<br>";
  	  		
  	  		$database->setQuery($sql);
  	  		if (!$database->query()) {
      			echo $database->getErrorMsg()."<br />";
      		}
  	  
  	  		$sql = "INSERT INTO phpbb_groups (group_name, group_description, group_single_user, group_moderator) VALUES ('', 'Personal User', 1, 0)";
  	  		$database->setQuery($sql);
  	  		if (!$database->query()) {
      			echo $database->getErrorMsg()."<br />";
      		}
//  	  		echo $sql . "<br>";
  	  		
  	  		$group_id = mysql_insert_id();
  	  		
  	  		$sql = "INSERT INTO phpbb_user_group (user_id, group_id, user_pending) VALUES (" . $row['id'] . ", " . $group_id . ", 0)";
  	  		$database->setQuery($sql);
  	  		if (!$database->query()) {
      			echo $database->getErrorMsg()."<br />";
      		}
//  	  		echo $sql . "<br>";
  	  		
  	  		$sql = "UPDATE mos_core_acl_aro SET value = '" . $row['id'] . "' WHERE name = '" . $row['name'] . "'";
  	  		$database->setQuery($sql);
  	  		if (!$database->query()) {
      			echo $database->getErrorMsg()."<br />";
      		}
//  	  		echo $sql . "<br>";
  	  		
  	  		$sql = "UPDATE mos_users_backup SET id = " . $row['id'] . " WHERE username = '" . $row['username'] . "'";
  	  		$database->setQuery($sql);
  	  		if (!$database->query()) {
      			echo $database->getErrorMsg()."<br />";
      		}
//  	  		echo $sql . "<br>";
  	  		
  	  		echo "User <b>" . $row['name'] . "</b> inserted in usertable and added to usersgroup " . $row['usertype'] . "<br>";
  	  		
//  	  		echo "-------------------------<br>";
  	  		
  	  		$i++;
  	  	}
  	  	
  	  	
  	  	//changing configuration
  	  	$query = "UPDATE phpbb_config SET config_value = '" . $mosConfig_sitename . "' WHERE config_name = 'sitename'";
  	  	$database->openConnectionNoReturn($query);
  	  	$query = "UPDATE phpbb_config SET config_value = '" . $adminemail . "' WHERE config_name = 'board_email'";
  	  	$database->openConnectionNoReturn($query);

  	  	
	    }
	    else{
	      
	    }
  	  	
	  	print"<hr width=\"25%\"><br>";
	  	print"<form method=\"POST\">";
	    print"<input type=\"hidden\" name=\"submit\" value=\"Step 3\">";
	    print"Do you want phpBB to run as mambo component?: <input type=\"checkbox\" name=\"runascomponent\" value=\"true\" checked><br>";
	    print"<input type=\"submit\" name=\"tekst\" value=\"Create configuration\" class=\"button\">";
	    print"</form>";
    }
    else{
    	print"<font class=\"error\">Archive extraction failed... cannot continue installation</font>";
    }
  } 
  else if(($_SERVER['REQUEST_METHOD'] == "POST") && ($_POST['submit'] == "Step 3")){
    //create config
    $config_data = '<?php'."\n\n";
  	$config_data .= "\n// phpBB 2.x auto-generated config file\n// Do not change anything in this file!\n\n";
  	$config_data .= '$dbms = \'mysql\';' . "\n\n";
  	$config_data .= '$dbhost = \'' . $mosConfig_host . '\';' . "\n";
  	$config_data .= '$dbname = \''. $mosConfig_db . '\';' . "\n";
  	$config_data .= '$dbuser = \''. $mosConfig_user . '\';' . "\n";
  	$config_data .= '$dbpasswd = \''. $mosConfig_password . '\';' . "\n\n";
  	$config_data .= '$table_prefix = \'phpbb_\';' . "\n\n";
  	
  	$config_data .= '$php_install_path = "' . $mosConfig_absolute_path . '/components/com_forum/";'."\n\n";
  	$config_data .= '$php_install_url = "' . $mosConfig_live_site . '/components/com_forum/";'."\n\n";
  
  	$config_data .= '$mambo_install_path = "' . $mosConfig_absolute_path . '/";'."\n";
  	$config_data .= '$mambo_install_url = "' . $mosConfig_live_site . '/";'."\n\n";
  	
  	$value = ($_POST['runascomponent'] == "true") ? "true" : "false";
  	
  	$config_data .= '$run_as_component = ' . $value . ';'."\n\n";
  	
  	$config_data .= 'define(\'PHPBB_INSTALLED\', true);'."\n\n";	
  	$config_data .= '?' . '>'; // Done this to prevent highlighting editors getting confused!
  	
  	$fp = fopen($mosConfig_absolute_path . "/components/com_forum/" . "config.php", 'w');
  	$result = fputs($fp, $config_data, strlen($config_data));
  	fclose($fp);
    
  	//delete install option from the menu...
  	
  	$query = "DELETE FROM #__components WHERE name = 'Install phpBB for mambo'";
  	$database->setQuery($query);
  	$database->query();
  
    print"Installation successfull";
    print"<script languag=\"JavaScript\">alert('Don`t forget to adjust the phpBB configuration!!!');</script>";
  }
  else{
    print'With this wizard you are going to set up your phpBB forum. Press the button below to extract the zip archive that contains all forum files. You\'ll need the ZLib library for this.';

    print"<form method=\"POST\">";
    print"<input type=\"hidden\" name=\"submit\" value=\"Step 1\">";
    print"<input type=\"submit\" name=\"tekst\" value=\"Step 1: Unpack needed forum files\" class=\"button\">";
    print"</form><br><br>";
  }
  print"</div>";
}
else if($_GET['task'] == "import"){
  print"You can only successfully import users if you didn't install a new phpBB database.<br>";
  print"This functionality will import all users from phpBB and place them in the combined table, and the MOS backup table<br>";
  print"<b>Proceding this will delete all users from mambo and give phpBB site administrators Mambo Superadministrator rights</b><br><br>";
  
  print"<b>Make sure you've run the upgrade scripts that came with the component to convert your phpbb database into the component version.</b><br><br>";
  
  print'<a href="index2.php?option=com_forum&task=import&confirm=1">Click here to continue</a><br /><br />';
  
  if($_GET['confirm'] == 1){
    $query = "DELETE FROM mos_users";
    $database->setQuery($query);
		if (!$database->query()) {
			echo $database->getErrorMsg()."<br />";
		}
    $query = "DELETE FROM mos_core_acl_aro"; 
    $database->setQuery($query);
		if (!$database->query()) {
			echo $database->getErrorMsg()."<br />";
		}
    $query = "DELETE FROM mos_core_acl_groups_aro_map";
    $database->setQuery($query);
		if (!$database->query()) {
			echo $database->getErrorMsg()."<br />";
		}
    $query = "DELETE FROM mos_users_backup";
    $database->setQuery($query);
		if (!$database->query()) {
			echo $database->getErrorMsg()."<br />";
		}
    
    $query = "SELECT * FROM phpbb_users ORDER BY user_id";
  	$database->setQuery($query);
		if (!$database->query()) {
			echo $database->getErrorMsg()."<br />";
		}
  	$result = $database->_cursor;
    
  	while($row = mysql_fetch_array($result)){
  		//echo $row['username'] . "<Br>";		
  		
  		if($row['user_level'] == 1){
  			$usertype = "superadministrator";
  			$gid = 25;
  		}
  		else{
  			$usertype = "users";
  			$gid = 18;
  		}
  		if($row['user_emailtime'] == ""){
  			$emailtime = "NULL";
  		}
  		else{
  			$emailtime = $row['user_emailtime'];
  		}
  		if($row['user_newpasswd'] == ""){
  			$newpasswd = "NULL";
  		}
  		else{
  			$newpasswd = $row['user_newpasswd'];
  		}
  		if($row['user_style'] == ""){
  			$style = "NULL";
  		}
  		else{
  			$style = $row['user_style'];
  		}
  		
  	  $sql = "INSERT INTO mos_users (
  	  id, 
  	  user_active, 
  	  username, 
  	  password, 
  	  name, 
  		usertype, 
  	  block, 
  	  sendEmail, 
  	  gid, 
  	  registerDate, 
  	  user_session_time, 
  	  user_session_page, 
  		user_lastvisit, 
  	  user_regdate, 
  	  user_level, 
  	  user_posts, 
  	  user_timezone, 
  		user_style, 
  	  user_lang, 
  	  user_dateformat, 
  	  user_new_privmsg, 
  	  user_unread_privmsg, 
  		user_last_privmsg, 
  	  user_emailtime, 
  	  user_viewemail, 
  	  user_attachsig, 
  	  user_allowhtml, 
  		user_allowbbcode, 
  	  user_allowsmile, 
  	  user_allowavatar, 
  	  user_allow_pm, 
  	  user_allow_viewonline, 
  		user_notify, 
  	  user_notify_pm, 
  	  user_popup_pm, 
  	  user_rank, 
  	  user_avatar, 
  	  user_avatar_type, 
  		email, 
  	  user_icq, 
  	  user_website, 
  	  user_from, 
  	  user_sig, 
      user_sig_bbcode_uid, 
  	  user_aim, 
  		user_yim, 
  	  user_msnm, 
  	  user_occ, 
  	  user_interests, 
  	  user_actkey, 
  	  user_newpasswd
  	  ) VALUES (
  	  '" . $row['user_id'] . "', 
  	  " . $row['user_active'] . ", 
  	  '" . addslashes($row['username']) . "', 
  	  '" . $row['user_password'] . "', 
  	  '" . addslashes($row['username']) . "', 
  		'" . $usertype . "', 
  	  0, 
  	  1, 
  	  " . $gid . ", 
  	  NOW(), 
  	  " . $row['user_session_time'] . ", 
  	  " . $row['user_session_page'] . ", 
      " . $row['user_lastvisit'] . ", 
  	  " . $row['user_regdate'] . ", 
  	  " . $row['user_level'] . ", 
  	  " . $row['user_posts'] . ", 
  	  '" . $row['user_timezone'] . "', 
      " . $style . ", 'english', 
      '" . $row['user_dateformat'] . "', 
  	  " . $row['user_new_privmsg'] . ", 
  	  " . $row['user_unread_privmsg'] . ", 
      " . $row['user_last_privmsg'] . ", 
  	  " . $emailtime . ", 
  	  '" . $row['user_viewemail'] . "', 
  	  '" . $row['user_attachsig'] . "', 
  	  '" . $row['user_allowhtml'] . "', 
      '" . $row['user_allowbbcode'] . "', 
  	  '" . $row['user_allowsmile'] . "', 
  	  '" . $row['user_allowavatar'] . "', 
  	  '" . $row['user_allow_pm'] . "', 
  	  '" . $row['user_allow_viewonline'] . "', 
      '" . $row['user_notify'] . "', 
  	  '" . $row['user_notify_pm'] . "', 
  	  '" . $row['user_popup_pm'] . "', 
  	  '" . $row['user_level'] . "', 
  	  '" . $row['user_avatar'] . "', 
  	  '" . $row['user_avatar_type'] . "', 
      '" . $row['user_email'] . "', 
  	  '" . $row['user_icq'] . "', 
  	  '" . $row['user_website'] . "', 
  	  '" . addslashes($row['user_from']) . "', 
  	  '" . addslashes($row['user_sig']) . "', 
      '" . addslashes($row['user_sig_bbcode_uid']) . "', 
  	  '" . addslashes($row['user_aim']) . "', 
      '" . addslashes($row['user_yim']) . "', 
  	  '" . addslashes($row['user_msnm']) . "', 
  	  '" . addslashes($row['user_occ']) . "', 
  	  '" . addslashes($row['user_interests']) . "', 
  	  '" . $row['user_actkey'] . "', 
      '" . $newpasswd . "'
  	  );";
  
  	  $database->setQuery($sql);
  		if (!$database->query()) {
  			echo $database->_errorMsg."<br />";
  		}
  	  
  	  $sql = "INSERT INTO mos_users_backup (id, email, username, password, name, 
  		  		usertype, block, sendEmail, gid,  registerDate) VALUES 
  		  		('" . $row['user_id'] . "', '" . $row['user_email'] . "', '" . addslashes($row['username']) . "', '" . $row['user_password'] . "', '" . addslashes($row['username']) . "', 
  		  		'', 0, 1, " . $gid . ", NOW())";
  	  $database->setQuery($sql);
  		if (!$database->query()) {
  			echo $database->_errorMsg."<br />";
  		}
  	  
  	  $sql = "INSERT INTO mos_core_acl_aro VALUES('', '" . $usertype . "', " . $row['user_id']. ", 0, '" . addslashes($row['username']) . "', 0)";
  		$database->setQuery($sql);
  		if (!$database->query()) {
  			echo $database->_errorMsg."<br />";
  		}
  		
  		$sql = "INSERT INTO mos_core_acl_groups_aro_map VALUES(" . $gid . ", '', " . mysql_insert_id() . ")";
  		$database->setQuery($sql);
  		if (!$database->query()) {
  			echo $database->_errorMsg."<br />";
  		}
  	  
  	  print "<b>" . $row['username'] . "</b> added to mambo and added to usersgroup " . $usertype . "<br>";
  	}
	} 
}
else {
  print"<div align=\"right\"><a href=\"http://www.phpbb.com\" target=\"_blank\"><img src=\"" . $mosConfig_live_site . "/administrator/components/com_forum/logo_phpBB_v3.png\" border=\"0\"></a></div>";
  ?>
  <font color="red">!!</font> To access the admin panel, you will need to be logged in at the forum <font color="red">!!</font><br><br>
  <?  
  print"<a href=\"" . $mosConfig_live_site . "/components/com_forum/admin/\" target=\"_blank\">Click here to open phpBB admin section</a>";
  
}

////////////////////////////////////////////////////////
/// cp function/////////////////////////////////
////////////////////////////////////////////////////////

function cp($wf, $wto){        // it moves $wf to $wto
	umask(0);
  if(!is_dir($wto)){    
		mkdir($wto,0777);
	}
	
	$arr=ls_a($wf);
	foreach ($arr as $fn){
		if($fn){
		  $fl="$wf/$fn";
		  $flto="$wto/$fn";
			if(is_dir($fl)){
				cp($fl,$flto);
			}
			else {
				copy($fl,$flto);
			}
			umask(0);
			chmod($flto, 0775);
		}
	}
}

///////////////////////////////////////////////////
/// ls_a function////////////////////////
// This function lists a directory.
// ANd is needed for the cp function.

function ls_a($wh){    
  if ($handle = opendir($wh)) {
    while (false !== ($file = readdir($handle))) { 
    	if ($file != "." && $file != ".." ) { 
				if(!$files) $files="$file";
				else $files="$file\n$files"; 
      } 
    }
    closedir($handle); 
  }
  $arr=explode("\n",$files);
  return $arr;
} 
?>