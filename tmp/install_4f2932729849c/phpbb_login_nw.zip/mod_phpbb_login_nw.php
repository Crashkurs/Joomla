<?php
//phpBB Login//
// $Id: mod_phpbb_login.php,v 1.0 2003/09/16 08:02:54 avandongen Exp $
//
// Copyright (C) 2000-2003 Miro International Pty Ltd
// All rights reserved.
//
// This source file is part of the Mambo Open Source Content
// Management System.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
// The "GNU General Public License" (GPL) is available at
// http://www.gnu.org/copyleft/gpl.html.

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
$registration_enabled = $mainframe->getCfg( 'allowUserRegistration' );

$keys = array_keys($_GET);
$values = array_values($_GET);

$redirect = "index.php?";
  	
for ($i=0; $i<count($keys); $i++){
	$redirect .= "" . $keys[$i]."=".$values[$i]."&";
}

if ($my->id) {
	echo _HI; ?><?php echo $my->username;
	?>
	<br />
<a href="<? echo $mosConfig_live_site; ?>/components/com_forum/forum.php?page=login&logout=true&redirect=../../index.php"><?php echo _BUTTON_LOGOUT; ?></a>

<?php
	} else {
	?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
	<tr>
		<td>
		  <form method="POST" action="<? echo $mosConfig_live_site; ?>/components/com_forum/forum.php?page=login">
      <?php echo _USERNAME; ?><br /><input type="text" name="username" class="inputbox" size="10" /> <br />
		  <?php echo _PASSWORD; ?><br /><input type="password" name="password" class="inputbox" size="10" /><br />
		  <input type="checkbox" name="autologin"><?php echo _REMEMBER_ME; ?>
		  
		  <input type="hidden" name="redirect" value="../../<?= $redirect?>" />
		  
		  <input type="submit" name="login" class="button" value="<?php echo _BUTTON_LOGIN; ?>" />
      </form>
      </td>
		</td>
	</tr>
	<tr>
		<td><a href="<? echo $mosConfig_live_site; ?>/components/com_forum/forum.php?page=profile&mode=sendpassword"><?php echo _LOST_PASSWORD ; ?></a>?</td>
	</tr>
<?
	if ($registration_enabled) {
?>
	<tr>
		<td><?php echo _NO_ACCOUNT; ?> <a href="<?php echo $mosConfig_live_site; ?>/components/com_forum/forum.php?page=profile&mode=register"><?php echo _CREATE_ACCOUNT;?></a></td>
	</tr>
<?php
	}
?>
</table>
<?php
}
?>