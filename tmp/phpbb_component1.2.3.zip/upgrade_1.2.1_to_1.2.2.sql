# --------------------------------------------------------
#
# Update version for phpbb
#
UPDATE `phpbb_config` SET `config_value` = '.0.8' WHERE `config_name` = 'version' LIMIT 1;