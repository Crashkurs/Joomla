# --------------------------------------------------------
#
# Update version for phpbb
#
UPDATE `phpbb_config` SET `config_value` = '.0.7' WHERE `config_name` = 'version' LIMIT 1;