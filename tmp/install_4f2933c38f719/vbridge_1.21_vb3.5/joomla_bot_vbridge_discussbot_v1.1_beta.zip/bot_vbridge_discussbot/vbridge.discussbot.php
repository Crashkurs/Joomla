<?php
/**
* Joomla! vBridge - A vBulletin bridge
* @version 1.1
* @package Joomla! vBridge
* @copyright (C) 2005 by Marko Schmuck aka Predator & Reggie Suplido - All rights reserved!
* @license Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @Inspired by the SimpleBoard mosbot by Jick - jick@jigsnet.com
* @AdaptedBy TSMF - http://tsmf.jigsnet.com
* @Adapted for SMF by Theodore Hildebrandt
* @Adapted for vBulletin Bridge by Marko Schmuck aka Predator & Reggie Suplido
**/
defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');

$_MAMBOTS->registerFunction('onPrepareContent', 'MOSBOT_add_vbforumlink');

function MOSBOT_add_vbforumlink(& $published, & $row) {
    global $database, $mosConfig_lang, $mosConfig_absolute_path;

    $database->setQuery("SELECT params FROM #__mambots WHERE element='vbridge.discussbot' AND folder = 'content'");
    $paramlist = $database->loadResult();
    $params = mosParseParams($paramlist);
    if ($params->use_vbridge == 1 && $params->use_vbridge != ''){
        $vb_config = null;
        $database->setQuery("SELECT * FROM #__vbridge_config WHERE id='1'");
        $database->loadObject($vb_config);
        if (file_exists($mosConfig_absolute_path.'/administrator/components/com_vbridge/language/'.$mosConfig_lang.'.php')) {
            include_once($mosConfig_absolute_path.'/administrator/components/com_vbridge/language/'.$mosConfig_lang.'.php');
        } else {
            include_once($mosConfig_absolute_path.'/administrator/components/com_vbridge/language/english.php');
        }
        $mosLang = new JoomlaVBRIDGELanguage();
    } else {
        if ($params->default_discuss == '') {
            die ('Please go to vBulletin discuss bot and click save to initialize parameters.');
        }
        
        $vb_config ='';
        $mosLang = new JoomlaVBRIDGEBot();
    }
    if (!$published) {
        $row->fulltext = str_replace( "{mos_vbridge_discuss:.+?}", "", $row->fulltext );
        return;
    }
    if (strpos($row->fulltext, "{mos_vbridge_discuss}")) {
          $row->text = str_replace("{mos_vbridge_discuss}", "{mos_vbridge_discuss:$params->default_discuss}", $row->text);
    }
    if (strpos($row->text, "{mos_vbridge_discuss}")) {
          $row->text = str_replace("{mos_vbridge_discuss}", "{mos_vbridge_discuss:$params->default_discuss}", $row->text);
    }    
    if (strpos($row->fulltext, "{mos_vbridge_discuss}") > 0 && $params->default_discuss == '') {
          $row->fulltext = str_replace("{mos_vbridge_discuss}", "{mos_vbridge_discuss:0}", $row->text);
          return;
    }
    if (strpos($row->fulltext, "{mos_vbridge_discuss}")) {
          $row->fulltext = str_replace("{mos_vbridge_discuss}", "{mos_vbridge_discuss:$params->default_discuss}", $row->text);
    } else {
    if (strpos($row->text, "{mos_vbridge_discuss}") > 0 && $params->default_discuss == '') {
          $row->text = str_replace("{mos_vbridge_discuss}", "{mos_vbridge_discuss:0}", $row->text);
          return;
    }
    
    }    
    if ($_REQUEST['option'] == 'com_frontpage') {
    
        
        $mos_vbridge_discuss_entrytext2 = $row->fulltext;
        $mos_vbridge_discuss_matches2 = array ();
        if (preg_match_all("/{mos_vbridge_discuss:.+?}/", $mos_vbridge_discuss_entrytext2, $mos_vbridge_discuss_matches2, PREG_PATTERN_ORDER) > 0) {
            foreach ($mos_vbridge_discuss_matches2[0] as $mos_vbridge_discuss_match2) {
                $showbottext = "";
                $mos_vbridge_discuss_match2 = str_replace("{mos_vbridge_discuss:", "", $mos_vbridge_discuss_match2);
                $mos_vbridge_discuss_match2 = str_replace("}", "", $mos_vbridge_discuss_match2);

                if ($mos_vbridge_discuss_match2 == "no_discuss") {
                    $showbottext = "";
                } else {
                    $showbottext = make_vbforumlink($mos_vbridge_discuss_match2, $row, $vb_config, $params, $mosLang);
                }
            }
            $row->text = $row->text.$showbottext;
        }

    }
   
    $mos_vbridge_discuss_entrytext = $row->text;
    $mos_vbridge_discuss_matches = array ();
    if (preg_match_all("/{mos_vbridge_discuss:.+?}/", $mos_vbridge_discuss_entrytext, $mos_vbridge_discuss_matches, PREG_PATTERN_ORDER) > 0) {
        foreach ($mos_vbridge_discuss_matches[0] as $mos_vbridge_discuss_match) {
            $showbottext = "";
            $mos_vbridge_discuss_match = str_replace("{mos_vbridge_discuss:", "", $mos_vbridge_discuss_match);
            $mos_vbridge_discuss_match = str_replace("}", "", $mos_vbridge_discuss_match);
            if ($mos_vbridge_discuss_match == "no_discuss") {
                $showbottext = "";
            } else {
                $showbottext = make_vbforumlink($mos_vbridge_discuss_match, $row, $vb_config, $params, $mosLang);
            }
            $mos_vbridge_discuss_entrytext = str_replace("{mos_vbridge_discuss:".$mos_vbridge_discuss_match."}", $showbottext, $mos_vbridge_discuss_entrytext);
        }
        $row->text = $mos_vbridge_discuss_entrytext;
    }
}

function make_vbforumlink($catid, $row, $vb_config, $params, $mosLang) {
    global $database, $my, $mosConfig_absolute_path, $mosConfig_live_site;
    global $mosConfig_sef;

    // Check for Editor rights
    $is_editor = (strtolower($my->usertype) == 'editor' || strtolower($my->usertype) == 'publisher' || strtolower($my->usertype) == 'manager' || strtolower($my->usertype) == 'administrator' || strtolower($my->usertype) == 'super administrator' );
    $is_user   = (strtolower($my->usertype) <> '');

    // Check if the subject as content title exists in the messages table
    $title = str_replace("'", "`", $row->title);
    $title = $params->title_prefix.$title;
    $threadid = $row->vb_threadid;
	
    $curtime = time();
    $REMOTE_ADDR=$_SERVER['REMOTE_ADDR'];  
    // Is there already a topic for this?  If not, make a new topic
    if ($threadid == 0) {
        $message = '[QUOTE]'.substr($row->text, 0, $params->num_chars).'...'.'[/QUOTE]';
        
        $search = array ("/\</", "/\>/", "/\\\"/", "/\[\/d.../","/\[br\/]/","/\[br \/]/","/\[div([^\]]*)\]{1}/", "/\[\/div\]/","/\[p([^\]]*)\]{1}/", "/\[\/p\]/", "/\[font([^\]]*)\]{1}/", "/\[\/font\]/", "/\[img.*src\=http/", "/\[img.*src\=/", "/jpg([^\]]*)\]{1}/", "/gif([^\]]*)\]{1}/", "/png([^\]]*)\]{1}/", "/jpeg([^\]]*)\]{1}/", "/\[a.+?(href=\"?http){1}/", "/\[a.+?(href=\"?){1}/", "/target\=([^\]]*)\]{1}/", "/\[\/a\]/", "/\[table([^\]]*)\]{1}/", "/\[tbody\]/", "/\[\/tbody\]/", "/\[td([^\]]*)\]{1}/", "/\[strike\]/", "/\[em\]/","/\[\/em\]/", "/\[b\]/","/\[\/b\]/", "/\[ol\]/", "/\[ul\]/", "/{mos_vbridge_discuss:.+?}/");
        if ($params->quote_images == "1") {
            $replace = array ("[", "]", "", "","","","", "","", "", "", "", "[IMG]http", "[IMG]".$mosConfig_live_site."/", "jpg[/IMG]", "gif[/IMG]", "png[/IMG]", "jpeg[/IMG]", "[URL=http", "[URL=".$mosConfig_live_site."/", "]", "[/URL]", "[table]", "", "", "[td]", "[s]", "[I]","[/I]","[B]","[/B]","[list]", "[list]", "");
        } else {
            $replace = array ("[", "]", "", "","","", "","", "","", "", "", "", "", "", "", "", "", "[URL=http", "[URL=".$mosConfig_live_site."/", "]", "[/URL]", "[table]", "", "", "[td]", "[S]", "[I]", "[B]", "[list]", "[list]", "");
        }
        $message = preg_replace($search, $replace, $message);
        $message = str_replace("'", "`", $message);
        $message = $message."[URL=".$mosConfig_live_site."/index.php?option=com_content&task=view&id=".$row->id."][B]Read the full article.[/B][/URL]";
         

        if ($params->use_vbridge == 1 && $params->use_vbridge != ''){
            $database->setQuery("SELECT id FROM #__menu WHERE link='index.php?option=com_vbridge' AND published='1'");
            $itemid = $database->loadResult();
            $scripturl = basename($_SERVER['PHP_SELF'])."?option=com_vbridge&Itemid=".$itemid;
        } else {
            if ($params->vbpath == '') {
                die ('Please go to vBulletin discuss bot and click save to initialize parameters.');
            }
        }
        if ($params->use_database == 1 ) {
        	
        	$database2 = new database( $params->db_host,$params->db_user,$params->db_passwd, $params->db_dbname, $params->db_prefix );
            $database2->setQuery("INSERT INTO {$params->db_prefix}thread SET title = '$title', lastpost='$curtime', forumid='$catid',open='1',postusername='$params->vbusername',postuserid='$params->vbuserid',lastposter='$params->vbusername',dateline='$curtime',visible='1'");
			if (!$database2->query()) {
				$error = $database2->stderr();
	    	 	echo "<script> alert('Database error 1: " . $error."'); window.history.go(-1); </script>\n";
			    exit();
			}
			$threadid = $database2->insertid();           
		    $database2->setQuery("INSERT INTO {$params->db_prefix}post SET threadid='$threadid',parentid='0',username='$params->vbusername',userid='$params->vbuserid',title='$title',dateline='$curtime',pagetext='$message',allowsmilie='1',showsignature='0',ipaddress='$REMOTE_ADDR',iconid='1',visible='1',attach='0'");
			if (!$database->query()) {
      	    	$error = $database2->stderr();
				echo "<script> alert('Database error 2: " . $error."'); window.history.go(-1); </script>\n";
				exit();
			}
			$postid = $database2->insertid(); 
			$database2->setQuery("UPDATE {$params->db_prefix}thread SET firstpostid='$postid' WHERE threadid='$threadid'");
			if (!$database2->query()) {
				$error = $database2->stderr();
				echo "<script> alert('Database error 3: " . $error."'); window.history.go(-1); </script>\n";
				exit();
			}
			$database2->setQuery("UPDATE {$params->db_prefix}forum SET threadcount=threadcount+1 WHERE forumid='$catid'");
			if (!$database2->query()) {
				$error = $database2->stderr();
				echo "<script> alert('Database error: " . $error."'); window.history.go(-1); </script>\n";
			    exit();
			}
		 	$database->setQuery("UPDATE #__content SET vb_threadid='$threadid' WHERE id='$row->id'");
			if (!$database->query()) {
				echo "<script> alert('Database error: " . $database->stderr()."'); window.history.go(-1); </script>\n";
	    		exit();
			}					
                
        } else {
			$database->setQuery("INSERT INTO {$params->db_prefix}thread SET title='$title',lastpost='$curtime',forumid='$catid',open='1',postusername='$params->vbusername',postuserid='$params->vbuserid',lastposter='$params->vbusername',dateline='$curtime',visible='1'");
        	if ( !$database->query() ) {
				echo "<script> alert('Database error: " . $database->stderr()."'); window.history.go(-1); </script>\n";
				exit();
			}				
			$threadid = $database->insertid();
			$database->setQuery("INSERT INTO {$params->db_prefix}post SET threadid='$threadid',username='$params->vbusername',userid='$params->vbuserid',title='$title',dateline='$curtime',pagetext='$message',allowsmilie='1',showsignature='0',ipaddress='$REMOTE_ADDR',iconid='1',visible='1',attach='0'");
			if ( !$database->query() ) {
				echo "<script> alert('Database error: " . $database->stderr()."'); window.history.go(-1); </script>\n";
				exit();
			}				
			$database->setQuery("UPDATE {$params->db_prefix}forum SET threadcount=threadcount+1 WHERE forumid='$catid' LIMIT 1");
			if ( !$database->query() ) {
				echo "<script> alert('Database error: " . $database->stderr()."'); window.history.go(-1); </script>\n";
				exit();
			}				
        	$database->setQuery("UPDATE #__content SET vb_threadid='$threadid' WHERE id='$row->id'");
			if ( !$database->query() ) {
				echo "<script> alert('Database error: " . $database->stderr()."'); window.history.go(-1); </script>\n";
				exit();
			}	
        }			
    }

    else 
    {
        if ($params->use_database == 1 ) { 
        	$database2 = new database( $params->db_host,$params->db_user,$params->db_passwd, $params->db_dbname, $params->db_prefix );
   			$database2->setQuery("SELECT *"."\nFROM {$params->db_prefix}post"."\nWHERE threadid = '".$threadid."'"."\nORDER BY postid;");
            $replies = $database2->loadObjectList();
            if ($database2->loadResult()) {
                $showreply = '';
            }
        } else {
            $database->setQuery("SELECT *"."\nFROM {$params->db_prefix}post"."\nWHERE threadid = '".$threadid."'"."\nORDER BY postid;");
            $replies = $database->loadObjectList();
            if ($database->loadResult()) {
                $showreply = '';
            }
        }
        for ($i = 0, $n = count($replies); $i < $n; $i ++) {
            $reply = & $replies[$i];
            $post = $i +1;
                       
            $pagetext = str_replace("[QUOTE]","", $reply->pagetext); 
            $pagetext = str_replace("[/QUOTE]","", $pagetext); 
            $pagetext = str_replace("[/div]","</div>", $pagetext); 
            $pagetext = str_replace("[div","<div", $pagetext); 
            $pagetext = str_replace("[URL=","<a href=", $pagetext);
            $pagetext = str_replace("[/URL]","</a>", $pagetext); 
            $pagetext = str_replace("[br /]","<br />", $pagetext);
            $pagetext = str_replace("[br/]","<br />", $pagetext);
            $pagetext = str_replace("[IMG]","<img src=", $pagetext); 
            $pagetext = str_replace("[/IMG]","></img>", $pagetext);
            $pagetext = str_replace("[I]","<em>", $pagetext); 
            $pagetext = str_replace("[/I]","</em>", $pagetext); 
            $pagetext = str_replace("[B]","<b>", $pagetext); 
            $pagetext = str_replace("[/B]","</b>", $pagetext); 
            $pagetext = str_replace("[/d...","",$pagetext);
            $pagetext = str_replace("]",">", $pagetext); 
              
            $icon = null;
            
        if ($params->use_database == 1 ) { 
       		$database2 = new database( $params->db_host,$params->db_user,$params->db_passwd, $params->db_dbname, $params->db_prefix );
   	        $database2->setQuery("SELECT * FROM {$params->db_prefix}icon WHERE iconid = '".$threadid."';");
            $database2->loadObject($icon);
   	        if (!$database2->loadResult()) {
                $iconlink = $params->vbpath.'/images/icons/icon1.gif';
                $icontitle = "None";
            } else {    
            	$iconlink = $params->vbpath.'/'.$icon->iconpath;
            	$icontitle = $icon->title;
            }
            
            $user = null;
            $database2->setQuery("SELECT * FROM {$params->db_prefix}user WHERE userid = '".$reply->userid."';");
            $database2->loadObject($user);          
        } else {
            $database->setQuery("SELECT * FROM {$params->db_prefix}icon WHERE iconid = '".$threadid."';");
            $database->loadObject($icon);
            if (!$database->loadResult()) {
                $iconlink = $params->vbpath.'/images/icons/icon1.gif';
            	$icontitle = "None";
            } else {
                $iconlink = $params->vbpath.'/'.$icon->iconpath;
                $icontitle = $icon->title;
        	}
            $user = null;
            $database->setQuery("SELECT * FROM {$params->db_prefix}user WHERE userid = '".$reply->userid."';");
            $database->loadObject($user);
        }
            if ($user->userid == $my->id) {
                $status = 'user_online.gif';
                $stat_name = 'online';
            } else {
                $status = 'user_offline.gif';
                $stat_name = 'offline';
            }
            if ($params->use_vbridge == 1 && $params->use_vbridge != ''){
            	$database = new database( $mosConfig_host, $mosConfig_user, $mosConfig_password, $mosConfig_db, $mosConfig_dbprefix );
	    	    $database->setQuery("SELECT id FROM #__menu WHERE link='index.php?option=com_vbridge' AND published='1'");
                $itemid = $database->loadResult();
                $scripturl = basename($_SERVER['PHP_SELF'])."?option=com_vbridge&Itemid=".$itemid;
                $showpostnew = $vb_config->vb_url.'/images/statusicon/post_new.gif';
                $userlink = sefRelToAbs($scripturl . '&file=member.php&amp;u='.$user->userid);
                $showpostcount = sefRelToAbs($scripturl . '&file=showpost.php&amp;p='.$reply->postid.'&amp;postcount='.$post);
                $statuslink = $vb_config->vb_url.'/images/statusicon/';
                $replylink = sefRelToAbs($scripturl . '&file=newreply.php&amp;do=newreply&amp;noquote=1&amp;p='.$reply->postid) ;
                $quotelink = sefRelToAbs($scripturl . '&file=newreply.php&amp;do=newreply&amp;p='.$reply->postid) ;
                $buttonlink = $vb_config->vb_url.'/images/buttons/';


            }else{
                if ($params->vbpath == '') {
                    die ('Please go to vBulletin discuss bot and click save to initialize parameters.');
                }
                $showpostnew = $params->vbpath.'/images/statusicon/post_new.gif';
                $userlink = $params->vbpath.'/member.php?u='.$user->userid;
                $showpostcount = $params->vbpath.'/showpost.php?p='.$reply->postid.'&amp;postcount='.$post;
                $iconlink = $params->vbpath.'/images/icons/icon1.gif';
                $statuslink = $params->vbpath.'/images/statusicon/';
                $replylink = $params->vbpath. '/newreply.php?do=newreply&amp;noquote=1&amp;p='.$reply->postid ;
                $quotelink = $params->vbpath.'/newreply.php?do=newreply&amp;p='.$reply->postid;
                $buttonlink = $params->vbpath.'/images/buttons/';
            }

            $showreply .= '<div align="center">
                <div style="width:100%; text-align:left">
				<div style="padding:0px 5px 0px 5px">
				<div style="padding:0px 0px 3px 0px">
				<table class="vbborder" cellpadding="3" cellspacing="0" border="0" width="100%" align="center">
				  <tr>
				    <td class="vbhead" width="175px">
				    <div align="left">		
					  <a><img class="inimg" src="'.$showpostnew.'" alt="Ungelesen" border="0" /></a>
						'.date($mosLang->VB_DATE_FORMAT_LONG, $reply->dateline).'
					  <a name="newpost"></a>
					  </div>
				    </td>
				    <td class="vbhead">
					&nbsp;#<a href="'.$showpostcount.'" target="new"><strong>'.$post.'</strong></a>
					</td>
				   </tr>
				   <tr valign="top">
					 <td class="vbalt2" width="175px">
					   <div id="post" align="left">
					   <a class="big" href="'.$userlink.'"><font color="red" >'.$reply->username.'</font></a>
					   </div>
					   <div class="vbsmallfont" align="left">'.$user->usertitle.'</div>
					   <div class="vbsmallfont">&nbsp;<br />
					   <div align="left">'.$mosLang->VB_JOINDATE.' '.date($mosLang->VB_DATE_FOMAT_SHORT, $user->joindate).'</div>
					   <div align="left">'.$mosLang->VB_POSTS.' '.$user->posts.'</div>
					   <div>&nbsp;</div></div>					
					 </td>
					 <td class="vbalt1">
					   <div class="vbsmallfont" align="left">
					   <img class="inimg" src="'.$iconlink.'" alt="'.$icontitle.'" border="0" />
					   <strong>'.nl2br($reply->title).'</strong>
					   </div>
					   <hr size="1" style="color:#D1D1E1" />
					   <div align="left">'.$pagetext.'</div>
					  </td>
					 </tr>
					 <tr>
					   <td class="vbalt2" align="left">
						 <img class="inimg" src="'.$statuslink.$status.'" alt="'.$reply->username.' ist '.$stat_name.'" border="0" />&nbsp;</td>
					   <td class="vbalt1">';
            if ($params->allow_anon OR $is_user) {

                $showreply .='<a href="'.$replylink.'">
						 <img src="'.$buttonlink.'reply_small.gif" alt="Reply" border="0" /></a>
						 <a href="'.$quotelink.'">
						 <img src="'.$buttonlink.'quote.gif" alt="Quote" border="0" /></a>';
            }

            $showreply .='</td>
					  </tr>
					 </table>
					 </div>
					 </div>
					 </div>
				   </div>
				  </div>
				 </div>
				</div>';
        }
		    
        if (!$params->allow_anon AND !$is_user) {
            $showreply .= '<p><center><font color="red" size="middle">'.$mosLang->COMMENT_ONLYREGISTERED.'</font></center></p>';

        }
        if ($params->compact_view == 1 && $params->compact_view != ''){
            $showreply =  make_frontpagelink($threadid, $row, $params);
            return $showreply;
        } else {
            if ($_REQUEST['option'] == 'com_frontpage') {
                $showreply =  make_frontpagelink($threadid, $row, $params);
                return $showreply;
            } else {
                return $showreply;
            }
        }
   }
   
   
}

function make_frontpagelink ($threadid, $row, $params) {
    global $database, $mosConfig_absolute_path, $mosConfig_live_site;
    global $mosConfig_sef;

    $title = str_replace("'", "`", $row->title);
    $title = $params->title_prefix.$title;

    if ($params->use_database == 1 ) {  
    	$database2 = new database( $params->db_host,$params->db_user,$params->db_passwd, $params->db_dbname, $params->db_prefix );
   	    $database2->setQuery("SELECT count(*) as replies"."\nFROM {$params->db_prefix}post"."\nWHERE threadid = '".$threadid."';");
        $replies = $database2->loadResult() - 1;
    } else {    
        $database->setQuery("SELECT count(*) as replies"."\nFROM {$params->db_prefix}post"."\nWHERE threadid = '".$threadid."';");
        $replies = $database->loadResult() - 1;
    }
    if ($replies < 0) $replies = 0;
    
    if ($params->use_vbridge == 1 && $params->use_vbridge != ''){
    	$database->setQuery("SELECT id FROM #__menu WHERE link='index.php?option=com_vbridge' AND published='1'");
        $itemid = $database->loadResult();
        $scripturl = basename($_SERVER['PHP_SELF'])."?option=com_vbridge&Itemid=" .$itemid;
        if ($params->begin_end==1){$vbridge_location = "0";} else {$vbridge_location="new";}
        $showreply = '<br /><a class="readon" href="'.sefRelToAbs($scripturl . '&file=showthread.php&t=' . $threadid ).'"> ('.$replies.') '.$params->link_text.'</a><br />';
    }else{
        if ($params->vbpath == '') {
            die ('Please go to vBulletin discuss bot and click save to initialize parameters.');
        }
        if ($params->begin_end==1){$vbridge_location = "0";} else {$vbridge_location="new";}
        $showreply = '<br /><a  class="readon" href="'.$params->vbpath.'/showthread.php?t=' . $threadid .'"> ('.$replies.') '.$params->link_text.'</a><br />';
    }


    return $showreply;
}

class JoomlaVBRIDGEBot {

    ## COMMON FOR ALL LANGUAGES
    ##
    var $VB_ISO 				    	= 'iso-8859-1';
    var $VB_DATE_FORMAT_LC 				= 'A, d. B Y'; //Verwendet das PHP strftime Format
    var $VB_DATE_FOMAT_SHORT 			= ' M Y'; // short date
    var $VB_DATE_FORMAT_LONG 			= 'd.m.Y H:i'; // use PHP strftime Format, more info at http://php.net

    ## COMMON FOR VBRIDGEBOT
    ##
    var $VB_BOT_COMMENTS				= "Comment(s):";
    var $VB_BOT_WRITECOMMENT			= "Write comment:";
    var $VB_JOINDATE        			= "Joindate:";
    var $VB_POSTS           			= "Posts:";
    var $COMMENT_ONLYREGISTERED         = "Only registered users can write comments.<br />Please login or register.";
}
?>
<script language="JavaScript">
function send_form(form_id)
{
    document.getElementById(form_id).submit();
}
</script>
<style>
.vbborder
{
	background-color: #D1D1E1;
	color: #000000;
	border: 1px solid #0B198C;
}
.vbhead
{
	background-color: #4a574a;
	color: #FFFFFF;
	font-weight:normal;
	text-align:right
	font: bold 11px tahoma, verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}

.vbalt1, .vbalt1Active
{
	background-color: #FFFFFF;
	color: #000000;
	font-weight:normal;
	text-align:right;
}
.vbalt2, .vbalt2Active
{
	background-color: #bfc4a6;
	color: #000000;
	font-weight:normal;
	text-align:right;
}

.vbsmallfont
{
	font: 11px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.big { font-size: 14pt; }
td.vbhead, div.vbhead { 
padding: 4px;
text-align:right;

}
.normal { font-weight: normal; }
.inimg { vertical-align: middle; }

a.readon:link, a.readon:visited {
  color            : #999999;
  font-family      : Tahoma, Verdana, Arial, Helvetica, sans-serif;
  font-size        : 10px;
  font-weight      : normal;
  background       : url(mambots/content/readon_normal.png) #F0F0F0 no-repeat;
  border           : 1px solid #E0E0E0;
  padding          : 2px 4px 2px 20px;
  white-space      : normal;
  float            : left;
  line-height      : 10px;
  text-decoration  : none;
}

a.readon:hover {
  color            : #4C6790;
  font-family      : Tahoma, Verdana, Arial, Helvetica, sans-serif;
  font-size        : 10px;
  font-weight      : normal;
  background       : url(mambots/content/readon_hover.png) #F0F0F0 no-repeat;
  border           : 1px solid #E0E0E0;
  padding          : 2px 4px 2px 20px;
  white-space      : normal;
  float            : left;
  line-height      : 10px;
  text-decoration  : none;
}


-->
</style>