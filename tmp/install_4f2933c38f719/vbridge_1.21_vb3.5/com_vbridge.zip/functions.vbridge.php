<?php
/**
  * @version $Id: functions.vbridge.php,v 1.2 2005/10/22 19:15:48 predator Exp $ 
  * @package Joomla! vBridge 
  * @copyright (C) 2005 wh-solution.com 
  * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL 
  */


defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');
/**
 * Show the text in green
 *
 * @param string $text
 * @return string
 */
function paintGreen($text) {
	return '<font color="green">'.$text.'</font>';
}
/**
 * Show the text in red
 *
 * @param string $text
 * @return string
 */
function paintRed($text) {
	return '<font color="red"><b>'.$text.'</b></font>';
}

/**
 * Checks if mod_vbridge_login is installed and published
 *
 * @return boole
 */
function isVBModInstalled() {
	global $database;
	$database->setQuery("SELECT * FROM #__modules WHERE module = 'mod_vbridge_login' AND published = 1 ");
	if ($database->loadResult()) {
		return true;
	}
	return false;
}

/**
 * Checks if vBulletin is installed
 *
 * @param string $vb_useextdb
 * @param string $vb_dbhost
 * @param string $vb_dbuser
 * @param string $vb_dbpass
 * @param string $vb_dbname
 * @param string $vb_prefix
 * @return boole
 */
function isVBInstalled($vb_useextdb,$vb_dbhost,$vb_dbuser,$vb_dbpass,$vb_dbname,$vb_prefix) {
	global $database;

	if ($vb_useextdb == 1) {

		$db_resource = mysql_connect($vb_dbhost,$vb_dbuser,$vb_dbpass);
		if (!$db_resource) {
			echo "unable to connect to database\n";

		}
		$db_selected = mysql_select_db($vb_dbname);
		if (!$db_selected) {
			die ("Can't use $vb_dbname: " . mysql_error());
		}
		$result = mysql_list_tables($vb_dbname);
	}else {

		$result = mysql_list_tables($mosConfig_db);
	}
	while ($row = mysql_fetch_row($result)) {
		if ((strpos($row[0], $vb_prefix."datastore") !== false) && (strpos($row[0], $vb_prefix."datastore") == 0)) {
			return true;
		}
	}
	return false;
}

/**
 * Checks which vBulletin Version is used
 *
 * @param string $vb_useextdb
 * @param string $vb_dbhost
 * @param string $vb_dbuser
 * @param string $vb_dbpass
 * @param string $vb_dbname
 * @param string $vb_prefix
 * @return string
 */
function vBVersion($vb_useextdb,$vb_dbhost,$vb_dbuser,$vb_dbpass,$vb_dbname,$vb_prefix) {
	global $database;

	if ($vb_useextdb == 1) {
		$database2 = new database( $vb_dbhost,$vb_dbuser,$vb_dbpass, $vb_dbname, $vb_prefix );
		$database2->setQuery("SELECT value FROM {$vb_prefix}setting WHERE varname = 'templateversion'");
		$result = $database2->loadResult();
	} else {
		$database->setQuery("SELECT value FROM {$vb_prefix}setting WHERE varname = 'templateversion'");
		$result = $database->loadResult();
	}
	return $result;
}
/**
 * Checks if the CB is installed
 *
 * @return boole
 */
function isCommunityLogin() {
	global $database;

	$database->setQuery("SELECT * FROM #__modules WHERE module LIKE 'mod_comprofiler%' AND published=1");
	if ($database->loadResult()) {
		return true;
	}
	return false;
}
/**
 * Checks if the Theme index.php is patched
 *
 * @param string $cur_template
 * @return boole
 */
function isThemePatched($cur_template) {
	global $mosConfig_absolute_path, $mosVB;

	$file = $mosConfig_absolute_path."/templates/".$cur_template."/index.php";
	if ($fp = fopen($file, 'r')) {
		$content = fread($fp, filesize($file));
		fclose($fp);
	} else {
		return false;
	}
	$pos = strpos($content, $mosVB->JOOMLA_VB_BEGIN2 );
	if (!($pos === false) && $pos >= 0) {
		return true;
	}
	return false;
}

/**
 * Checks if the includes/config.php is patched
 *
 * @param array $vb_config
 * @return boole
 */
function isConfigPatched($vb_config) {
	global $mosVB;

	$file = $vb_config[0]->vb_path."/includes/config.php";
	if ($fp = fopen($file, 'r')) {
		$content = fread($fp, filesize($file));
		fclose($fp);
	} else {
		return false;
	}
	$pos = strpos($content, $mosVB->JOOMLA_VB_BEGIN );
	if (!($pos === false) && $pos >= 0) {
		return true;
	}
	return false;
}

/**
 * If config.php is not patched via the installscript give an option to do here.
 *
 * @param array $vb_config
 */
function patchConfig($vb_config) {

	$file = $vb_config[0]->vb_path."/includes/config.php";

	if ($fp = fopen($file, 'r')) {
		$content = fread($fp, filesize($file));
		$origcontent = $content;
		fclose($fp);
	} else {
		$msg= "ERROR: Could not read vBulletin config.php";
	}

	$vb_search = "?>";

	$pos = strpos($content, $vb_search);
	if (!($pos === false) && $pos >= 0) {
		$content = str_replace($vb_search, getConfigCode2().$vb_search, $content);
	} else {
		$msg= "ERROR: vBulletin config.php not patched";
	}

	$bakfile = $vb_config[0]->vb_path.'/includes/config.php~';
	@chmod($vb_config[0]->vb_path.'/includes', 0777);
	if (!(copy($file, $bakfile))) {

		echo "ERROR: Could not write config.php~";
		exit();
	}
	$oldperms = fileperms($file);
	@chmod($file, $oldperms | 0777);
	if ($fp = fopen($file, 'w')) {
		fputs($fp, $content);
		fclose($fp);
		@ chmod($file, $oldperms);
		echo "vBulletin config.php successful patched";
	} else {
		echo "ERROR: Could not patch vBulletin config.php please patch manual.";
		exit();
	}
}
function getConfigCode2() {
	global $mosConfig_absolute_path, $mosConfig_live_site;
	global $mosConfig_db,$mosConfig_host, $mosConfig_user, $mosConfig_password, $mosConfig_db, $mosConfig_dbprefix;

	$JOOMLA_VB_BEGIN 	= "//<!-- Begin Joomla-vBridge from WH-SOLUTION -->";
	$JOOMLA_VB_END 	= "//<!-- End Joomla-vBridge -->";

	return ""
	. $JOOMLA_VB_BEGIN."\n"
	. "\n\t"."define('MOS_PATH','$mosConfig_absolute_path');"
	. "\n\t"."define('MOS_URL','$mosConfig_live_site');"
	. "\n\t"."define('MOS_HOST','$mosConfig_host');"
	. "\n\t"."define('MOS_USER','$mosConfig_user');"
	. "\n\t"."define('MOS_PASS','$mosConfig_password');"
	. "\n\t"."define('MOS_NAME','$mosConfig_db');"
	. "\n\t"."define('MOS_PREFIX','$mosConfig_dbprefix');\n"
	. $JOOMLA_VB_END."\n\n";
}

function isMamboVBUserSync($vb_useextdb,$vb_dbhost,$vb_dbuser,$vb_dbpass,$vb_dbname,$vb_prefix) {
	global $mosConfig_db,$mosConfig_dbprefix;
	global $database, $mosConfig_absolute_path;

	$mos_prefix=$mosConfig_dbprefix;
	if ($vb_useextdb == 1) {
		$mos_prefix=$mosConfig_db.".".$mosConfig_dbprefix;
		$vbprefix=$vb_dbname.".".$vb_prefix;
		$database2 = new database( $vb_dbhost,$vb_dbuser,$vb_dbpass, $vb_dbname, $vb_prefix );
		$query = ""." SELECT count(*)"." FROM {$vbprefix}user"." LEFT JOIN {$mos_prefix}users ON {$mos_prefix}users.username={$vbprefix}user.username "." WHERE {$mos_prefix}users.username IS NULL ";
		$database2->setQuery($query);
		if (intval($database2->loadResult()) > 0) {
			return false;
		}
		if ($database2->getErrorNum()) {
			return $database2->getErrorMsg();
		}
		$query = ""." SELECT count(*)"." FROM {$mos_prefix}users"." LEFT JOIN {$vbprefix}user ON {$vbprefix}user.username = {$mos_prefix}users.username"." WHERE {$vbprefix}user.username IS NULL OR {$mos_prefix}users.vb_userid = '0'";
		$database2->setQuery($query);
		if (intval($database2->loadResult()) > 0) {
			return false;
		}
		if ($database2->getErrorNum()) {
			return $database2->getErrorMsg();
		}
	} else {
		$query = ""." SELECT count(*)"." FROM {$vbprefix}user"." LEFT JOIN {$mos_prefix}users ON {$mos_prefix}users.username={$vbprefix}user.username "." WHERE {$mos_prefix}users.username IS NULL ";
		$database->setQuery($query);
		if (intval($database->loadResult()) > 0) {
			return false;
		}
		if ($database->getErrorNum()) {
			return $database->getErrorMsg();
		}
		$query = ""." SELECT count(*)"." FROM {$mos_prefix}users"." LEFT JOIN {$vbprefix}user ON {$vbprefix}user.username = {$mos_prefix}users.username"." WHERE {$vbprefix}user.username IS NULL OR {$mos_prefix}users.vb_userid = '0'";
		$database->setQuery($query);
		if (intval($database->loadResult()) > 0) {
			return false;
		}
		if ($database->getErrorNum()) {
			return $database->getErrorMsg();
		}
	}
	return true;
}
/**
 * Synchronize vBulletin User to Joomla
 *
 * @param string $vb_prefix
 * @return $count
 */
function syncVBtoJoomla($config) {
	global $mosConfig_dbprefix;
	global $database, $mosConfig_absolute_path, $mosConfig_db,$mosLang;

	$mos_prefix=$mosConfig_dbprefix;
	$vbprefix=$config[0]->vb_prefix;
	if ($config[0]->vb_useextdb == 1) {
		$vbprefix=$config[0]->vb_dbname.".".$config[0]->vb_prefix;
	}
	$query = "SELECT {$mos_prefix}users.id, {$vbprefix}user.userid, {$vbprefix}user.usergroupid, {$vbprefix}user.username, {$vbprefix}user.password, {$vbprefix}user.email, {$vbprefix}user.joindate, {$vbprefix}user.lastvisit "." FROM {$vbprefix}user "." AS {$config[0]->vb_prefix}user LEFT JOIN {$mos_prefix}users ON {$mos_prefix}users.username={$vbprefix}user.username "." WHERE {$mos_prefix}users.username IS NULL OR {$mos_prefix}users.vb_userid = '0'";

	$database->setQuery($query);
	$rows = $database->loadObjectList();
	if ($database->getErrorNum()) {
		return $database->getErrorMsg();
	}
	$count = 0;
	foreach ($rows as $row) {
		$msg = insertToJoomla2($row);
		if ($msg != 1) {

			mosRedirect("index2.php?option=com_vbridge", $mosLang->MSG_FAILED.": ".$msg);
		}
		$count ++;
	}

	return $count;
}
/**
 * Synchronize Joomla User to vBulletin
 *
 * @param string $vb_prefix
 * @return $count
 */
function syncJoomlaToVB($config) {
	global $mosConfig_dbprefix;
	global $database, $mosConfig_absolute_path, $mosConfig_db,$mosLang;

	$mos_prefix=$mosConfig_dbprefix;
	$vbprefix=$config[0]->vb_prefix;
	if ($config[0]->vb_useextdb == 1) {
		//$mos_prefix=$mosConfig_db.".".$mosConfig_dbprefix;
		$vbprefix=$config[0]->vb_dbname.".".$config[0]->vb_prefix;
	}

	$query = "SELECT {$mos_prefix}users.id, {$mos_prefix}users.username, {$mos_prefix}users.password, {$mos_prefix}users.email, {$mos_prefix}users.registerDate"." FROM {$mos_prefix}users"." AS #__users LEFT JOIN {$vbprefix}user ON {$vbprefix}user.username = {$mos_prefix}users.username"." WHERE {$vbprefix}user.username IS NULL";

	$database->setQuery($query);
	$rows = $database->loadObjectList();
	if ($database->getErrorNum()) {
		return $database->getErrorMsg();
	}

	$count = 0;
	foreach ($rows as $row) {
		$msg = insertToVB2($row,$config);
		if ($msg != 1) {
			mosRedirect("index2.php?option=com_vbridge", $mosLang->MSG_FAILED.": ".$msg);
		}
		$count ++;
	}
	return $count;
}

/**
 * Insert vBulletin User to the Mambo Usertable
 *
 * @param array $data
 * @return boole
 */
function insertToVB2($data,$config) {
	global $database, $mosConfig_absolute_path;
	global $my, $acl;

	$vbulletin_salt = '';
	for ($i = 0; $i < 3; $i++)
	{
		$vbulletin_salt .= chr(rand(32, 126));
	}
	$vbprefix=$config[0]->vb_prefix;
	$password = md5 ($data->password . $vbulletin_salt);

	$query ="INSERT INTO {$vbprefix}user SET
	    usergroupid       = '2',
		membergroupids    = '',
		displaygroupid    = '0',
		username          = '" . $data->username . "',
		password          = '" . $password . "',
		passworddate      = '" . date('Y-m-d') . "',
		email             = '" . $data->email . "',
		styleid           = '1',
		parentemail       = '',
		homepage          = '',
		icq               = '',
		aim               = '',
		yahoo             = '',
		showvbcode        = '1',
		usertitle         = 'Junior Member',
		customtitle       = '0',
		joindate          = '" . time() . "',
		daysprune         = '0',
		lastvisit         = '" . time() . "',
		lastactivity      = '" . time() . "',
		lastpost          = '0',
		posts             = '0',
		reputation        = '10',
		reputationlevelid = '5',
		timezoneoffset    = '0',
		pmpopup           = '0',
		avatarid          = '0',
		avatarrevision    = '0',
		options           = '3159',
		birthday          = '',
		birthday_search   = '0000-00-00',
		maxposts          = '-1',
		startofweek       = '1',
		ipaddress         = '" . $_SERVER['REMOTE_ADDR'] . "',
		referrerid        = '0',
		languageid        = '0',
		msn               = '',
		emailstamp        = '0',
		threadedmode      = '0',
		autosubscribe     = '-1',
		pmtotal           = '0',
		pmunread          = '0',
		salt              = '$vbulletin_salt'";


	if ($config[0]->vb_useextdb == 1) {
		$database2 = new database( $config[0]->vb_dbhost,$config[0]->vb_dbuser,$config[0]->vb_dbpass, $config[0]->vb_dbname, $config[0]->vb_prefix );
		$database2->setQuery( $query );
		if (!$database2->query()) {
			$error=$database2->getErrorMsg();
			echo "<script> alert('".$error."'); window.history.go(-1); </script>\n";
			exit();
		}
		$vb_user = $database2->insertid();

		$database2->setQuery("SELECT MAX(userid) as userid FROM {$vbprefix}user");
		$vbulletin_userid = $database2->loadResult();
		$database2->query();

		$database2->setQuery("INSERT INTO {$vbprefix}userfield     SET userid = '$vbulletin_userid'");
		$database2->query();
		$database2->setQuery("INSERT INTO {$vbprefix}usertextfield SET userid = '$vbulletin_userid'");
		$database2->query();

		$database2->setQuery("SELECT COUNT(*) AS users, MAX(userid) AS max FROM {$vbprefix}user");
		$vbull_members = $database2->loadAssocList();

		$database2->setQuery("SELECT userid, username FROM {$vbprefix}user WHERE userid = $vbull_members[max]");
		$vbull_newuser = $database2->loadAssocList();

		$vbull_values = array(
		'numbermembers' => $vbull_members['users'],
		'activemembers' => $vbull_members['active'],
		'newusername'   => $vbull_newuser['username'],
		'newuserid'     => $vbull_newuser['userid']);

		$query = "REPLACE INTO {$vbprefix}datastore (title, data) VALUES ('userstats', '" . addslashes(trim(serialize($vbull_values))) . "')";
		$database2->setQuery( $query );
		$database2->query();
	} else {



		$database->setQuery( $query );
		if (!$database->query()) {
			$error=$database->getErrorMsg();
			echo "<script> alert('".$error."'); window.history.go(-1); </script>\n";
			exit();
		}
		$vb_user = $database->insertid();

		$database->setQuery("SELECT MAX(userid) as userid FROM {$vbprefix}user");
		$vbulletin_userid = $database->loadResult();
		$database->query();

		$database->setQuery("INSERT INTO {$vbprefix}userfield     SET userid = '$vbulletin_userid'");
		$database->query();
		$database->setQuery("INSERT INTO {$vbprefix}usertextfield SET userid = '$vbulletin_userid'");
		$database->query();

		$database->setQuery("SELECT COUNT(*) AS users, MAX(userid) AS max FROM {$vbprefix}user");
		$vbull_members = $database->loadAssocList();

		$database->setQuery("SELECT userid, username FROM {$vbprefix}user WHERE userid = $vbull_members[max]");
		$vbull_newuser = $database->loadAssocList();

		$vbull_values = array(
		'numbermembers' => $vbull_members['users'],
		'activemembers' => $vbull_members['active'],
		'newusername'   => $vbull_newuser['username'],
		'newuserid'     => $vbull_newuser['userid']);

		$query = "REPLACE INTO {$vbprefix}datastore (title, data) VALUES ('userstats', '" . addslashes(trim(serialize($vbull_values))) . "')";
		$database->setQuery( $query );
		$database->query();

	}
	$query = "UPDATE #__users"
		. "\n SET vb_userid = '$vb_user'"
		. "\n WHERE id = '$data->id'"
		;
	$database->setQuery( $query );
	$database->query() or die( $database->getErrorMsg() );

	return true;

}

/**
 * Insert vBulletin User to the Joomla Usertable
 *
 * @param array $data
 * @return boole
 */
function insertToJoomla2($data) {

	global $database,$mosLang, $my, $acl;

	if($data->usergroupid == 6) {
		$group = 25;
		$type = 'Super Administrator';
	} else {
		$group = 18;
		$type = 'Registered';
	}

	if ($data->id){
		$row = new mosUser( $database );
		// load the row from the db table
		$row->load( $data->id );
		$user['password'] = $data->password;
		$user['vb_userid'] = $data->userid;
		if (!$row->bind($user)) {
			mosRedirect("index.php?option=com_vbridge&mosmsg=".$mosLang->MSG_CANNOT_COPY_USER_TO_MAMBO);
		}
		$row->vb_userid = $data->userid;
		$row->password = $data->password;

		if (!$row->store()) {
			return $row->getErrorMsg();
		}
		$row->checkin();
		return true;
	} else {
		$row = new mosUser($database);
		$user['name'] = $data->username;
		$user['username'] = $data->username;
		$user['email'] = $data->email;
		$user['password'] = $data->password;
		$user['vb_userid'] = $data->userid;
		if ($data->usergroupid == 1 OR $data->usergroupid == 3 OR $data->usergroupid == 4 OR $data->usergroupid == 8)
		{
			$block= 1;
		} else {
			$block= 0;
		}
		if (!$row->bind($user)) {
			mosRedirect("index.php?option=com_vbridge&mosmsg=".$mosLang->MSG_CANNOT_COPY_USER_TO_MAMBO);
		}
		mosMakeHtmlSafe($row);
		$row->id = 0;
		$row->name = $data->username;
		$row->username = $data->username;
		$row->email = $data->email;
		$row->usertype = $type;
		$row->gid = $group;
		$row->activation = '';
		$row->block = $bock;
		$row->password = $data->password;
		$row->registerDate = date("Y-m-d H:i:s", $data->joindate);
		$row->lastvisitDate = date("Y-m-d H:i:s", $data->lastvisit);
		$row->vb_userid = $data->userid;
		if (!$row->store()) {
			return $row->getError();
		}
		$row->checkin();
		return true;
	}
}
?>