<?php
/**
* @version $Id: vbridge.php,v 1.20 2005/08/23 01:27:11 predator Exp $
* @package com_vbridge
* @copyright (C) wh-solution.com
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $database, $mainframe, $mosConfig_live_site, $my;

$database->setQuery("SELECT id FROM #__menu WHERE link='index.php?option=com_vbridge' AND published='1'");
$Itemid = $database->loadResult();

$vb_config = null;
$database->setQuery( "SELECT * FROM #__vbridge_config WHERE id='1'" );
$database->loadObject( $vb_config );

if (isset($_ENV['QUERY_STRING']) OR isset($_SERVER['QUERY_STRING']))
{
    $script = ($_SERVER['QUERY_STRING'] ? $_SERVER['QUERY_STRING'] : $_ENV['QUERY_STRING']);
}

$link = str_replace("option=com_vbridge&Itemid=$Itemid&file=","", $script);
$link = str_replace(".php&",".php?", $link);
if ($vb_config->wrapped == 1 ) {
    if (isset($_REQUEST['file']) && isset($_REQUEST['file']) !== '' ) {
        if (strstr( $_REQUEST['file'], 'http' ) OR strstr( $_REQUEST['file'], 'https' ) ){
            mosRedirect($_REQUEST['file']);
        }
        if ($_REQUEST['file'] == 'admincp/index.php&' OR $_REQUEST['file'] == 'admincp/index.php' OR substr($_REQUEST['file'], -17) == 'admincp/index.php'){
        
            $url=$vb_config->vb_url."/admincp/index.php"; 
           header("Location: $url");
        }
        if ($_REQUEST['file'] == 'modcp/index.php&' OR $_REQUEST['file'] == 'modcp/index.php' OR substr($_REQUEST['file'], -15) == 'modcp/index.php'){
        
            $url=$vb_config->vb_url."/modcp/index.php"; 
           header("Location: $url");
        }
        if (isset($_REQUEST['action']) == 'newspost') {
            if (isset($_REQUEST['f'])) {
                $f = 'f='.$_REQUEST['f'].'&';
            } else {
                $f ='';
            }
            $url = $vb_config->vb_url."/".$_REQUEST['file'].'?'.$f;
        } else {
              $url = $vb_config->vb_url."/".$link;
        }
        if ($_REQUEST['file'] == 'register.php') {
            if ($vb_config->vb_reg == 1 ){
                $registerlink = ($vb_config->cb_login ? $mosConfig_live_site.'/index.php?option=com_comprofiler&task=registers' : $mosConfig_live_site.'/index.php?option=com_registration&task=register');
                $reminderlink = ($vb_config->cb_login ? $mosConfig_live_site.'/index.php?option=com_comprofiler&task=lostPassword' : $mosConfig_live_site.'/index.php?option=com_registration&task=lostPassword');
                mosRedirect( $registerlink );
                exit();              
            } else {
                $url = $vb_config->vb_url."/register.php";   
            }
        }
        if (isset($_REQUEST['p']) && isset($_REQUEST['p']) !== '')  {
          if ($_REQUEST['file'] == 'report.php')  {
            $p = '?p='.$_REQUEST['p'];
            $url = $vb_config->vb_url."/".$link.$p;
          }   
        } else {           
          if ($_REQUEST['file'] == 'report.php')  {
            $p='';
            $url = $vb_config->vb_url."/index.php";
        }
        if ($_REQUEST['file'] == 'misc.php')  {
            if (isset($_REQUEST['do']) == 'buddylist' )  {
               $do = '?do='.$_REQUEST['do'];
               mosRedirect($vb_config->vb_url."/".$_REQUEST['file'].$do);
            }   
        } 
        if ($_REQUEST['file'] == '#')  {
             $url = $vb_config->vb_url."/index.php";
        } 
        
        } 
    } else {
        $url = $vb_config->vb_url."/index.php";
    }
    $xhtml=0;
    $row->loadx = '';
	$row->load 	= '';
	// auto height control
	if ( $xhtml ) {
			$row->loadx = 'window.onload = iFrameHeight;';
		} else {
			$row->load = 'onload="iFrameHeight()"';
	}
	


	?>
	<script language="javascript" type="text/javascript">
	<?php echo $row->loadx ."\n"; ?>
	function iFrameHeight() {
			var h = 0;
			if ( !document.all ) {
				// Firefox
				//alert("1");
				h = document.getElementById('blockrandom').contentDocument.height;
				document.getElementById('blockrandom').style.height = 60 + 'px';
				h = document.getElementById('blockrandom').contentDocument.height;
				//alert(h);
				document.getElementById('blockrandom').style.height = h + 60 + 'px';
			} else if( document.all ) {
				// Internet Explorer
				//alert("2");
				h = document.frames('blockrandom').document.body.scrollHeight;
				document.all.blockrandom.style.height =  20 + 'px';
				h = document.frames('blockrandom').document.body.scrollHeight;
				//alert(h);
				document.all.blockrandom.style.height = h + 20 + 'px';
			}
		}

		</script>
	   <iframe   
		id="blockrandom"
		name="forum"
		src="<?php echo $url; ?>" 
		width="100%" 
		height="3800" 
		scrolling="no" 
		align="top"
		frameborder="0"
		class="wrapper"
		<?php echo $row->load ."\n"; ?>
		>
		<?php echo _CMN_IFRAMES; ?>
		</iframe>
		
		<?php 
} else {
    
    if (isset($_REQUEST['file']) == 'register.php') {
            if ($vb_config->vb_reg == 1 ){
                $registerlink = ($vb_config->cb_login ? $mosConfig_live_site.'/index.php?option=com_comprofiler&task=registers' : $mosConfig_live_site.'/index.php?option=com_registration&task=register');
                $reminderlink = ($vb_config->cb_login ? $mosConfig_live_site.'/index.php?option=com_comprofiler&task=lostPassword' : $mosConfig_live_site.'/index.php?option=com_registration&task=lostPassword');
                mosRedirect( $registerlink );
                exit();              
            } else {
                mosRedirect($vb_config->vb_url."/register.php");   
            }
        } else {
            mosRedirect($vb_config->vb_url."/index.php");

        }
}
?>