<?
/** 
  * @version $Id: uninstall.vbridge.php,v 1.0 2005/07/07 01:27:11 predator Exp $ 
  * @package com_vbridge 
  * @copyright (C) wh-solution.com 
  * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL 
  */




defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );



function com_uninstall()
{

    global $mosConfig_absolute_path;
	$bakfile = $mosConfig_absolute_path .'/index.php~';
	$origfile = $mosConfig_absolute_path .'/index.php';

	if (file_exists($bakfile)) {
		if (!(copy($bakfile,$origfile))) {
			mosRedirect( 'index2.php?option=com_installer&element=component', 'Operation Failed: Could not rename backup file '.$bakfile );
	}
	unlink($bakfile);
	}
}



?>