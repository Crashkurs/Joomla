<?
/**
  * @version $Id: install.vbridge.php,v 1.0 2005/07/07 01:27:11 predator Exp $ 
  * @package com_vbridge 
  * @copyright (C) wh-solution.com 
  * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL 
  */


function com_install() {
    global $database, $mosConfig_absolute_path;

    # Set up new icons for admin menu
    $database->setQuery("UPDATE #__components SET admin_menu_img='js/ThemeOffice/config.png' WHERE admin_menu_link='option=com_vbridge&task=config'");
    $iconresult[1] = $database->query();

    $msg="";
    // Let's find vBulletin!
    $joomla_path = dirname(dirname(dirname(dirname(__FILE__))));

    $paths_to_try = array(
    '/forum', '/forums','/community', '/board', '/vb', '/yabbse', '/vbulletin',
    '/../forum', '/../forums','/../community', '/../board', '/../vb', '/../yabbse', '/../vbulletin',
    '/../../forum', '/../../forums','/../../community', '/../../board', '/../../vb', '/../../yabbse', '/../../vbulletin',
    '/../../../forum', '/../../../forums','/../../../community', '/../../../board', '/../../../vb', '/../../../yabbse', '/../../../vbulletin',
    '/components/com_vbridge'
    );

    foreach ($paths_to_try as $possible)
    if (file_exists($joomla_path . $possible . '/reputation.php'))
    {
        $vb_path = realpath($joomla_path . $possible);
        break;
    }

    $file = $vb_path."/includes/config.php";

    if ($fp = fopen($file, 'r')) {
        $content = fread($fp, filesize($file));
        $origcontent = $content;
        fclose($fp);
    } else {
       $msg= "ERROR: Could not read vBulletin config.php"; 
    }
    
    $vb_config = "?>";

    $pos = strpos($content, $vb_config);
    if (!($pos === false) && $pos >= 0) {
        $content = str_replace($vb_config, getConfigCode().$vb_config, $content);
    } else {
        $msg= "ERROR: vBulletin config.php not patched"; 
    }

    $bakfile = $vb_path.'/includes/config.php~';
    if (!(copy($file, $bakfile))) {
       
        $msg= "ERROR: Could not write config.php~"; 
    }
    $oldperms = fileperms($file);
    @ chmod($file, $oldperms | 0222);
    if ($fp = fopen($file, 'w')) {
        fputs($fp, $content);
        fclose($fp);
        @ chmod($file, $oldperms);
        $msg= "vBulletin config.php successful patched"; 
    } else {
        $msg= "ERROR: Could not patch vBulletin config.php Patch the file in the vBridge Admin->Installation."; 
    }


    # Show installation result to user
?>
<center>
<table width="100%" border="0">
  <tr>
    <td>
      <strong>Joomla-vBulletin Bridge</strong><br/>
      <br/>
      This component is released under the terms and conditions of the <a href="index2.php?option=com_admisc&task=license">GNU General Public License</a>.
      <br/>
      Please visit <a href="http://developer.joomla.org/sf/projects/vbridge">vBridge at Joomla Developerforge</a> for updates.
    </td>
  </tr>
  <tr>
    <td>
      <code>Installation: <font color="green">successful</font></code>
    </td>
    <td>
      <code>Patch Config.php: <font color="green"><?php echo $msg; ?></font></code>
    </td>
   </tr>
</table>
</center>

<?
}

function getConfigCode() {
    global $mosConfig_absolute_path, $mosConfig_live_site;
    global $mosConfig_db,$mosConfig_host, $mosConfig_user, $mosConfig_password, $mosConfig_db, $mosConfig_dbprefix;
    
     $JOOMLA_VB_BEGIN 	= "//<!-- Begin Joomla-vBridge from WH-SOLUTION -->";
     $JOOMLA_VB_END 	= "//<!-- End Joomla-vBridge -->";

		return ""
		. $JOOMLA_VB_BEGIN."\n"
        . "\n\t"."define('MOS_PATH','$mosConfig_absolute_path');"
		. "\n\t"."define('MOS_URL','$mosConfig_live_site');"
		. "\n\t"."define('MOS_HOST','$mosConfig_host');"
		. "\n\t"."define('MOS_USER','$mosConfig_user');"
		. "\n\t"."define('MOS_PASS','$mosConfig_password');"
		. "\n\t"."define('MOS_NAME','$mosConfig_db');"
		. "\n\t"."define('MOS_PREFIX','$mosConfig_dbprefix');\n"
		. $JOOMLA_VB_END."\n\n";
	}
?>