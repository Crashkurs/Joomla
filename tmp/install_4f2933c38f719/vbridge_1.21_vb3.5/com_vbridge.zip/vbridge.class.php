<?php
/** 
  * @version $Id: vbridge.class.php,v 1.2 2005/10/25 01:27:11 predator Exp $ 
  * @package Joomla! vBridge 
  * @copyright (C) 2005 wh-solution.com 
  * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL 
  */


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

/**
 * class to check patches
 *
 */
class mosVB {

	var $JOOMLA_VB_BEGIN 	= "//<!-- Begin Joomla-vBridge from WH-SOLUTION -->";
	var $JOOMLA_VB_END 		= "//<!-- End Joomla-vBridge -->";
	var $JOOMLA_VB_BEGIN2 	= "<!-- Begin Joomla-vBridge from WH-SOLUTION -->";
	var $JOOMLA_VB_END2 	= "<!-- End Joomla-vBridge -->";
}

/**
 * Get values class
 *
 */
class vBridgeConfig {
	/** @var string Internal variable to hold the absolute vb path */
	var $vb_path='';
    /** @var string Internal variable to hold URL of the board */
	var $vb_url='';
	/** @var string Internal variable to hold value to redirect or not */
	var $vb_redirect = 0;
	/** @var string Internal variable to hold value to use external db or not */
	var $vb_useextdb = 0;
	/** @var string Internal variable to hold vb databasehost */
	var $vb_dbhost='';
	/** @var string Internal variable to hold vb databaseuser */
	var $vb_dbuser='';
	/** @var string Internal variable to hold vb databasepassword */
	var $vb_dbpass='';
	/** @var string Internal variable to hold vb databasename */
	var $vb_dbname='';
	/** @var string Internal variable to hold vb databaseprefix */
	var $vb_prefix='';
	/** @var int Internal variable to hold vb cookierefix */
	var $vb_cookie='';
	/** @var int Internal variable to hold the value wrapped/unwrapped */
	var $wrapped = 1;
	/** @var int Internal variable to hold the vb license */
	var $vb_license = '';
	/** @var int Internal variable to hold the value cb used or not */
	var $cb_login = 0;
	/** @var int Internal variable to hold the value to use vb or JOOMLA for registration */
    var $vb_reg = 0;
    var $check_user = 0;

	/**
	* vBridgeConfig object constructor
	*/
	function vBridgeConfig(){
	global $database;
	
	$database->setQuery( "SELECT * FROM #__vbridge_config WHERE id='1'" );
	$config = $database->loadObjectList();

	$this->vb_path = $config[0]->vb_path;
	$this->vb_url = $config[0]->vb_url;
	$this->vb_redirect = $config[0]->vb_redirect;
	$this->vb_useextdb = $config[0]->vb_useextdb;
	$this->vb_dbhost = $config[0]->vb_dbhost;
	$this->vb_dbuser = $config[0]->vb_dbuser;
	$this->vb_dbpass = $config[0]->vb_dbpass;
	$this->vb_dbname = $config[0]->vb_dbname;
	$this->vb_prefix = $config[0]->vb_prefix;
	$this->vb_cookie = $config[0]->vb_cookie;
	$this->wrapped = $config[0]->wrapped;
	$this->vb_license = $config[0]->license;
	$this->cb_login = $config[0]->cb_login;
	$this->vb_reg = $config[0]->vb_reg;
	$this->check_user = $config[0]->check_user;
		return;	
	}
}

/**
 * Use mosDBTable to save values
 *
 */
class vBridgeConfigDB extends mosDBTable {
	var $id = 1;
	var $vb_path = null;
	var $vb_url = null;
	var $vb_redirect = null;
	var $vb_useextdb = null;
	var $vb_dbhost = null;
	var $vb_dbuser = null;
	var $vb_dbpass = null;
	var $vb_dbname = null;
	var $vb_prefix = null;
	var $vb_cookie = null;
	var $wrapped = null;
	var $vb_license = null;
	var $cb_login = null;
	var $vb_reg = null;
	var $check_user = null;

	/**
	 * Get Configuration
	 *
	 * @param array $db
	 * @return vBridgeConfigDB
	 */
	function vBridgeConfigDB(& $_db) {
		$this->mosDBTable('#__vbridge_config', 'id', $_db);
	}
}
?>