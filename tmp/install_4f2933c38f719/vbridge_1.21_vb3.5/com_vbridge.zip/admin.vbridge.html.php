<?php
/**
  * @version $Id: admin.vbridge.html.php,v 1.2 2005/10/25 19:45:49 predator Exp $ 
  * @package Joomla! vBridge 
  * @copyright (C) 2005 wh-solution.com 
  * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL 
  */

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

/**
* @package com_vbridge
* @subpackage html
*/
class vbridge_html {

    /**
     * Show Configuration
     *
     * @param string $option
     * @param array $config
     * @param array $configs
     * @param string $cur_template
     */
    function admin_showconfig($option, $config, $configs, $cur_template)
    {
        global $mosConfig_live_site, $mosLang;
        $tabs = new mosTabs(0);
?>

	<div id="overDiv" style="position:absolute; visibility:hidden; z-index:10000;"></div>
	<script language="JavaScript" src="<?php echo $mosConfig_live_site; ?>/includes/js/overlib_mini.js" type="text/javascript"></script>

	<table class="adminheading">
	<tr>
		<th><?php echo $mosLang->HEADER_MAIN; ?></th>
	</tr>
	</table>

    <script language="javascript" type="text/javascript">
    <!--
    function submitbutton(pressbutton) {
        var form = document.adminForm;
        submitform( pressbutton );
        return;
    }
    //-->
    </script>

    <form action="index2.php" method="POST" name="adminForm">

    	<?php $tabs->startPane( 'configPane' ); ?>
		<?php $tabs->startTab( $mosLang->TAB_CONFIGURATION_TITLE, 'general-page' ); ?>

		<table width="100%" border="0" cellpadding="2" cellspacing="2">
		<tr>
		<td valign="top">

    	<table width="100%" border="0" cellpadding="2" cellspacing="2" class="adminForm">
    	<tr>
    	<tr>
    		<td colspan="2"><b><?php echo $mosLang->HEADER_CONFIG_SETTINGS; ?></b></td>
    	</tr>

    	<td colspan="2">&nbsp;</td>
    	</tr>
    	<?php 
    	if (!file_exists($config[0]->vb_path))
    	{
    	    // Let's find vBulletin!
    	    $mambo_path = dirname(dirname(dirname(dirname(__FILE__))));

    	    $paths_to_try = array(
    	    '/forum', '/forums','/community', '/board', '/vb', '/yabbse', '/vbulletin',
    	    '/../forum', '/../forums','/../community', '/../board', '/../vb', '/../yabbse', '/../vbulletin',
    	    '/../../forum', '/../../forums','/../../community', '/../../board', '/../../vb', '/../../yabbse', '/../../vbulletin',
    	    '/components/com_vbridge'
    	    );

    	    foreach ($paths_to_try as $possible)
    	    if (file_exists($mambo_path . $possible . '/reputation.php'))
    	    {
    	        $config[0]->vb_path = realpath($mambo_path . $possible);
    	        break;
    	    }
                      } ?>

    	
		<tr>
			<td align="left" valign="top" width="170"><?php echo $mosLang->FIELD_VB_PATH_ABSOLUT; ?></td>
			<td align="left" valign="top">
				<input type="text" name="vb_path" value="<?php if( $config[0]->vb_path != '' ) echo $config[0]->vb_path; ?>" size="60" /><?php echo file_exists($config[0]->vb_path."/includes/config.php") ? "&nbsp;".mosToolTip( $mosLang->TXT_TIP_CONFIG01 . '</span>', $mosLang->TXT_TIP_CONFIG01_TITLE) : "&nbsp;".mosToolTip( $mosLang->TXT_TIP_CONFIG02 . '</span>', $mosLang->TXT_TIP_CONFIG01_TITLE ). "&nbsp;".paintRed($mosLang->MSG_INCORRECT_PATH) ;?>
				</td>
		</tr>
<tr>
			<td align="left" valign="top" width="170"><?php echo $mosLang->FIELD_VB_URL_ABSOLUT; ?></td>
			<td align="left" valign="top">
				<input type="text" name="vb_url" value="<?php if( $config[0]->vb_url != '' ) echo $config[0]->vb_url; else echo $mosConfig_live_site."/<vBulletin url here>"; ?>" size="60" /><?php echo "&nbsp;".mosToolTip( $mosLang->TXT_TIP_CONFIG03 . '</span>', $mosLang->TXT_TIP_CONFIG03_TITLE ); ?>
			</td>
		</tr>
		<tr>
			<td align="left"><?php echo $mosLang->FIELD_VB_USEEXTDB; ?></td>
			<td align="left">
				<?php echo $configs['vb_useextdb']; ?>&nbsp;&nbsp;
				<?php echo mosToolTip( $mosLang->TXT_TIP_CONFIG12 . '</span>', $mosLang->TXT_TIP_CONFIG12_TITLE ); ?>
			</td>
		</tr>
		
		<tr>
			<td align="left" valign="top"><?php echo $mosLang->FIELD_VB_DB_HOST; ?></td>
			<td align="left" valign="top">
			<?php if (file_exists($config[0]->vb_path."/includes/config.php")) include_once ($config[0]->vb_path."/includes/config.php") ;?>	
				<input type="text" name="vb_dbhost" value="<?php if( $config[0]->vb_dbhost != '' ) echo $config[0]->vb_dbhost; else {$config[0]->vb_dbhost=$config['MasterServer']['servername']; echo $config['MasterServer']['servername'];} ?>" /><?php echo mosToolTip( $mosLang->TXT_TIP_CONFIG04 . '</span>', $mosLang->TXT_TIP_CONFIG04_TITLE ); ?>
			</td>
		</tr>
		
		<tr>
			<td align="left" valign="top"><?php echo $mosLang->FIELD_VB_DB_USER; ?></td>
			<td align="left" valign="top">
			<?php if (file_exists($config[0]->vb_path."/includes/config.php")) include_once ($config[0]->vb_path."/includes/config.php") ;?>	
				<input type="text" name="vb_dbuser" value="<?php if( $config[0]->vb_dbuser != '' ) echo $config[0]->vb_dbuser; else {$config[0]->vb_prefix=$config['MasterServer']['username']; echo $config['MasterServer']['username'];} ?>" /><?php echo mosToolTip( $mosLang->TXT_TIP_CONFIG04 . '</span>', $mosLang->TXT_TIP_CONFIG04_TITLE ) ;?>
			</td>
		</tr>
		
		<tr>
			<td align="left" valign="top"><?php echo $mosLang->FIELD_VB_DB_PASS; ?></td>
			<td align="left" valign="top">
			<?php if (file_exists($config[0]->vb_path."/includes/config.php")) include_once ($config[0]->vb_path."/includes/config.php") ;?>	
				<input type="text" name="vb_dbpass" value="<?php if( $config[0]->vb_dbpass != '' ) echo $config[0]->vb_dbpass; else {$config[0]->vb_prefix=$config['MasterServer']['password']; echo $config['MasterServer']['password'];} ?>" /><?php echo mosToolTip( $mosLang->TXT_TIP_CONFIG04 . '</span>', $mosLang->TXT_TIP_CONFIG04_TITLE ) ;?>
			</td>
		</tr>
		
		<tr>
			<td align="left" valign="top"><?php echo $mosLang->FIELD_VB_DB_NAME; ?></td>
			<td align="left" valign="top">
			<?php if (file_exists($config[0]->vb_path."/includes/config.php")) include_once ($config[0]->vb_path."/includes/config.php") ;?>	
				<input type="text" name="vb_dbname" value="<?php if( $config[0]->vb_dbname != '' ) echo $config[0]->vb_dbname; else {$config[0]->vb_dbname=$config['Database']['dbname']; echo $config['Database']['dbname'];} ?>" /><?php echo mosToolTip( $mosLang->TXT_TIP_CONFIG04 . '</span>', $mosLang->TXT_TIP_CONFIG04_TITLE ) ;?>
			</td>
		</tr>
		<tr>
			<td align="left" valign="top"><?php echo $mosLang->FIELD_VB_DB_PREFIX; ?></td>
			<td align="left" valign="top">
			<?php if (file_exists($config[0]->vb_path."/includes/config.php")) include_once ($config[0]->vb_path."/includes/config.php") ;?>	
				<input type="text" name="vb_prefix" value="<?php if( $config[0]->vb_prefix != '' ) echo $config[0]->vb_prefix; else {$config[0]->vb_prefix=$config['Database']['tableprefix']; echo $config['Database']['tableprefix'];} ?>" /><?php echo isVBInstalled($config[0]->vb_useextdb,$config[0]->vb_dbhost,$config[0]->vb_dbuser,$config[0]->vb_dbpass,$config[0]->vb_dbname,$config[0]->vb_prefix) ? "&nbsp;".mosToolTip( $mosLang->TXT_TIP_CONFIG04 . '</span>', $mosLang->TXT_TIP_CONFIG04_TITLE ) : "&nbsp;".mosToolTip( $mosLang->TXT_TIP_CONFIG05 . '</span>', $mosLang->TXT_TIP_CONFIG04_TITLE ). "&nbsp;".paintRed($mosLang->MSG_INCORRECT_PREFIX) ;?>
			</td>
		</tr>
		<tr>
			<td align="left" valign="top" width="170"><?php echo $mosLang->FIELD_VB_COOKIE_PREFIX; ?></td>
			<td align="left" valign="top">
			<?php if (file_exists($config[0]->vb_path."/includes/config.php")) include_once ($config[0]->vb_path."/includes/config.php") ;?>			
				<input type="text" name="vb_cookie" value="<?php if( $config[0]->vb_cookie != '' ) echo $config[0]->vb_cookie; else {$config[0]->vb_cookie=$config['Misc']['cookieprefix']; echo $config['Misc']['cookieprefix'];} ?>"  /><?php echo file_exists($config[0]->vb_path."/includes/config.php") ? "&nbsp;".mosToolTip( $mosLang->TXT_TIP_CONFIG07 . '</span>', $mosLang->TXT_TIP_CONFIG07_TITLE) : "&nbsp;".mosToolTip( $mosLang->TXT_TIP_CONFIG08 . '</span>', $mosLang->TXT_TIP_CONFIG07_TITLE ). "&nbsp;".paintRed($mosLang->MSG_INCORRECT_PATH) ;?>
				</td>
		</tr>
		
		<tr>
			<td align="left" valign="top"><?php echo $mosLang->FIELD_VB_LICENSE; ?></td>
			<td align="left" valign="top">
				<input type="text" name="vb_license" value="<?php echo $config[0]->vb_license; ?>" /><?php echo "&nbsp;".mosToolTip( $mosLang->TXT_TIP_CONFIG06 . '</span>', $mosLang->TXT_TIP_CONFIG06_TITLE ); ?>
			</td>
		</tr>
        <tr>
    		<td colspan="2"><b><?php echo $mosLang->HEADER_BEHAV_SETTINGS; ?></b></td>
    	</tr>
    	</tr>

    	<td colspan="2">&nbsp;</td>
    	</tr>
		<tr>
			<td align="left" valign="top"><?php echo $mosLang->FIELD_INTEGRATION_OPTION; ?></td>
			<td align="left" valign="top">
				<input type="radio" name="wrapped" value="1" <?php echo $config[0]->wrapped == 1 ? 'checked="checked"' : '' ; ?>><?php echo $mosLang->FIELD_VALUE_WRAPPED; ?>
				<input type="radio" name="wrapped" value="0" <?php echo $config[0]->wrapped == 0 ? 'checked="checked"' : '' ; ?>><?php echo $mosLang->FIELD_VALUE_UNWRAPPED; ?>
				&nbsp;&nbsp;
				<?php echo mosToolTip( $mosLang->TXT_TIP_CONFIG10 . '</span>', $mosLang->TXT_TIP_CONFIG10_TITLE ); ?>
			</td>
		</tr>
		<tr>
			<td align="left" valign="top"><?php echo $mosLang->FIELD_REGISTRATION_OPTION; ?></td>
			<td align="left" valign="top">
				<input type="radio" name="vb_reg" value="1" <?php echo $config[0]->vb_reg == 1 ? 'checked="checked"' : '' ; ?>><?php echo $mosLang->FIELD_VALUE_VBUNREG; ?>
				<input type="radio" name="vb_reg" value="0" <?php echo $config[0]->vb_reg == 0 ? 'checked="checked"' : '' ; ?>><?php echo $mosLang->FIELD_VALUE_VBREG; ?>
				&nbsp;&nbsp;
				<?php echo mosToolTip( $mosLang->TXT_TIP_CONFIG11 . '</span>', $mosLang->TXT_TIP_CONFIG11_TITLE ); ?>
			</td>
		</tr>

		

		<?php

		if (isCommunityLogin()) { ?>
		<tr>
			<td align="left" valign="top"><?php echo $mosLang->FIELD_CB_LOGIN; ?></td>
			<td align="left" valign="top">
				<input type="radio" name="cb_login" value="0" <?php echo $cbprofile == 0 ? 'checked="checked"' : '' ; ?>>No
				<input type="radio" name="cb_login" value="1" <?php echo $cbprofile == 1 ? 'checked="checked"' : '' ; ?>>Yes
				&nbsp;&nbsp;
			</td>
		</tr>
		<?php } ?>

		<tr>
			<td align="left"><?php echo $mosLang->FIELD_VB_REDIRECT; ?></td>
			<td align="left">
				<?php echo $configs['vb_redirect']; ?>&nbsp;&nbsp;
				<?php echo mosToolTip( $mosLang->TXT_TIP_CONFIG12 . '</span>', $mosLang->TXT_TIP_CONFIG12_TITLE ); ?>
			</td>
		</tr>

    	<tr><td colspan="2">&nbsp;</td></td></tr>

		

		<tr><td colspan="2">&nbsp;</td></td></tr>
		<tr>
		<td colspan=2>
			<?php echo $mosLang->MSG_VB_VERSION_IS." <b>".vBVERSION($config[0]->vb_useextdb,$config[0]->vb_dbhost,$config[0]->vb_dbuser,$config[0]->vb_dbpass,$config[0]->vb_dbname,$config[0]->vb_prefix)."</b>"; ?>
        </tr>
		<tr>
	
			<td colspan=2>
			<?php echo $mosLang->MSG_MAMBO_VB_VERSION_IS." ".readComVersion(); ?>
			</td>
		</tr>

		</table>

		</td>
		</tr>

		</table>

		<?php $tabs->endTab(); ?>
		<?php $tabs->startTab( $mosLang->TAB_INSTALL_MANAGER_TITLE, 'general-page' ); ?>
		<table width="100%" border="0" cellpadding="2" cellspacing="2">
		
		<tr>
			<td colspan=2><b><?php echo $mosLang->HEADER_INSTALLATION_CHECKLIST; ?></b></td>
		</tr>
		<tr>
    	<td colspan="2">&nbsp;</td>
    	</tr>
    	
    	<?php if (!$config[0]->vb_useextdb == 1 ){ ?>
		<tr>
			<td align="right"><?php echo isVBInstalled($config[0]->vb_useextdb,$config[0]->vb_dbhost,$config[0]->vb_dbuser,$config[0]->vb_dbpass,$config[0]->vb_dbname,$config[0]->vb_prefix) ? paintGreen($mosLang->MSG_INSTALLED) : paintRed($mosLang->MSG_NOT_INSTALLED) ;?></td>
			<td><?php echo $mosLang->TEXT_INSTALL_VB; ?></td>
		</tr>
		<?php } else { ?>
		<tr>
			<td align="right"><?php echo isVBInstalled($config[0]->vb_useextdb,$config[0]->vb_dbhost,$config[0]->vb_dbuser,$config[0]->vb_dbpass,$config[0]->vb_dbname,$config[0]->vb_prefix) ? paintGreen($mosLang->MSG_INSTALLED) : paintRed($mosLang->MSG_NOT_INSTALLED) ;?></td>
			<td><?php echo $mosLang->TEXT_INSTALL_VBEXT."&nbsp;<b>".$config[0]->vb_dbname."</b>"; ?></td>
		</tr>
		
		<?php } ?>
		<tr>
			<td align="right"><?php echo isVBModInstalled() ? paintGreen($mosLang->MSG_INSTALLED) : paintRed($mosLang->MSG_NOT_INSTALLED) ;?></td>
			<td><?php echo $mosLang->TEXT_INSTALL_VB_MOD; ?></td>
		</tr>
		<tr>
		    <td align="right"><?php echo isConfigPatched($config) ? paintGreen($mosLang->MSG_DONE) :patchConfig($config); ;?></td>
			<td><?php echo $mosLang->TEXT_PATCH_CONFIG_FILE; ?></td>
						
		</tr>
		<?php 
		if ($config[0]->wrapped == 1 ){
		    ?>
		<tr>
			<td align="right"><?php echo isThemePatched($cur_template) ? paintGreen($mosLang->MSG_DONE) : paintRed($mosLang->MSG_NOT_INSTALLED) ;?></td>
			<td><?php echo $mosLang->TEXT_PATCH_MAMBO_FILE.'&nbsp;<b>'. $cur_template.'</b>'; ?></td>
		</tr>
		<?php } ?>
		<tr>
    	<td colspan="2">&nbsp;</td>
    	</tr>
		<tr>
			<td colspan=2><b><?php echo $mosLang->HEADER_INSTALLATION_CHECKUSER; ?></b></td>
		</tr>
		<tr>
    	<td colspan="2">&nbsp;</td>
    	</tr>
		<?php if (isset($_REQUEST['task']) == 'checksync') {
		    $sync_done = isMamboVBUserSync($config[0]->vb_prefix);
		    if ($sync_done) mosRedirect( "index2.php?option=$option", $mosLang->MSG_VB_MAMBO_IN_SYNC);
		 } ?>

		<tr>
			<td align="right"><?php echo $config[0]->check_user  ? "[<b><a href=\"".$mosConfig_live_site."/administrator/index2.php?option=com_vbridge&task=checksync\">".$mosLang->MSG_VERIFY."</a></b>] " . paintGreen($mosLang->MSG_DONE) : "<b><a href=\"".$mosConfig_live_site."/administrator/index2.php?option=com_vbridge&task=sync\">".$mosLang->MSG_SYNC."</a></b>" ;?></td>
			<td><?php echo $mosLang->TEXT_SYNC_MAMBO_VB; ?></td>
		</tr>
		</table>
		<?php $tabs->endTab(); ?>
		<?php $tabs->startTab( $mosLang->TAB_CREDITS_TITLE, 'general-page' ); ?>
		<table width="100%" border="0" cellpadding="2" cellspacing="2">
		<tr>
			<td valign="top"><b><?php echo $mosLang->HEADER_CREDITS; ?></b></td>
			<td><img src="<?php echo $mosConfig_live_site; ?>/administrator/components/com_vbridge/vbridge.gif" alt="" /></td>
		</tr>
		<tr>
    	<td colspan="2">&nbsp;</td>
    	</tr>
		<tr>
    		<td valign="top"><b><?php echo $mosLang->HEADER_CREDITS_DEVELOPER; ?></b></td>
    		<td><b>Leaddeveloper:</b><br />
    		Marko Schmuck aka Predator<br /><br />
    		<b>Contributions:</b><br />
    		rsuplido, vivpuri
    	</tr>
    	<tr>
    	<td colspan="2">&nbsp;</td>
    	</tr>
    	<tr>
    		<td valign="top"><b><?php echo $mosLang->HEADER_CREDITS_DOCUMENTATION; ?></b></td>
    		<td>kenmcd</td>
    	</tr>
    	<tr>
    	<td colspan="2">&nbsp;</td>
    	</tr>
    	<tr>
    		<td valign="top"><b><?php echo $mosLang->HEADER_CREDITS_TRANSLATOR; ?></b></td>
    		<td><b>Spanish:</b><br />
    	    aoricci2<br />
    	    <b>Italian:</b><br />
    	    Andrea "StaRise" Brandi<br />
    	    <b>Turkish:</b><br />
    	    Deniz Senturk aka Anarchy</td>
    	</tr>
    	<tr>
    	<td colspan="2">&nbsp;</td>
    	</tr>
    	<tr>
    		<td valign="top"><b><?php echo $mosLang->HEADER_CREDITS_TESTER; ?></b></td>
    	    <td>
    	    <b>The sleepless bughunters:</b><br />
    	    vivpuri, rsuplido, justinkwaugh, kenmcd, stefaandk, odsign, bugfaceuk</td>
		</tr>
		<tr>
    	<td colspan="2">&nbsp;</td>
    	</tr>
    	<tr>
    		<td valign="top"><b><?php echo $mosLang->HEADER_CREDITS_MISC; ?></b></td>
    		 <td><b>External Code use:</b><br />
    		 Some code from mambull based on hotnuts21<br />
    		 <b>Inspirated by:</b><br />
    		 cowboy1015 and his SMF Integration<br />
    		 Theodore Hildebrandt and his adaption of the Simpleboard dicussionbot<br />
    		 mic`s and his mossmfdiscuss.btn.php
    		 </td>
    	</tr>
    	<tr>
    	<td colspan="2">&nbsp;</td>
    	</tr>
    	<tr>
    		<td valign="top"><b><?php echo $mosLang->HEADER_CONTACT_MISC; ?></b></td>
    		 <td><b>BUGTRACKER:</b> <a href="http://developer.joomla.org/sf/tracker/do/listArtifacts/projects.vbridge/tracker.bugs" target="_blank">
    		 http://developer.joomla.org/sf/tracker/do/listArtifacts/projects.vbridge/tracker.bugs</a><br />
    		 <b>JOOMLA FORUM:</b> <a href="http://forum.joomla.org/index.php/board,174.0.html" target="_blank">
    		 http://forum.joomla.org/index.php/board,174.0.html</a><br />
    		 <b>JOOMLA DEVELOPER:</b> <a href="http://developer.joomla.org/sf/sfmain/do/viewProject/projects.vbridge" target="_blank">
    		 http://developer.joomla.org/sf/sfmain/do/viewProject/projects.vbridge</a><br />
    		 <br /><br /> 
       		 </td> 
    	</tr>
    	<tr>
    	<td colspan="2">&nbsp;</td>
    	</tr>
		</table>
		<?php $tabs->endTab();?>
    	<?php $tabs->endPane();?>
    	<input type="hidden" name="option" value="<?php echo $option; ?>" />
    	<input type="hidden" name="act" value="<?php echo $act; ?>" />
    	<input type="hidden" name="task" value="" />
    	<input type="hidden" name="boxchecked" value="0" />
    </form>

<?php
    }

}
?>