<?php
/** 
  * @version $Id: english.php,v 1.0 2005/07/07 01:27:11 predator Exp $ 
  * @Package Joomla! vBridge 
  * @copyright (C) 2005 wh-solution.com 
  * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL 
  */

class JoomlaVBRIDGELanguage {

## MAIN COMPONENT ADMIN PAGE GEADER
##
var $HEADER_MAIN = 'Joomla! vBulletin Bridge Configuration';

## TABS
##
var $TAB_CONFIGURATION_TITLE 		= "Configuration";
var $TAB_REGISTRATION_TITLE 		= "Registration";
var $TAB_INSTALL_MANAGER_TITLE 		= "Installation";
var $TAB_USER_MANAGER_TITLE 		= "User Manager";
var $TAB_LANGUAGE_TITLE 			= "Language";
var $TAB_CREDITS_TITLE 			    = "Credits";

## CONFIGURATION TAB CONSTANTS
##
var $FIELD_VB_PATH_ABSOLUT			= "vBulletin Absolute Path:";
var $FIELD_VB_URL_ABSOLUT			= "vBulletin URL:";
var $FIELD_VB_DB_HOST   		    = "vBulletin Database Host:";
var $FIELD_VB_DB_USER			    = "vBulletin Database User:";
var $FIELD_VB_DB_PASS			    = "vBulletin Database Password:";
var $FIELD_VB_DB_NAME			    = "vBulletin Database Name:";
var $FIELD_VB_DB_PREFIX			    = "vBulletin Database Prefix:";
var $FIELD_VB_COOKIE_PREFIX			= "vBulletin Cookie Prefix:";
var $FIELD_VB_LICENSE			    = "vBulletin License:";
var $FIELD_MOS_DB_PREFIX			= "Joomla! Database Prefix:";
var $FIELD_INTEGRATION_OPTION 		= "Integration Mode:";
var $FIELD_REGISTRATION_OPTION 		= "Registration Mode:";
var $FIELD_EXISTING_VB				= "Existing vBulletin With User Data?:";
var $FIELD_HIDE_EMAIL				= "Hide emails in vBulletin profile on sync:";
var $FIELD_CB_LOGIN 				= "Redirect vBulletin profile link to Community Builder:";
var $FIELD_VERSION_INFO				= "Version Info:";
var $FIELD_VB_REDIRECT				= "Always redirect to forum on login:";
var $FIELD_VB_USEEXTDB				= "Use other Database for vBulletin:";

var $FIELD_VALUE_WRAPPED 			= "Wrapped";
var $FIELD_VALUE_UNWRAPPED 			= "Unwrapped";
var $FIELD_VALUE_VBREG   			= "Use vBulletin";
var $FIELD_VALUE_VBUNREG 			= "Use Joomla!";

var $HEADER_CONFIG_SETTINGS		    = "CONFIGURATION SETTINGS:";
var $HEADER_BEHAV_SETTINGS		    = "BEHAVIOUR SETTINGS:";
var $HEADER_INSTALLATION_CHECKLIST	= "INSTALLATION CHECKLIST:";
var $HEADER_INSTALLATION_CHECKUSER	= "SYNCHRONIZE / IMPORT VBULLETIN USER:";
var $HEADER_CREDITS_DEVELOPER      	= "vBRIDGE DEVELOPER:";
var $HEADER_CREDITS                 = "vBRIDGE CREDIT PAGE";
var $HEADER_CREDITS_DOCUMENTATION  	= "vBRIDGE DOCUMENTATION:";
var $HEADER_CREDITS_TRANSLATOR     	= "vBRIDGE TRANSLATORS:";
var $HEADER_CREDITS_TESTER         	= "vBRIDGE TESTER:";
var $HEADER_CREDITS_MISC          	= "THANKS TO THE FOLLOWING:";
var $HEADER_CONTACT_MISC          	= "HOW TO CONTACT:";

var $MSG_INSERTED					= "inserted";
var $MSG_INSTALLED					= "installed";
var $MSG_VERIFY						= "verify";
var $MSG_IMPORT						= "Import";
var $MSG_NOT_INSTALLED				= "not installed";
var $MSG_NOT_PUBLISHED				= "not published";
var $MSG_SYNC						= "click to sync";
var $MSG_PATCH						= "click to patch";
var $MSG_APPLY						= "apply";
var $MSG_DONE						= "done";
var $MSG_INCORRECT_PREFIX			= "(incorrect prefix)";
var $MSG_INCORRECT_PATH				= "(incorrect path)";
var $MSG_VB_VERSION_IS				= "Your vBulletin version is";
var $MSG_MAMBO_VB_VERSION_IS		= "Your Joomla! vBulletin Bridge version is";
var $MSG_LATEST_MAMBO_VB_VERSION_IS= "Latest Joomla! vBulletin Bridge Version is";
var $MSG_VB_MAMBO_IN_SYNC			= "VB and Joomla! users in sync.";
var $MSG_VB_TEMP_IN_SYNC			= "VB Templates are patched.";


var $MSG_MAMBO_CACHE_DIR_IS			= "Joomla! cache directory";
var $MSG_MAMBO_INDEX_FILE_IS		= "Joomla! index file";
var $MSG_MAMBO_MAMBO_FILE_IS		= "Joomla! file";
var $MSG_MAMBO_PATH_IS 				= "Joomla! main path";

var $MSG_ERR_MAMBO_INDEX_NOT_WRITEABLE 	= "Joomla! main path or index.php is not writeable!";
var $MSG_ERR_MAMBO_NOT_WRITEABLE 	    = "Joomla! main path or theme index.php is not writeable!";
var $MSG_ERR_CONF_NOT_WRITEABLE 		= "Configuration file is not writeable!";
var $MSG_SETTINGS_SAVED 				= "Settings saved";
var $MSG_WRITABLE 						= 'is writeable';
var $MSG_NOT_WRITABLE 					= 'is not writeable';
var $MSG_SUCCESS						= 'Success';
var $MSG_FAILED							= 'Failed';
var $MSG_CANNOT_COPY_USER_TO_MAMBO		= "Warning: You are logged to VB but not in Joomla!. Cannot load user to Joomla!.";
var $MSG_CANNOT_COPY_USER_TO_VB		    = "Warning: You are logged to Joomla! but not in VB. Cannot load user to VB.";

var $TEXT_INSTALL_VB				= "Install vBulletin on the same database as Joomla!.";
var $TEXT_INSTALL_VBEXT				= "vBulletin is installed in database:";
var $TEXT_INSTALL_VB_MOD			= "Install vBridge Mod Login using the Modules Installer.";
var $TEXT_PATCH_CONFIG_FILE   		= "Patch vBulletin includes/config.php file.";
var $TEXT_PATCH_LOGIN_FILE  		= "Patch vBulletin login.php file.";
var $TEXT_PATCH_PROFILE_FILE  		= "Patch vBulletin profile.php file.";
var $TEXT_PATCH_REGISTER_FILE  		= "Patch vBulletin register.php file.";
var $TEXT_PATCH_SHOWTHREAD_FILE		= "Patch vBulletin showthread.php file.";
var $TEXT_PATCH_FUNCTION_FILE	    = "Patch vBulletin includes/functions.php file.";
var $TEXT_PATCH_ADMINUSER_FILE	    = "Patch vBulletin admincp/user.php file.";
var $TEXT_PATCH_MAMBO_FILE	        = "Patch index.php from the current mambo theme:";
var $TEXT_PATCH_MAMBO_VB            = "Patch vBulletin Templates";
var $TEXT_SYNC_MAMBO_VB			    = "Synchronize Joomla! and vBulletin users.";
var $TEXT_IMPORTANT					= "IMPORTANT:";
var $TEXT_IMPORTANT_MSG				= "Uncheck only if you are using this for a fresh vBulletin install!";
var $TEXT_IMPORT_USER               = "the vBulletin User to Joomla!. <br />NOTE: ALL JOOMLA USER WILL BE DELETED USE ONLY IF YOU ARE USING A FRESH MAMBO INSTALLATION";
## COMMON FOR ALL LANGUAGES
##
var $VB_ISO 								= 'iso-8859-1';
var $VB_DATE_FORMAT_LC 					= 'A, d. B Y'; //Verwendet das PHP strftime Format
var $VB_DATE_FOMAT_SHORT 					= ' M Y'; // short date
var $VB_DATE_FORMAT_LONG 					= 'd.m.Y H:i'; // use PHP strftime Format, more info at http://php.net

## COMMON FOR VBRIDGEBOT
##
var $VB_BOT_COMMENTS				= "Comment(s):";
var $VB_BOT_WRITECOMMENT			= "Write comment:";
var $VB_JOINDATE        			= "Joindate:";
var $VB_POSTS           			= "Posts:";
var $COMMENT_ONLYREGISTERED         = "Only registered users can write comments.<br />Please login or register.";

## PATCHHANDLER ##


var $TXT_VB154 = "Proceed";
var $TXT_VB160 = "Modification file was extracted, but this modification also comes with a PHP script which should be executed before it will work";
var $TXT_VB161 = "Run";
var $TXT_VB163 = "Read";
var $TXT_VB173 = "Script output:";
var $TXT_VB174 = "Additional notes";
var $TXT_VB175 = "Instruction/Additional notes file";
var $TXT_VB180 = "List files in Patch";
var $TXT_VB181 = "Files in archive";
var $TXT_VB182 = "Patch Get";
var $TXT_VB183 = "Patch servers";
var $TXT_VB184 = "Browse";
var $TXT_VB185 = "Add server";
var $TXT_VB186 = "Server name";
var $TXT_VB187 = "URL";
var $TXT_VB189 = "No Patchs yet.";
var $TXT_VB190 = "Download";
var $TXT_VB192 = "Patch downloaded successfully";
var $TXT_VB193 = "Patch has been downloaded successfully";
var $TXT_VB198 = "Patch Manager";
var $TXT_VB159b = "Apply Patch";
var $TXT_VB162b = "Modification file was extracted, this modification also comes with a SQL file with modifications the database needs.  It is a good idea to run it.";
var $TXT_VB163b = "Run";
var $TXT_VB174b = "SQL Queries";
var $TXT_VB189b = "No mods currently installed";
var $TXT_VB188b = "Browse installed mods";
var $TXT_VB198b = "Uninstall";
var $TXT_VB198d = "Delete Mod List";
var $TXT_VB198h = "Sorry, you server has PHP set to SAFE MODE.  This feature is not compatible with SAFE MODE.  Sorry.";
var $TXT_VB198i = "Let me try anyway.";

var $TXT_PATCH1 = "Patch Manager";
var $TXT_PATCH2 = "Main Menu";
var $TXT_PATCH3 = "Browse Patchs";
var $TXT_PATCH4 = "Create a New Patch";
var $TXT_PATCH5 = "Download New Patches";
var $TXT_PATCH6 = "View and Remove Installed Patches";
var $TXT_PATCH7 = "Modification Patches";

var $TXT_PATCH10 = "Unknown Patchs";
var $TXT_PATCH11 = "Apply Patch";

var $TXT_PATCH14 = "List Files";
var $TXT_PATCH15 = "Remove";
var $TXT_PATCH24 = "Patch Type";
var $TXT_PATCH34 = "Archiving";
var $TXT_PATCH37 = "Extracting";
var $TXT_PATCH39 = "The avatars have been extracted, you can now use them.";
var $TXT_PATCH41 = "The language pack has been extracted, you can now use it (by setting it in your settings).";

var $TXT_PACMAN2 = "Patch Name";
var $TXT_PACMAN3 = "Version";
var $TXT_PACMAN4 = "Author";
var $TXT_PACMAN6 = "Author\"s Homepage";
var $TXT_PACMAN8 = "No Description Given";
var $TXT_PACMAN9 = "Description";
var $TXT_PACMAN10 = "Location of file";
var $TXT_PACMAN11 = "Action";

var $TXT_PATCH_installed_key = "Installed patches:";
var $TXT_PATCH_installed_current = "current version";
var $TXT_PATCH_installed_old = "older version";
var $TXT_PATCH_installed_warning1 = "This Patch is already installed, and no upgrade was found!";
var $TXT_PATCH_installed_warning2 = "You should uninstall the old version first to avoid problems, or ask the author to create an upgrade from your old version.";
var $TXT_PATCH_installed_warning3 = "Please remember to always make regular backups of your sources and database before installing patches, especially beta versions.";
var $TXT_PATCH_installed_extract = "Extracting Patch";
var $TXT_PATCH_installed_done = "The Patch was installed successfully.  You should now be able to use whatever functionality it adds or changes; or not be able to use functionality it removes.";

var $TXT_PATCHs_latest = "Latest Patchs";
var $TXT_PATCHs_latest_fetch = "Attempting to fetch the most popular and recent Patchs from www.simplemachines.org...";

var $TXT_PATCH_upgrade = "Upgrade";
var $TXT_PATCH_install_readme = "Installation Readme";
var $TXT_PATCH_install_type = "Type";
var $TXT_PATCH_install_action = "Action";
var $TXT_PATCH_install_desc = "Description";
var $TXT_PATCH42 = "Install Actions";
var $TXT_PATCH43 = "for archive";
var $TXT_PATCH44 = "Installing this Patch will perform the following actions:";
var $TXT_PATCH45 = "The Patch you are trying to download or install is either corrupt or not compatible with this version of vBulletin.";
var $TXT_PATCH50 = "Create";
var $TXT_PATCH51 = "Move";
var $TXT_PATCH52 = "Delete";
var $TXT_PATCH53 = "Extract";
var $TXT_PATCH54 = "File";
var $TXT_PATCH55 = "Tree";
var $TXT_PATCH56 = "Execute Modification";
var $TXT_PATCH57 = "Execute Code";

var $TXT_PATCH_bytes = "bytes";

var $TXT_PATCH_action_missing = "<b style='color: red;'>File not found</b>";
var $TXT_PATCH_action_error = "<b style='color: red;'>Modification parse error</b>";
var $TXT_PATCH_action_failure = "<b style='color: red;'>Failure</b>";
var $TXT_PATCH_action_success = "<b>Success</b>";

var $TXT_PATCH_uninstall_actions = "Uninstall Actions";
var $TXT_PATCH_uninstall_done = "The Patch has been uninstalled, it should no longer take effect.";
var $TXT_PATCH_uninstall_cannot = "This Patch cannot be uninstalled, because there is no uninstaller!<br /><br />Please contact the mod author for more information.";
var $TXT_PATCH_package_cant_uninstall ="Can not uninstall";

var $TXT_PATCH_install_options = "Installation Options";
var $TXT_PATCH_install_options_ftp_why = "Using FTP is the easiest way to get around having to manually chmod the files writable by FTP yourself for the Patch manager to work.<br />Here you can set the default values for some fields.";
var $TXT_PATCH_install_options_ftp_server = "FTP Server";
var $TXT_PATCH_install_options_ftp_port = "Port";
var $TXT_PATCH_install_options_ftp_user = "Username";
var $TXT_PATCH_install_options_make_backups = "Create Backup versions of replaced files with a tilda (~) on the end of their names.";

// For a break, use \\n instead of <br />... and don"t use entities.
var $TXT_PATCH_delete_bad = "The Patch you are about to delete is currently installed!  If you delete it, you may not be able to uninstall it later.\\n\\nAre you sure?";

var $TXT_PATCH_examine_file = "View file in Patch";
var $TXT_PATCH_file_contents = "Contents of file";

var $TXT_PATCH_upload_title = "Upload a Patch";
var $TXT_PATCH_upload_select = "Patch to Upload";
var $TXT_PATCH_upload = "Upload";
var $TXT_PATCH_upload_error_supports = "The Patch manager currently allows only these file types: ";
var $TXT_PATCH_upload_error_broken = "The Patch you tried to upload either is not a valid Patch or has become corrupted.";
var $TXT_PATCH_uploaded_success = "Patch uploaded successfully";
var $TXT_PATCH_uploaded_successfully = "The Patch has been uploaded successfully";

var $TXT_PATCH_modification_malformed = "Malformed or invalid modification file.";
var $TXT_PATCH_modification_missing = "The file could not be found.";
var $TXT_PATCH_no_zlib = "Sorry, your PHP configuration doesn\"t have support for <b>zlib</b>.  Without this, the Patch manager cannot function.  Please contact your host about this for more information.";

var $TXT_TIP_CONFIG01_TITLE 	= "vBulletin Absolute Path";
var $TXT_TIP_CONFIG01  = "The absolute Path of your vBulletin Board i.e. /www/mambo/forum  without trailing \'/\'";
var $TXT_TIP_CONFIG02  = "The absolute Path of your vBulletin Board i.e. /www/mambo/forum  without trailing \'/\' is not correct please add the correct value.";
var $TXT_TIP_CONFIG03_TITLE 	= "vBulletin URL";
var $TXT_TIP_CONFIG03  = "The URL of your vBulletin Board i.e. http://www.domain.com/forum  without trailing \'/\'";
var $TXT_TIP_CONFIG04_TITLE 	= "vBulletin Database Prefix";
var $TXT_TIP_CONFIG04  = "The database prefix of your vBulletin Board i.e. mos_vb_";
var $TXT_TIP_CONFIG05  = "The database prefix of your vBulletin Board i.e. mos_vb_ is not correct please add the correct value. Both databases must merge into the same database";
var $TXT_TIP_CONFIG06_TITLE 	= "vBulletin License";
var $TXT_TIP_CONFIG06  = "Enter your vBulletin license here i.e. VBF9999999. Beware only use your own license";
var $TXT_TIP_CONFIG07_TITLE 	= "vBulletin Cookie Prefix";
var $TXT_TIP_CONFIG07  = "Cookie Prefix of your vBulletin Board. Default is \'bb\' and will be catch correctly if the absolute Path is set.";
var $TXT_TIP_CONFIG08  = "The absolute Path of your vBulletin Board i.e. /www/mambo/forum  without trailing \'/\' is not correct please add the correct value. Otherwise this value will not be correct.";

var $TXT_TIP_CONFIG10_TITLE 	= "Integration Option";
var $TXT_TIP_CONFIG10 			= "This is - maybe - one of the most important settings here! Here you have to define if vBulletin will be integrated (wrapped) within Joomla! or not (unwrapped).";
var $TXT_TIP_CONFIG11_TITLE 	= "Registration Option";
var $TXT_TIP_CONFIG11 			= "This is also a important settings here! You can define if you want to use the vBulletin registration or the Joomla! registration.";
var $TXT_TIP_CONFIG12_TITLE 	= "Redirection Option";
var $TXT_TIP_CONFIG12 			= "Setting this to YES means always redirect to the forum when you login.";

}
?>