<?php
/** 
  * @version $Id: english.php,v 1.0 2005/07/07 01:27:11 predator Exp $ 
  * @Patch com_vbridge 
  * @copyright (C) wh-solution.com 
  * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL 
  */

class JoomlaVBRIDGELanguage {

## MAIN COMPONENT ADMIN PAGE GEADER
##
var $HEADER_MAIN = 'Mambo vBulletin Bridge Configuration';

## TABS
##
var $TAB_CONFIGURATION_TITLE 		= "Configuracion";
var $TAB_REGISTRATION_TITLE 		= "Registracion";
var $TAB_INSTALL_MANAGER_TITLE 		= "Instalacion";
var $TAB_USER_MANAGER_TITLE 		= "Administracion de Usuario";
var $TAB_LANGUAGE_TITLE 			= "Language";
var $TAB_CREDITS_TITLE 			    = "Creditos";

## CONFIGURATION TAB CONSTANTS
##
var $FIELD_VB_PATH_ABSOLUT			= "vBulletin ruta Absoluta:";
var $FIELD_VB_URL_ABSOLUT			= "vBulletin URL:";
var $FIELD_VB_DB_PREFIX			    = "vBulletin Prefijo de la Base de Datos:";
var $FIELD_VB_COOKIE_PREFIX			= "vBulletin Prefijo de Cookie:";
var $FIELD_VB_LICENSE			    = "vBulletin Licencia:";
var $FIELD_MOS_DB_PREFIX			= "Mambo Prefijo de la Base de Datos:";
var $FIELD_INTEGRATION_OPTION 		= "Modo de Integracion:";
var $FIELD_REGISTRATION_OPTION 		= "Modo de Registracion:";
var $FIELD_EXISTING_VB				= "Existen Usuarios en Vbulletin con datos?:";
var $FIELD_HIDE_EMAIL				= "Ocultar emails en el perfil de vBulletin para sync:";
var $FIELD_CB_LOGIN 				= "Redireccionar el perfil de vBulletin a Community Builder:";
var $FIELD_VERSION_INFO				= "Version Info:";
var $FIELD_VB_REDIRECT				= "Siempre redireccionar al foro cuando inicia secion:";

var $FIELD_VALUE_WRAPPED 			= "Embebido";
var $FIELD_VALUE_UNWRAPPED 			= "no Embebido";
var $FIELD_VALUE_VBREG   			= "Usar vBulletin";
var $FIELD_VALUE_VBUNREG 			= "Usar Mambo";

var $HEADER_CONFIG_SETTINGS		    = "Ajustes de la Configuracion:";
var $HEADER_BEHAV_SETTINGS		    = "Ajustes de Comportamiento:";
var $HEADER_INSTALLATION_CHECKLIST	= "Lista de comprobacion de la Instalacion:";
var $HEADER_INSTALLATION_CHECKUSER	= "SYNCHRONIZE / IMPORT VBULLETIN USER:";
var $HEADER_CREDITS_DEVELOPER      	= "vBRIDGE Desarrollador:";
var $HEADER_CREDITS                 = "vBRIDGE Pagina de Creditos";
var $HEADER_CREDITS_DOCUMENTATION  	= "vBRIDGE DOCUMENTACION:";
var $HEADER_CREDITS_TRANSLATOR     	= "vBRIDGE TRADUCTORES:";
var $HEADER_CREDITS_TESTER         	= "vBRIDGE TESTER:";
var $HEADER_CREDITS_MISC          	= "GRACIAS A LOS SIGUIENTES:";

var $MSG_INSERTED					= "insertado";
var $MSG_INSTALLED					= "instalado";
var $MSG_VERIFY						= "verificado";
var $MSG_IMPORT						= "Importar";
var $MSG_NOT_INSTALLED				= "no instalado";
var $MSG_NOT_PUBLISHED				= "no publicado";
var $MSG_SYNC						= "click para sync";
var $MSG_PATCH						= "click para parchar";
var $MSG_APPLY						= "aplicado";
var $MSG_DONE						= "listo";
var $MSG_INCORRECT_PREFIX			= "(prefijo incorrecto)";
var $MSG_INCORRECT_PATH				= "(ruta incorrecta)";
var $MSG_VB_VERSION_IS				= "Su version de vBulletin es";
var $MSG_MAMBO_VB_VERSION_IS		= "Su version de Mambo vBulletin Bridge es";
var $MSG_LATEST_MAMBO_VB_VERSION_IS= "Su version de Ultimos Post Mambo vBulletin Bridge es";
var $MSG_VB_MAMBO_IN_SYNC			= "VB and Mambo usuarios estan sync.";

var $MSG_MAMBO_CACHE_DIR_IS			= "cache de directorio de Mambo";
var $MSG_MAMBO_INDEX_FILE_IS		= "Archivo index de Mambo";
var $MSG_MAMBO_MAMBO_FILE_IS		= "Archivo de Mambo";
var $MSG_MAMBO_PATH_IS 				= "Ruta de inicio de Mambo";

var $MSG_ERR_MAMBO_INDEX_NOT_WRITEABLE 	= "ruta de inicio de Mambo o index.php no se puede escribir!";
var $MSG_ERR_MAMBO_NOT_WRITEABLE 	    = "ruta de inicio de Mambo o tema index.php no se puede escribir!";
var $MSG_ERR_CONF_NOT_WRITEABLE 		= "El archivo de configuracion no se puede escribir!";
var $MSG_SETTINGS_SAVED 				= "Ajustes guardados";
var $MSG_WRITABLE 						= 'es escribible';
var $MSG_NOT_WRITABLE 					= 'no es escribible';
var $MSG_SUCCESS						= 'Exitoso';
var $MSG_FAILED							= 'Fallo';
var $MSG_CANNOT_COPY_USER_TO_MAMBO		= "Cuidado: Ud. inicio secion en VB pero no en Mambo. No se puede cargar al usuario en Mambo.";
var $MSG_CANNOT_COPY_USER_TO_VB		    = "Cuidado: Ud. inicio secion en Mambo pero no en VB. No se puede cargar al usuario en VB.";

var $TEXT_INSTALL_VB				= "Instale Vbulletin en la misma base de datos de Mambo.";
var $TEXT_INSTALL_VB_MOD			= "Instale vBridge Mod Loguin usando el instalador de Modulos.";
var $TEXT_PATCH_INIT_FILE   		= "Parchar archivo de vBulletin includes/init.php.";
var $TEXT_PATCH_LOGIN_FILE  		= "Parchar archivo de vBulletin login.php.";
var $TEXT_PATCH_PROFILE_FILE  		= "Parchar archivo de vBulletin profile.php.";
var $TEXT_PATCH_REGISTER_FILE  		= "Parchar archivo de vBulletin register.php.";
var $TEXT_PATCH_SHOWTHREAD_FILE		= "Parchar archivo de  vBulletin showthread.php.";
var $TEXT_PATCH_FUNCTION_FILE	    = "Parchar archivo de vBulletin includes/functions.php.";
var $TEXT_PATCH_ADMINUSER_FILE	    = "Parchar archivo vBulletin admincp/user.php.";
var $TEXT_PATCH_MAMBO_FILE	        = "Parchar archivo index.php del tema usado en mambo:";
var $TEXT_PATCH_MAMBO_VB            = "Parchar la plantilla usada en vBulletin";
var $TEXT_SYNC_MAMBO_VB			    = "Sincronizar usuarios de Mambo and vBulletin.";
var $TEXT_IMPORTANT					= "IMPORTANTE:";
var $TEXT_IMPORTANT_MSG				= "Desmarcar solamente si ud. esta usando para una nueva instalacion de vBulletin!";
var $TEXT_IMPORT_USER               = "los usuarios de vBulletin a Mambo. <br />NOTA: TODOS LOS USUARIOS DE MAMBO SERAN ELIMINADOS, USE SOLAMENTE SI UD ESTA USANDO UNA NUEVA INSTALACION DE MAMBO";
## COMMON FOR ALL LANGUAGES
##
var $VB_ISO 								= 'iso-8859-1';
var $VB_DATE_FORMAT_LC 					= 'A, d. B Y'; //Verwendet das PHP strftime Format
var $VB_DATE_FOMAT_SHORT 					= ' M Y'; // short date
var $VB_DATE_FORMAT_LONG 					= 'd.m.Y H:i'; // use PHP strftime Format, more info at http://php.net

## COMMON FOR VBRIDGEBOT
##
var $VB_BOT_COMMENTS				= "Comentario(s):";
var $VB_BOT_WRITECOMMENT			= "Comentario escrito:";
var $VB_JOINDATE        			= "dia de union:";
var $VB_POSTS           			= "Posts:";
var $COMMENT_ONLYREGISTERED         = "Solamnete usuarios registrados pueden escribir comentarios.<br />Por favor inicie secion o registrese.";

## PATCHHANDLER ##


var $TXT_VB154 = "Proceder";
var $TXT_VB160 = "El archivo de modificaci�n fue extra�do, pero esta modificaci�n tambi�n viene con una escritura de PHP que deba ser ejecutada antes de que trabaje";
var $TXT_VB161 = "Correr";
var $TXT_VB163 = "Leer";
var $TXT_VB173 = "Script de salida:";
var $TXT_VB174 = "Notas Adicionales";
var $TXT_VB175 = "Instrucciones/Archivo de notas adicionales";
var $TXT_VB180 = "lista de archivos en el Parche";
var $TXT_VB181 = "Archivos";
var $TXT_VB182 = "Obtenet el Patch";
var $TXT_VB183 = "Servidor del Patch";
var $TXT_VB184 = "Explorar";
var $TXT_VB185 = "Agregar servidorr";
var $TXT_VB186 = "Nombre de Servidor";
var $TXT_VB187 = "URL";
var $TXT_VB189 = "No Parchado aun.";
var $TXT_VB190 = "Descargar";
var $TXT_VB192 = "Parche Descargado satisfactoriamente";
var $TXT_VB193 = "Parche a sido Descargado satisfactoriamente";
var $TXT_VB198 = "Administrador de Parche";
var $TXT_VB159b = "Parche aplicado";
var $TXT_VB162b = "El archivo de modificaci�n fue extra�do, esta modificaci�n tambi�n viene con un archivo del SQL con modificaciones que la base de datos necesita.  Es una buena idea correrla.";
var $TXT_VB163b = "Correr";
var $TXT_VB174b = "Consultas SQL ";
var $TXT_VB189b = "Ningun mods Actualmente instalado";
var $TXT_VB188b = "Explorar mods instalados";
var $TXT_VB198b = "Desinstalar";
var $TXT_VB198d = "Borrar el Mod de la lista";
var $TXT_VB198h = "Disculpe, su servidor tiene PHP fijado al MODO SEGURO.  Esta caracter�stica no es compatible con MODO SEGURO. Disculpe.";
var $TXT_VB198i = "Dejeme intentarlo de todas formas.";

var $TXT_PATCH1 = "Administrador de Parche";
var $TXT_PATCH2 = "menu Principal";
var $TXT_PATCH3 = "Explorar Parches";
var $TXT_PATCH4 = "Crear un nuevo parche";
var $TXT_PATCH5 = "Descargar nuevos parches";
var $TXT_PATCH6 = "Ver y remover parches instalados";
var $TXT_PATCH7 = "Parches modificados";

var $TXT_PATCH10 = "Parche desconocido";
var $TXT_PATCH11 = "Aplicar parche";

var $TXT_PATCH14 = "Lista de archivos";
var $TXT_PATCH15 = "Remover";
var $TXT_PATCH24 = "Tipo de parche";
var $TXT_PATCH34 = "Archivando";
var $TXT_PATCH37 = "Extrayendo";
var $TXT_PATCH39 = "Los avatares an sido extraidos, ahora ud puede usarlos.";
var $TXT_PATCH41 = "El paquete de lenguaje a sido extraido, ahora ud puede usarlo (fijandolo en sus ajustes).";

var $TXT_PACMAN2 = "Nombre del parchee";
var $TXT_PACMAN3 = "Version";
var $TXT_PACMAN4 = "Autor";
var $TXT_PACMAN6 = "Autor\"s Homepage";
var $TXT_PACMAN8 = "Ninguna descripcion suminstrada";
var $TXT_PACMAN9 = "Descripcion";
var $TXT_PACMAN10 = "Locacion del archivo";
var $TXT_PACMAN11 = "Accion";

var $TXT_PATCH_installed_key = "Parches instalados:";
var $TXT_PATCH_installed_current = "Version Actual";
var $TXT_PATCH_installed_old = "version antigua";
var $TXT_PATCH_installed_warning1 = "Este parche est� instalado ya, y no se encontr� ninguna mejora!";
var $TXT_PATCH_installed_warning2 = "Ud deberia desinstalar la vieja version primero, para evitar problemas, o pregunte al autor para crear una mejora desde su verson antigua..";
var $TXT_PATCH_installed_warning3 = "Recuerde por favor hacer siempre resguardos regulares de sus fuentes y base de datos antes de instalar los parches, especialmente en versiones beta.";
var $TXT_PATCH_installed_extract = "Extrayendo el parche";
var $TXT_PATCH_installed_done = "El parche fue instalado con �xito.  Usted debe ahora poder utilizar cualquier funcionalidad de agregar o cambiar;  o no poder utilizar esta funcionalidad que quita.";

var $TXT_PATCHs_latest = "Ultimos Parches";
var $TXT_PATCHs_latest_fetch = "Intentando descargar el Parche m�s popular y m�s reciente de www.simplemachines.org...";

var $TXT_PATCH_upgrade = "Actualizacion";
var $TXT_PATCH_install_readme = "Instalacion leame";
var $TXT_PATCH_install_type = "Tipo";
var $TXT_PATCH_install_action = "Accion";
var $TXT_PATCH_install_desc = "Descripcion";
var $TXT_PATCH42 = "Instalar acciones";
var $TXT_PATCH43 = "para archivo";
var $TXT_PATCH44 = "La instalaci�n de este parche realizar� las acciones siguientes:";
var $TXT_PATCH45 = "El parche que usted est� intentando descargar o instalar es o esta corrompido o no es compatible con esta versi�n del vBulletin.";
var $TXT_PATCH50 = "Creaar";
var $TXT_PATCH51 = "Mover";
var $TXT_PATCH52 = "Borrar";
var $TXT_PATCH53 = "Extraer";
var $TXT_PATCH54 = "Archivo";
var $TXT_PATCH55 = "Arbol";
var $TXT_PATCH56 = "Ejecutar";
var $TXT_PATCH57 = "Ejecutar codigo";

var $TXT_PATCH_bytes = "bytes";

var $TXT_PATCH_action_missing = "<b style='color: red;'>Archivo no encontrado</b>";
var $TXT_PATCH_action_error = "<b style='color: red;'>Modificcacion en el error del analice</b>";
var $TXT_PATCH_action_failure = "<b style='color: red;'>Falta</b>";
var $TXT_PATCH_action_success = "<b>Exito</b>";

var $TXT_PATCH_uninstall_actions = "Desinstalar Acciones";
var $TXT_PATCH_uninstall_done = "El parche a sido desinstalado, esto no deberia tener mas efecto.";
var $TXT_PATCH_uninstall_cannot = "Este parche no puede ser desinstalado, porque no hay desinstalador!<br /><br />Entre en contacto por favor con el autor del mod para m�s informaci�n.";

var $TXT_PATCH_install_options = "Opciones de instalacion";
var $TXT_PATCH_install_options_ftp_why = "Uusar el ftp es la manera m�s f�cil de conseguir teniendo que manualmente modificar el chmod de los archivos para ser escribibles, por FTP usted mismo para el administrador del parche haga al trabajo.<br />Aqu� usted puede fijar los valores prefijados para algunos campos.";
var $TXT_PATCH_install_options_ftp_server = "Servidor de FTP";
var $TXT_PATCH_install_options_ftp_port = "Puerto";
var $TXT_PATCH_install_options_ftp_user = "Nomnre de usuario";
var $TXT_PATCH_install_options_make_backups = "Cree las versiones de resguardo de archivos substituidos con un tilda (~) en el final de sus nombres.";

var $TXT_PATCH_ftp_necessary = "Informacion requerida por el FTP";
var $TXT_PATCH_ftp_why = "Algunos de los archivos que este parche necesita modificar no son escribibles.  Esto necesita ser cambiada registrando en el ftp y chmoding los archivos";
var $TXT_PATCH_ftp_why_download = "Descargar los parches, el directorio de parches y los archivos en �l necesitan ser escribibles - y no est�n actualmente.  El administrador del parche puede utilizar su informaci�n del ftp para fijar esto.";
var $TXT_PATCH_ftp_server = "Servidor de FTP";
var $TXT_PATCH_ftp_port = "Puerto";
var $TXT_PATCH_ftp_username = "Nombre de usuario";
var $TXT_PATCH_ftp_password = "Contrase�a";
var $TXT_PATCH_ftp_path = "Camino local para vBulletin";

// For a break, use \\n instead of <br />... and don"t use entities.
var $TXT_PATCH_delete_bad = "�El parche que usted est� a punto de suprimir est� instalado actualmente!  �Si usted lo suprime, usted no puede volver a desinstalarlo  despues.\\n\\nEsta Ud seguro de esto?";

var $TXT_PATCH_examine_file = "Ver el archivo en el parche";
var $TXT_PATCH_file_contents = "Archivo de contenidos";

var $TXT_PATCH_upload_title = "Subir un parche";
var $TXT_PATCH_upload_select = "Parche a subir";
var $TXT_PATCH_upload = "Subir";
var $TXT_PATCH_upload_error_supports = "El Administrador del parche permite actualmente solamente estos tipos del archivo: ";
var $TXT_PATCH_upload_error_broken = "El parche que usted intent� subir no es un parche v�lido o ha sido corrompido.";
var $TXT_PATCH_uploaded_success = "Parche subido satisfactoriamente";
var $TXT_PATCH_uploaded_successfully = "El parche ha sido subido satisfactoriamente";

var $TXT_PATCH_modification_malformed = "Archivo de modificaci�n malformado o inv�lido.";
var $TXT_PATCH_modification_missing = "El archivo no pod�a ser encontrado.";
var $TXT_PATCH_no_zlib = "Disculpe, su configuraci�n de PHP no tiene ayuda para <b>zlib</b>.  Sin esto, el Adminsitrador del parche no puede funcionar.  Entre en contacto con su host sobre esto para m�s informaci�n.";

var $TXT_TIP_CONFIG01_TITLE 	= "Camino absoluto de vBulletin";
var $TXT_TIP_CONFIG01  = "El camino absoluto de su vBulletin Board i.e. /www/mambo/forum  sin poner \'/\'";
var $TXT_TIP_CONFIG02  = "El camino absoluto de su vBulletin Board i.e. /www/mambo/forum  sin poner \'/\' esto no es correcto, agregue los valores correctos.";
var $TXT_TIP_CONFIG03_TITLE 	= "vBulletin URL";
var $TXT_TIP_CONFIG03  = "La URL de su vBulletin Board i.e. http://www.domain.com/forum  sin poner \'/\'";
var $TXT_TIP_CONFIG04_TITLE 	= "Prefijo de la base de datos de vBulletin";
var $TXT_TIP_CONFIG04  = "El prefijo de la base de datos de su vBulletin Board i.e. mos_vb_";
var $TXT_TIP_CONFIG05  = "El prefijo de la base de datos de su vBulletin Board i.e. mos_vb_ no es correcto, agregue los valores correctos. Ambas bases de datos seran unidas en una sola";
var $TXT_TIP_CONFIG06_TITLE 	= "Licencia de vBulletin";
var $TXT_TIP_CONFIG06  = "Ingrese la licencia de su vBulletin aqui i.e. VBF9999999. Solamente use su licencia";
var $TXT_TIP_CONFIG07_TITLE 	= "Prefijo de las Cookies de vBulletin";
var $TXT_TIP_CONFIG07  = "Prefijo de las Cookies de su vBulletin Board. Por defecto es \'bb\' y deberia de tomarlas correctamente si el camino absoluto esta seteado.";
var $TXT_TIP_CONFIG08  = "El camino absoluto de su vBulletin Board i.e. /www/mambo/forum  sin poner \'/\' esto no es correcto, por favor agregue el valor correcto. De otra manera el valor no deberia de estar corecto.";

var $TXT_TIP_CONFIG10_TITLE 	= "Opcion de Integracion";
var $TXT_TIP_CONFIG10 			= "Esto es - quisas - �uno de los ajustes m�s importantes aqu�!  Aqu� usted tiene que definir si el vBulletin es integrado(embebido) con Mambo o no (embebido).";
var $TXT_TIP_CONFIG11_TITLE 	= "Opcion de registracion";
var $TXT_TIP_CONFIG11 			= "��ste es tambi�n un ajuste importante aqu�!  Usted puede definir si usted desea utilizar el registro del vBulletin o el registro de Mambo.";
var $TXT_TIP_CONFIG12_TITLE 	= "Opcion de redireccion";
var $TXT_TIP_CONFIG12 			= "Fijando esto a YES vuelve a dirigir siempre al foro cuando usted inicia secion.";

}
?>