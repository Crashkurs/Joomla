<?php
/**
  * @version $Id: english.php,v 1.0 2005/07/07 01:27:11 predator Exp $
  * @Patch com_vbridge
  * @copyright (C) wh-solution.com
  * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
  */

class JoomlaVBRIDGELanguage {

## MAIN COMPONENT ADMIN PAGE GEADER
##
var $HEADER_MAIN = 'Mambo vBulletin Kopru Ayarlari';

## TABS
##
var $TAB_CONFIGURATION_TITLE             = "Ayarlar";
var $TAB_REGISTRATION_TITLE               = "Kayit";
var $TAB_INSTALL_MANAGER_TITLE          = "Kurulum";
var $TAB_USER_MANAGER_TITLE              = "Kullanicilari Duzenle";
var $TAB_LANGUAGE_TITLE                     = "Dil";
var $TAB_CREDITS_TITLE                        = "Credits";

## CONFIGURATION TAB CONSTANTS
##
var $FIELD_VB_PATH_ABSOLUT            = "vBulletin Tam Dizini:";
var $FIELD_VB_URL_ABSOLUT            = "vBulletin URL:";
var $FIELD_VB_DB_PREFIX                = "vBulletin Veritabani Oneki:";
var $FIELD_VB_COOKIE_PREFIX            = "vBulletin Kurabiye Oneki:";
var $FIELD_VB_LICENSE                = "vBulletin Lisansi:";
var $FIELD_MOS_DB_PREFIX            = "Mambo Veritabani Oneki:";
var $FIELD_INTEGRATION_OPTION         = "Entegre Modu:";
var $FIELD_REGISTRATION_OPTION         = "Kayit Modu:";
var $FIELD_EXISTING_VB                = "Var olan Kullanici datali vBulletin?:";
var $FIELD_HIDE_EMAIL                = "sync esnasinda vBulletin profilindeki e-mailleri sakla:";
var $FIELD_CB_LOGIN                 = "vBulletin profil linkini Community Builder a yonlendir:";
var $FIELD_VERSION_INFO                = "Versiyon:";
var $FIELD_VB_REDIRECT                = "Login olduktan sonra her zaman foruma yonlendir:";

var $FIELD_VALUE_WRAPPED             = "mambo icinde";
var $FIELD_VALUE_UNWRAPPED             = "mambo disinda";
var $FIELD_VALUE_VBREG               = "vBulletin";
var $FIELD_VALUE_VBUNREG             = "Mambo";

var $HEADER_CONFIG_SETTINGS            = "KONFIGURASYON AYARLARI:";
var $HEADER_BEHAV_SETTINGS            = "DAVRANIS AYARLARI:";
var $HEADER_INSTALLATION_CHECKLIST    = "KURULUM KONTROL LISTESI:";
var $HEADER_CREDITS_DEVELOPER          = "vBRIDGE GELISTIRICISI:";
var $HEADER_CREDITS                 = "vBRIDGE CREDIT SAYFASI";
var $HEADER_CREDITS_DOCUMENTATION      = "vBRIDGE DOCUMENTATION:";
var $HEADER_CREDITS_TRANSLATOR         = "vBRIDGE CEVIRMENLERI:";
var $HEADER_CREDITS_TESTER             = "vBRIDGE TEST EDENLER:";
var $HEADER_CREDITS_MISC              = "TESEKKURU HAK EDENLER:";

var $MSG_INSERTED                    = "sokuldu";
var $MSG_INSTALLED                    = "kuruldu";
var $MSG_VERIFY                        = "dogrula";
var $MSG_IMPORT                        = "Iceri AL";
var $MSG_NOT_INSTALLED                = "yuklu degil";
var $MSG_NOT_PUBLISHED                = "basili degil";
var $MSG_SYNC                        = "sync icin tiklayin";
var $MSG_PATCH                        = "patch(yama) icin tiklayin";
var $MSG_APPLY                        = "uygula";
var $MSG_DONE                        = "tamam";
var $MSG_INCORRECT_PREFIX            = "(yanlis onek)";
var $MSG_INCORRECT_PATH                = "(yanlis dizin)";
var $MSG_VB_VERSION_IS                = "vBulletin versiyonunuz";
var $MSG_MAMBO_VB_VERSION_IS        = "Mambo vBulletin Kopru versiyonunuz";
var $MSG_LATEST_MAMBO_VB_VERSION_IS= "Son Mambo vBulletin Kopru versiyonu";
var $MSG_VB_MAMBO_IN_SYNC            = "sync icindeki VB ve Mambo kullanicilari";

var $MSG_MAMBO_CACHE_DIR_IS            = "Mambo cache dizini";
var $MSG_MAMBO_INDEX_FILE_IS        = "Mambo index dosyasi";
var $MSG_MAMBO_MAMBO_FILE_IS        = "Mambo dosyasi";
var $MSG_MAMBO_PATH_IS                 = "Mambo ana dizini";

var $MSG_ERR_MAMBO_INDEX_NOT_WRITEABLE     = "Mambo ana dizini veya index.php yazilabilir degil!";
var $MSG_ERR_MAMBO_NOT_WRITEABLE         = "Mambo ana dizini veya theme index.php yazilabilir degil!";
var $MSG_ERR_CONF_NOT_WRITEABLE         = "Configuration dosyasi yazilabilir degil!";
var $MSG_SETTINGS_SAVED                 = "Ayarlar Kaydedildi";
var $MSG_WRITABLE                         = 'yazilabilir';
var $MSG_NOT_WRITABLE                     = 'yazilabilir degil';
var $MSG_SUCCESS                        = 'Basari ile tamamlandi';
var $MSG_FAILED                            = 'Hata olsutu';
var $MSG_CANNOT_COPY_USER_TO_MAMBO        = "Dikkat: VB ye login oldunuz ama mamboya olmadiniz. Kullanici Mamboya tasinamiyor.";
var $MSG_CANNOT_COPY_USER_TO_VB            = "Dikkat: Mamboya login oldunuz ama VBye olmadiniz. Kullanici VBye tasinamiyor.";

var $TEXT_INSTALL_VB                = "vBulletini Mambo ile ayni veritabani uzerine kur.";
var $TEXT_INSTALL_VB_MOD            = "vBridge Mod Login'i Modules Installer ile kurun.";
var $TEXT_PATCH_INIT_FILE           = "vBulletin includes/init.php dosyasini yama.";
var $TEXT_PATCH_LOGIN_FILE          = "vBulletin login.php dosyasini yama.";
var $TEXT_PATCH_PROFILE_FILE          = "vBulletin profile.php dosyasini yama.";
var $TEXT_PATCH_REGISTER_FILE          = "vBulletin register.php dosyasini yama.";
var $TEXT_PATCH_SHOWTHREAD_FILE        = "vBulletin showthread.php dosyasini yama.";
var $TEXT_PATCH_FUNCTION_FILE        = "vBulletin includes/functions.php dosyasini yama.";
var $TEXT_PATCH_ADMINUSER_FILE        = "vBulletin admincp/user.php dosyasini yama.";
var $TEXT_PATCH_MAMBO_FILE            = "index.php yi simdiki mambo themesinden yama:";
var $TEXT_PATCH_MAMBO_VB            = "vBulletin Templatelerini yama";
var $TEXT_SYNC_MAMBO_VB                = "Mambo ve vBulletin kullanicilarini senkronize et.";
var $TEXT_IMPORTANT                    = "ONEMLI:";
var $TEXT_IMPORTANT_MSG                = "Bu checki sadece taze bir vBulletin kurulumu yapiyorsaniz kaldirin!";
var $TEXT_IMPORT_USER = "vBulletin Kullanicilari Mamboya. <br />NOT: BUTUN MAMBO KULLANICILARI SILINECEKTIR SADECE TAZE MAMBO KURULUMU YAPARKEN KULLANINIZ";
## COMMON FOR ALL LANGUAGES
##
var $VB_ISO                                 = 'iso-8859-1';
var $VB_DATE_FORMAT_LC                     = 'A, d. B Y'; //Verwendet das PHP strftime Format
var $VB_DATE_FOMAT_SHORT                     = ' M Y'; // short date
var $VB_DATE_FORMAT_LONG                     = 'd.m.Y H:i'; // use PHP strftime Format, more info at http://php.net

## COMMON FOR VBRIDGEBOT
##
var $VB_BOT_COMMENTS                = "Yorum(lar):";
var $VB_BOT_WRITECOMMENT            = "Yorum yaz:";
var $VB_JOINDATE                    = "Katilimgunu:";
var $VB_POSTS                       = "Mesajlar:";
var $COMMENT_ONLYREGISTERED         = "Sadece kayitli kullanicilar yorum yazabilir.<br />Lutfen login veya kayit olun.";

## PATCHHANDLER ##


var $TXT_VB154 = "Devam Et";
var $TXT_VB160 = "Modifikasyon dosyasi cikartildi, ama bu modifikasyon bir PHP script ile beraber geliyor calistirilmadan once yok silinmesi gereken bir script";
var $TXT_VB161 = "Calistir";
var $TXT_VB163 = "Oku";
var $TXT_VB173 = "Script randimani:";
var $TXT_VB174 = "Ek notlar";
var $TXT_VB175 = "Bilgi/Ek notlar dosyasi";
var $TXT_VB180 = "Yama daki dosyalari listele";
var $TXT_VB181 = "Arsivdeki dosyalar";
var $TXT_VB182 = "Yama indir";
var $TXT_VB183 = "Yama serverlari";
var $TXT_VB184 = "Goz at";
var $TXT_VB185 = "Server ekle";
var $TXT_VB186 = "Server adi";
var $TXT_VB187 = "URL";
var $TXT_VB189 = "Henuz yeni yama yok.";
var $TXT_VB190 = "Download";
var $TXT_VB192 = "Yama basari ile yuklendi";
var $TXT_VB193 = "Yama basari ile yuklenildi";
var $TXT_VB198 = "Yama Menajeri";
var $TXT_VB159b = "Yamayi uygula";
var $TXT_VB162b = "Modifikasyon dosyasi cikartildi, bu modifikasyon dosyasi databasein ihtiyaci olan bir SQL dosyasi ile geliyor. Bunu calistirmak iyi bir fikirdir.";
var $TXT_VB163b = "Calistir";
var $TXT_VB174b = "SQL Sorgulari";
var $TXT_VB189b = "Henuz kuurlu mod yok";
var $TXT_VB188b = "kurulu modlara bak";
var $TXT_VB198b = "Uninstall";
var $TXT_VB198d = "Mod Listesini Sil";
var $TXT_VB198h = "Uzgunuz serveriniz PHP yi GUVENLI MOD(SAFEMODE)a sokmus. Bu ozellik guvenli modla birlikte calismaz uzgunuz.";
var $TXT_VB198i = "Olsun denemek istiyorum.";

var $TXT_PATCH1 = "Yama Menajeri";
var $TXT_PATCH2 = "Ana Menu";
var $TXT_PATCH3 = "yamalara Goz At";
var $TXT_PATCH4 = "Yeni Bir Yama Olsutur";
var $TXT_PATCH5 = "Yeni yamalar indir";
var $TXT_PATCH6 = "Kurulu yamalari goruntule ve kaldir";
var $TXT_PATCH7 = "Modifikasyon Yamalari";

var $TXT_PATCH10 = "Bilinmeyen yamalar";
var $TXT_PATCH11 = "Yamayi Uygula";

var $TXT_PATCH14 = "Dosyalari Listele";
var $TXT_PATCH15 = "Kaldir";
var $TXT_PATCH24 = "Yama Tipi";
var $TXT_PATCH34 = "Arsivleniyor";
var $TXT_PATCH37 = "Cikartiliyor";
var $TXT_PATCH39 = "Avatarlar cikartildi, artik onlari kullanabilirsiniz.";
var $TXT_PATCH41 = "Dil paketi cikartildi, artik onu kullanabilirsiniz (ayarlardan ayarlayarak).";

var $TXT_PACMAN2 = "Yama Adi";
var $TXT_PACMAN3 = "Versiyon";
var $TXT_PACMAN4 = "Yazar";
var $TXT_PACMAN6 = "Yazar\"sin Sayfasi";
var $TXT_PACMAN8 = "Tanim verilmedi";
var $TXT_PACMAN9 = "Tanim";
var $TXT_PACMAN10 = "Dosyanin konumu";
var $TXT_PACMAN11 = "Aksiyon";

var $TXT_PATCH_installed_key = "Kurulu yamalar:";
var $TXT_PATCH_installed_current = "simdiki versiyon";
var $TXT_PATCH_installed_old = "eski versiyon";
var $TXT_PATCH_installed_warning1 = "Bu yama zaten yuklu, ve bir upgrade bulunamadi!";
var $TXT_PATCH_installed_warning2 = "Problemleri onlemek icin eski versiyonu kaldirmaniz gerekiyor, veya yama sahibinden bir upgrade(terfi) isteginde bulunabilirsiniz.";
var $TXT_PATCH_installed_warning3 = "Lutfen bir yama yuklemeden once yedekleme yapmayi unutmayiniz, ozellikle beta versiyonlarda.";
var $TXT_PATCH_installed_extract = "Yama cikartiliyor";
var $TXT_PATCH_installed_done = "Yama basari ile kuruldu. Su an yamanin ekledigi ozelligi kullanabilmeye veya degistirmeye hazirsiniz; veya kaldircacagi ozelligi kullananamamaya.";

var $TXT_PATCHs_latest = "Son Yamalar";
var $TXT_PATCHs_latest_fetch = "www.simplemachines.org dan en populer yamalar alinmaya calisiyor";

var $TXT_PATCH_upgrade = "Upgrade(Terfi)";
var $TXT_PATCH_install_readme = "Kurulum BeniOku";
var $TXT_PATCH_install_type = "Tip";
var $TXT_PATCH_install_action = "Aksiyon";
var $TXT_PATCH_install_desc = "Tanim";
var $TXT_PATCH42 = "Kurulum Aksiyonlari";
var $TXT_PATCH43 = "Arsiv icin";
var $TXT_PATCH44 = "Bu yamanin yuklenmesi assagidaki aksiyonlarin olusmasina sebep olacaktir:";
var $TXT_PATCH45 = "Yuklemeye calistiginiz yama bozuk veya vBulletin in bu versiyonu ile uyumsuz.";
var $TXT_PATCH50 = "Olustur";
var $TXT_PATCH51 = "Move";
var $TXT_PATCH52 = "Sil";
var $TXT_PATCH53 = "Cikart";
var $TXT_PATCH54 = "Dosya";
var $TXT_PATCH55 = "Tree";
var $TXT_PATCH56 = "Modifikasyonu Sil";
var $TXT_PATCH57 = "Kodu Sil";

var $TXT_PATCH_bytes = "bytes";

var $TXT_PATCH_action_missing = "<b style='color: red;'>Dosya bulunamadi</b>";
var $TXT_PATCH_action_error = "<b style='color: red;'>Modifikasyon parse erroru</b>";
var $TXT_PATCH_action_failure = "<b style='color: red;'>Basarisiz</b>";
var $TXT_PATCH_action_success = "<b>Basarili</b>";

var $TXT_PATCH_uninstall_actions = "Uninstall Aksiyonlari";
var $TXT_PATCH_uninstall_done = "yama silindi, artik gecersiz ve etkisizdir.";
var $TXT_PATCH_uninstall_cannot = "Bu yama silinemiyor, cunku uninstalleri yok!<br /><br />Lutfen mod un sahibi ile irtibata geciniz dha fazla bilgi icin.";

var $TXT_PATCH_install_options = "Kurulum Opsiyonlari";
var $TXT_PATCH_install_options_ftp_why = "Yama Menajeri icin dosylarin FTP den CHMOD lanmasi sizin icin en kolay yol olacaktir.<br />Buradan bazi varsayilan degerleri girebilirsiniz.";
var $TXT_PATCH_install_options_ftp_server = "FTP Server";
var $TXT_PATCH_install_options_ftp_port = "Port";
var $TXT_PATCH_install_options_ftp_user = "Kullanici Adi";
var $TXT_PATCH_install_options_make_backups = "Yerine yerlestirilmis dosyalarin sonuna tilda (~) koyarak yedekleri olusturulsun .";

// For a break, use \\n instead of <br />... bagimsiz varliklari(entities) kullanmayiniz.
var $TXT_PATCH_delete_bad = "Silmek uzere oldugunuz yama su an kurulmus durumda! Eger silerseniz daha sonra uninstall edemezsiniz.\\n\\nEminmisiniz?";

var $TXT_PATCH_examine_file = "Yama icerisindeki dosyayi goruntule";
var $TXT_PATCH_file_contents = "Dosya icerikleri";

var $TXT_PATCH_upload_title = "Bir yama upload edin";
var $TXT_PATCH_upload_select = "Upload icin yama seciniz";
var $TXT_PATCH_upload = "Upload";
var $TXT_PATCH_upload_error_supports = "Yama menajeri simdilk sadece bu dosyalari destekliyor: ";
var $TXT_PATCH_upload_error_broken = "Upload etmeye calistiginiz yama gecersiz veya bozuk";
var $TXT_PATCH_uploaded_success = "Yama basari ile upload edildi";
var $TXT_PATCH_uploaded_successfully = "Yama basari ile upload edildi";

var $TXT_PATCH_modification_malformed = "Bozuk veya gecersiz modifikasyon dosyasi.";
var $TXT_PATCH_modification_missing = "Dosya bulunamadi.";
var $TXT_PATCH_no_zlib = "Uzgunuz, ama PHP konfigurasyonunuz <b>zlib</b> i desteklemiyor. Bu olmadan yama menajeri calisamaz. Lutfen bu konu hakkinda hostunuzla irtibata gecin daha genis bilgi alabilmek icin.";

var $TXT_TIP_CONFIG01_TITLE     = "vBulletin Tam Dizini";
var $TXT_TIP_CONFIG01  = "vBulletin Boardunuzun tam dizini ornegin /www/mambo/forum  izsiz \'/\'";
var $TXT_TIP_CONFIG02 = "vBulletin Boardunuzun tam dizini ornegin /www/mambo/forum izsiz \'/\' dogru degildir lutfen dogru degeri giriniz.";
var $TXT_TIP_CONFIG03_TITLE     = "vBulletin URL";
var $TXT_TIP_CONFIG03  = "vBulletin Boardunuzun URLsi ornegin http://www.domain.com/forum  izsiz \'/\'";
var $TXT_TIP_CONFIG04_TITLE     = "vBulletin Database(Veritabani) Prefix(Oneki)";
var $TXT_TIP_CONFIG04  = "vBulletin Boardunuzun veritabani oneki ornegin mos_vb_";
var $TXT_TIP_CONFIG05 = "vBulletin Boardunuzun veritabani oneki ornegin mos_vb_ dogru degil lutfen dogru degeri giriniz. Both databases must merge into the same database";
var $TXT_TIP_CONFIG06_TITLE     = "vBulletin Lisansi";
var $TXT_TIP_CONFIG06  = "Buraya vBulletin lisansinizi giriniz ornek VBF9999999. Dikkat sadece kendi lisansinizi kullanin";
var $TXT_TIP_CONFIG07_TITLE     = "vBulletin Kurabiye Oneki";
var $TXT_TIP_CONFIG07 = "vBulletin Boardunuzun Kurabiye Oneki. Varsayilan \'bb\' ve dogru olarak yakalayacaktir tam dizin ayarlanmis ise.";
var $TXT_TIP_CONFIG08 = "vBulletin Boardunuzun tam dizini ornegin /www/mambo/forum izsiz \'/\' dogru degildir lutfen dogru degeri girin. Yoksa bu deger dogru olmayacaktir.";

var $TXT_TIP_CONFIG10_TITLE     = "Entegre Opsiyonu";
var $TXT_TIP_CONFIG10 = "Bu en onemli ayarlardan biri burada vBulletin in Mambonun icindemi yoksa disinda mi olacagina karar vereceksiniz.";
var $TXT_TIP_CONFIG11_TITLE     = "Kayit Opsiyonu";
var $TXT_TIP_CONFIG11 = "Kullanicilar icin Mambo kayit sistemi mi kullanilsin yoksa vBulletin mi?";
var $TXT_TIP_CONFIG12_TITLE     = "Yonlendirme Opsiyonu";
var $TXT_TIP_CONFIG12             = "Bunu evet yaptiginiz takdirde her login oldugunuzda foruma yonlendirilirsiniz";
}
?> 