<?php
/** 
  * @Language file for vBridge, by Andrea "StaRise" Brandi
  * @Author website: http://www.starise.net
  * @copyright (C) wh-solution.com
  * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
  */

class JoomlaVBRIDGELanguage {

## MAIN COMPONENT ADMIN PAGE GEADER
##
var $HEADER_MAIN = 'Configurazione di Mambo vBulletin';

## TABS
##
var $TAB_CONFIGURATION_TITLE 		= "Configurazione";
var $TAB_REGISTRATION_TITLE 		= "Registrazione";
var $TAB_INSTALL_MANAGER_TITLE 		= "Installazione";
var $TAB_USER_MANAGER_TITLE 		= "Gestione Utenti";
var $TAB_LANGUAGE_TITLE 			= "Lingua";
var $TAB_CREDITS_TITLE 			    = "Crediti";

## CONFIGURATION TAB CONSTANTS
##
var $FIELD_VB_PATH_ABSOLUT			= "vBulletin Path Assoluta:";
var $FIELD_VB_URL_ABSOLUT			= "vBulletin URL:";
var $FIELD_VB_DB_PREFIX			    = "vBulletin Prefisso Database:";
var $FIELD_VB_COOKIE_PREFIX			= "vBulletin Prefisso Cookie:";
var $FIELD_VB_LICENSE			    = "vBulletin Num. Licenza:";
var $FIELD_MOS_DB_PREFIX			= "Mambo Prefisso Database:";
var $FIELD_INTEGRATION_OPTION 		= "Metodo di Integrazione:";
var $FIELD_REGISTRATION_OPTION 		= "Metodo di Registrazione:";
var $FIELD_EXISTING_VB				= "Esistono utenti vBulletin con dati?:";
var $FIELD_HIDE_EMAIL				= "Nascondi le emails nel profilo di vBulletin (sync):";
var $FIELD_CB_LOGIN 				= "Rimanda al profilo di vBulletin cliccando su Community Builder:";
var $FIELD_VERSION_INFO				= "Info Versione:";
var $FIELD_VB_REDIRECT				= "Rimanda al forum dopo il login:";

var $FIELD_VALUE_WRAPPED 			= "Wrapped";
var $FIELD_VALUE_UNWRAPPED 			= "Unwrapped";
var $FIELD_VALUE_VBREG   			= "Usa vBulletin";
var $FIELD_VALUE_VBUNREG 			= "Usa Mambo";

var $HEADER_CONFIG_SETTINGS		    = "CONFIGURA LE OPZIONI:";
var $HEADER_BEHAV_SETTINGS		    = "COMPORTAMENTO:";
var $HEADER_INSTALLATION_CHECKLIST	= "CONTROLLO DELL'INSTALLAZIONE:";
var $HEADER_INSTALLATION_CHECKUSER	= "SINCRONIZZA / IMPORTA UTENTI VBULLETIN:";
var $HEADER_CREDITS_DEVELOPER      	= "SVILUPPATORI:";
var $HEADER_CREDITS                 = "vBRIDGE CREDITI";
var $HEADER_CREDITS_DOCUMENTATION  	= "DOCUMENTAZIONE:";
var $HEADER_CREDITS_TRANSLATOR     	= "TRADUTTORI:";
var $HEADER_CREDITS_TESTER         	= "TESTER:";
var $HEADER_CREDITS_MISC          	= "GRAZIE A:";
var $HEADER_CONTACT_MISC          	= "ALTRE INFORMAZIONI:";

var $MSG_INSERTED					= "inserito";
var $MSG_INSTALLED					= "installato";
var $MSG_VERIFY						= "verifica";
var $MSG_IMPORT						= "Importa";
var $MSG_NOT_INSTALLED				= "non installato";
var $MSG_NOT_PUBLISHED				= "non pubblicato";
var $MSG_SYNC						= "clicca per sincronizzare";
var $MSG_PATCH						= "clicca per modificare";
var $MSG_APPLY						= "applica";
var $MSG_DONE						= "applicato";
var $MSG_INCORRECT_PREFIX			= "(prefisso non corretto)";
var $MSG_INCORRECT_PATH				= "(path non corretta)";
var $MSG_VB_VERSION_IS				= "La tua versione di vBulletin �";
var $MSG_MAMBO_VB_VERSION_IS		= "La tua versione di vBridge �";
var $MSG_LATEST_MAMBO_VB_VERSION_IS = "Ultima versione di vBridge:";
var $MSG_VB_MAMBO_IN_SYNC			= "Utenti VB e Mambo sincronizzati.";
var $MSG_VB_TEMP_IN_SYNC			= "Il template di VB � sincronizzato.";


var $MSG_MAMBO_CACHE_DIR_IS			= "Cartella cache di Mambo";
var $MSG_MAMBO_INDEX_FILE_IS		= "Index file di Mambo";
var $MSG_MAMBO_MAMBO_FILE_IS		= "File di Mambo";
var $MSG_MAMBO_PATH_IS 				= "Path principale di Mambo";

var $MSG_ERR_MAMBO_INDEX_NOT_WRITEABLE 	= "Path principale di Mambo o index.php non scrivibile!";
var $MSG_ERR_MAMBO_NOT_WRITEABLE 	    = "Path principale di Mambo o index.php del template non scrivibile!";
var $MSG_ERR_CONF_NOT_WRITEABLE 		= "File di configurazione non scrivibile!";
var $MSG_SETTINGS_SAVED 				= "Impostazioni salvate";
var $MSG_WRITABLE 						= '� scrivibile';
var $MSG_NOT_WRITABLE 					= 'non � scrivibile';
var $MSG_SUCCESS						= 'Completato';
var $MSG_FAILED							= 'Fallito';
var $MSG_CANNOT_COPY_USER_TO_MAMBO		= "Attenzione: Sei loggato in VB ma non in Mambo. Impossibile caricare utenti in Mambo.";
var $MSG_CANNOT_COPY_USER_TO_VB		    = "Attenzione: Sei loggato in Mambo ma non in VB. Impossibile caricare utenti in VB.";

var $TEXT_INSTALL_VB				= "Installa vBulletin nello stesso database di Mambo.";
var $TEXT_INSTALL_VB_MOD			= "Installa il vBridge Mod Login usando Modules Installer.";
var $TEXT_PATCH_CONFIG_FILE   		= "Modifica vBulletin includes/config.php.";
var $TEXT_PATCH_LOGIN_FILE  		= "Modifica vBulletin login.php.";
var $TEXT_PATCH_PROFILE_FILE  		= "Modifica vBulletin profile.php.";
var $TEXT_PATCH_REGISTER_FILE  		= "Modifica vBulletin register.php.";
var $TEXT_PATCH_SHOWTHREAD_FILE		= "Modifica vBulletin showthread.php.";
var $TEXT_PATCH_FUNCTION_FILE	    = "Modifica vBulletin includes/functions.php.";
var $TEXT_PATCH_ADMINUSER_FILE	    = "Modifica vBulletin admincp/user.php.";
var $TEXT_PATCH_MAMBO_FILE	        = "Modifica index.php del template corrente di Mambo:";
var $TEXT_PATCH_MAMBO_VB            = "Modifica template di vBulletin";
var $TEXT_SYNC_MAMBO_VB			    = "Sincronizza utenti di Mambo e vBulletin.";
var $TEXT_IMPORTANT					= "IMPORTANTE:";
var $TEXT_IMPORTANT_MSG				= "Deseleziona solo se stai usando questo per una nuova installazione di vBulletin!";
var $TEXT_IMPORT_USER               = "gli utenti vBulletin in Mambo. <br />NOTA: TUTTI GLI UTENTI MAMBO SARANNO CANCELLATI SOLO SE STAI USANDO UNA NUOVA INSTALLAZIONE DI MAMBO";
## COMMON FOR ALL LANGUAGES
##
var $VB_ISO 								= 'iso-8859-1';
var $VB_DATE_FORMAT_LC 					= 'A, d. B Y'; //Verwendet das PHP strftime Format
var $VB_DATE_FOMAT_SHORT 					= ' M Y'; // short date
var $VB_DATE_FORMAT_LONG 					= 'd.m.Y H:i'; // use PHP strftime Format, more info at http://php.net

## COMMON FOR VBRIDGEBOT
##
var $VB_BOT_COMMENTS				= "Commenti:";
var $VB_BOT_WRITECOMMENT			= "Scrivi commento:";
var $VB_JOINDATE        			= "Data di iscrizione:";
var $VB_POSTS           			= "Posts:";
var $COMMENT_ONLYREGISTERED         = "Solo gli utenti registrati possono scrivere commenti.<br />Ti preghiamo di loggarti o di registrarti.";

## PATCHHANDLER ##


var $TXT_VB154 = "Procedi";
var $TXT_VB160 = "Il file di modifica � stato estratto. La modifica funziona con uno script PHP che dovr� essere eseguito prima che funzioni";
var $TXT_VB161 = "Esegui";
var $TXT_VB163 = "Leggi";
var $TXT_VB173 = "Script output:";
var $TXT_VB174 = "Note addizionali";
var $TXT_VB175 = "Istruzioni/File note addizionali";
var $TXT_VB180 = "Lista files nella patch";
var $TXT_VB181 = "Files nell'archivio";
var $TXT_VB182 = "Ottieni Patch";
var $TXT_VB183 = "Server delle Patch";
var $TXT_VB184 = "Esplora";
var $TXT_VB185 = "Aggiungi server";
var $TXT_VB186 = "Nome server";
var $TXT_VB187 = "URL";
var $TXT_VB189 = "Nessuna patch.";
var $TXT_VB190 = "Download";
var $TXT_VB192 = "Patch scaricata con successo";
var $TXT_VB193 = "La Patch � stata scaricata con successo";
var $TXT_VB198 = "Patch Manager";
var $TXT_VB159b = "Applica Patch";
var $TXT_VB162b = "Il file di modifica � stato estratto. La modifica funziona con un file SQL contenente le modifiche che il database richiede.  Ti consigliamo di eseguirlo.";
var $TXT_VB163b = "Esegui";
var $TXT_VB174b = "Query SQL";
var $TXT_VB189b = "Nessuna modifica installata";
var $TXT_VB188b = "Esplora modifiche installate";
var $TXT_VB198b = "Disinstalla";
var $TXT_VB198d = "Cancella Lista Modifiche";
var $TXT_VB198h = "Spiacenti, il tuo server PHP � settato su SAFE MODE. Questa funzione non � compatibile con SAFE MODE.";
var $TXT_VB198i = "Voglio continuare comunque.";

var $TXT_PATCH1 = "Patch Manager";
var $TXT_PATCH2 = "Menu Principale";
var $TXT_PATCH3 = "Esplora Patchs";
var $TXT_PATCH4 = "Crea una Nuova Patch";
var $TXT_PATCH5 = "Scarica Nuove Patch";
var $TXT_PATCH6 = "Visualizza e Rimuovi Patch Installate";
var $TXT_PATCH7 = "Patch di Modifica";

var $TXT_PATCH10 = "Patch sconosciuta";
var $TXT_PATCH11 = "Applica Patch";

var $TXT_PATCH14 = "Lista file";
var $TXT_PATCH15 = "Rimuovi";
var $TXT_PATCH24 = "Tipo di Patch";
var $TXT_PATCH34 = "Archiviamento";
var $TXT_PATCH37 = "Estrazione";
var $TXT_PATCH39 = "Gli avatars sono stati estratti, ora puoi usarli.";
var $TXT_PATCH41 = "La nuova lingua � stata estratta, ora puoi usarla (selezionandola nei settaggi).";

var $TXT_PACMAN2 = "Nome Patch";
var $TXT_PACMAN3 = "Versione";
var $TXT_PACMAN4 = "Autore";
var $TXT_PACMAN6 = "Homepage Autore";
var $TXT_PACMAN8 = "Nessuna Descrizione";
var $TXT_PACMAN9 = "Descrizione";
var $TXT_PACMAN10 = "Locazione del file";
var $TXT_PACMAN11 = "Azione";

var $TXT_PATCH_installed_key = "Patch installate:";
var $TXT_PATCH_installed_current = "versione attuale";
var $TXT_PATCH_installed_old = "vecchie versioni";
var $TXT_PATCH_installed_warning1 = "Questa patch � gi� installata e nessun aggiornamento � stato trovato!";
var $TXT_PATCH_installed_warning2 = "Consigliamo prima di disinstallare le vecchie versioni per evitare problemi, o chiedere all'autore di creare un aggiornamento alla vecchia versione.";
var $TXT_PATCH_installed_warning3 = "Ricorda sempre di effettuare un backup dei tuoi files e del database prima di installare una nuova patch, speciamente se sono versioni beta.";
var $TXT_PATCH_installed_extract = "Estrazione della Patch";
var $TXT_PATCH_installed_done = "La Patch � stata installata correttamente.  Dovresti ora essere in grado di visualizzare la funzionalit� o la modifica che effettuava; oppure a non vedere la funzione che rimuoveva.";

var $TXT_PATCHs_latest = "Nuove Patch";
var $TXT_PATCHs_latest_fetch = "Attendere mentre vengono cercate le pi� recenti e le pi� popolari patch da www.simplemachines.org...";

var $TXT_PATCH_upgrade = "Aggiorna";
var $TXT_PATCH_install_readme = "Leggimi dell'installazione";
var $TXT_PATCH_install_type = "Tipo";
var $TXT_PATCH_install_action = "Azione";
var $TXT_PATCH_install_desc = "Descrizione";
var $TXT_PATCH42 = "Installa Azioni";
var $TXT_PATCH43 = "per archivio";
var $TXT_PATCH44 = "Installando questa Patch verranno effettuate le seguenti azioni:";
var $TXT_PATCH45 = "La Patch che cerchi di scaricare o installare � corrotta o non compatibile con questa versione di vBulletin.";
var $TXT_PATCH50 = "Crea";
var $TXT_PATCH51 = "Sposta";
var $TXT_PATCH52 = "Cancella";
var $TXT_PATCH53 = "Estrai";
var $TXT_PATCH54 = "File";
var $TXT_PATCH55 = "Albero";
var $TXT_PATCH56 = "Esegui Modifiche";
var $TXT_PATCH57 = "Esegui Codice";

var $TXT_PATCH_bytes = "bytes";

var $TXT_PATCH_action_missing = "<b style='color: red;'>File non trovato</b>";
var $TXT_PATCH_action_error = "<b style='color: red;'>Errore di analisi della modifica (Parse Error)</b>";
var $TXT_PATCH_action_failure = "<b style='color: red;'>Fallimento</b>";
var $TXT_PATCH_action_success = "<b>Successo</b>";

var $TXT_PATCH_uninstall_actions = "Disinstalla Azioni";
var $TXT_PATCH_uninstall_done = "La Patch � stata disinstallata, Dovrebbe non avere pi� effetto.";
var $TXT_PATCH_uninstall_cannot = "Questa Patch non pu� essere disinstallata, perch� non � presente lo script di disinstallazione!<br /><br />Contatta l'autore della modifica per ulteriori informazioni.";

var $TXT_PATCH_install_options = "Opzioni di Installazione";
var $TXT_PATCH_install_options_ftp_why = "Usare l'FTP � la strada pi� facile per effettuare chmod sui file e renderli scrivibili per il Patch manager.<br />Qui puoi settare le impostazioni di default per alcuni campi.";
var $TXT_PATCH_install_options_ftp_server = "Server FTP";
var $TXT_PATCH_install_options_ftp_port = "Porta";
var $TXT_PATCH_install_options_ftp_user = "Nome utente";
var $TXT_PATCH_install_options_make_backups = "Creare versioni di Backup per i file sostituiti (usare un ~ alla fine del nome).";

// For a break, use \\n instead of <br />... and don"t use entities.
var $TXT_PATCH_delete_bad = "La Patch che stai cercando di cancellare � ancora installata!  Puoi cancellarla, ma non potrai pi� Disinstallarla dopo.\\n\\nVuoi davvero continuare?";

var $TXT_PATCH_examine_file = "Vedi file nella Patch";
var $TXT_PATCH_file_contents = "Contenuto del file";

var $TXT_PATCH_upload_title = "Carica una Patch";
var $TXT_PATCH_upload_select = "Patch da Caricare";
var $TXT_PATCH_upload = "Carica";
var $TXT_PATCH_upload_error_supports = "Il Patch manager attualmente accetta solo questi tipi di file: ";
var $TXT_PATCH_upload_error_broken = "La Patch che cerchi di caricare non � valida o potrebbe essere corrotta.";
var $TXT_PATCH_uploaded_success = "Patch caricata correttamente";
var $TXT_PATCH_uploaded_successfully = "La Patch � stata caricata correttamente";

var $TXT_PATCH_modification_malformed = "Errato o non valido file di modifica.";
var $TXT_PATCH_modification_missing = "Il file non � stato trovato.";
var $TXT_PATCH_no_zlib = "Spiacenti, la tua configurazione di PHP non supporta <b>zlib</b>.  Senza questo, il Patch manager non pu� funzionare.  Contatta il tuo host per ulteriori informazioni.";

var $TXT_TIP_CONFIG01_TITLE 	= "vBulletin Path Assoluta";
var $TXT_TIP_CONFIG01  = "La Path assoluta del tuo vBulletin es. /www/mambo/forum  senza slash finale \'/\'";
var $TXT_TIP_CONFIG02  = "La Path assoluta del tuo vBulletin es. /www/mambo/forum  senza slash finale \'/\' non � corretta. Inserisci un valore corretto.";
var $TXT_TIP_CONFIG03_TITLE 	= "vBulletin URL";
var $TXT_TIP_CONFIG03  = "Indirizzo URL del tuo vBulletin es. http://www.tuosito.com/forum  senza slash finale \'/\'";
var $TXT_TIP_CONFIG04_TITLE 	= "vBulletin Prefisso Database";
var $TXT_TIP_CONFIG04  = "Il prefisso del Database di vBulletin es. vb3_";
var $TXT_TIP_CONFIG05  = "Il prefisso del Database di vBulletin es. vb3_ non � corretto. Inserisci un valore corretto. Ricorda che il database di vB deve essere lo stesso di Mambo";
var $TXT_TIP_CONFIG06_TITLE 	= "vBulletin Num. Licenza";
var $TXT_TIP_CONFIG06  = "Inserisci il numero di licenza della tua copia di vBulletin es. VBF9999999";
var $TXT_TIP_CONFIG07_TITLE 	= "vBulletin Prefisso Cookie";
var $TXT_TIP_CONFIG07  = "Il prefisso dei Cookie del tuo vBulletin. Di default � \'bb\' e sar� funzionante se la Path Assoluta � settata.";
var $TXT_TIP_CONFIG08  = "La Path assoluta del tuo vBulletin es. /www/mambo/forum  senza slash finale \'/\' non � corretta. Inserisci un valore corretto. Altrimenti questa opzione non potr� funzionare.";

var $TXT_TIP_CONFIG10_TITLE 	= "Integrazione";
var $TXT_TIP_CONFIG10 			= "Questo � - forse - uno dei settaggi pi� importanti! Devi decidere se il vBulletin sar� integrato dentro mambo (wrapped) oppure no (unwrapped).";
var $TXT_TIP_CONFIG11_TITLE 	= "Registrazione";
var $TXT_TIP_CONFIG11 			= "Questo � un altra importante opzione! Puoi decidere se usare il sistema di registrazione di vBulletin oppure quello di Mambo.";
var $TXT_TIP_CONFIG12_TITLE 	= "Redirezione";
var $TXT_TIP_CONFIG12 			= "Impostandola su SI (Yes), dopo il login, gli utenti saranno reindirizzati alla pagina principale del forum.";

}
?>