<?php /* $Id $ */

// Ensure this file is being included by a parent file.
defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');

require_once($mainframe->getPath('toolbar_html'));

switch ($task)
{
	case 'new':
	case 'edit':
		TOOLBAR_vbridge::_EDIT();
		break;
	default:
		TOOLBAR_vbridge::_DEFAULT();
	break;
}

?>