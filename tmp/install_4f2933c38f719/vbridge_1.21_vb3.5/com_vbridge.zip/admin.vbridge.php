<?php
/**
  * @version $Id: admin.vbridge.php,v 1.2 2005/10/25 19:15:47 predator Exp $ 
  * @package Joomla! vBridge 
  * @copyright (C) 2005 wh-solution.com 
  * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL 
  */

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


// get language file
if( file_exists( $mosConfig_absolute_path . '/administrator/components/com_vbridge/language/' . $mosConfig_lang . '.php' ) ) {
    include( $mosConfig_absolute_path . '/administrator/components/com_vbridge/language/' . $mosConfig_lang . '.php' );
}else{
    include( $mosConfig_absolute_path. '/administrator/components/com_vbridge/language/english.php' );
}
$mosLang = new JoomlaVBRIDGELanguage();
// end language
$task = mosGetParam( $_REQUEST,'task','' );

include_once( $mosConfig_absolute_path . '/administrator/components/com_vbridge/functions.vbridge.php' );

require_once( $mainframe->getPath( 'admin_html' ) );
require_once( $mainframe->getPath( 'class' ) );

$config = array();
$database->setQuery( "SELECT * FROM #__vbridge_config WHERE id='1'" );
$config = $database->loadObjectList();
$mosVB = new mosVB();

switch ($task) {

    case "cancel":
    showConfig($option, $config);
    break;
    case "":
    showConfig($option, $config);
    break;
    case "save":
    saveConfig ($database);
    break;
    case "apply";
    if (!insertCode()) {
        mosRedirect( "index2.php?option=$option", $mosLang->MSG_FAILED.": ".$mosLang->MSG_ERR_TEMPLATE_NOT_WRITEABLE);
    }
    mosRedirect( "index2.php?option=$option", $mosLang->MSG_SUCCESS);
    break;
    case "checksync";
    $database->setQuery("UPDATE #__vbridge_config SET check_user= 0 WHERE id ='1'");
    $database->query();
    if ($database->getErrorNum()) {
        mosRedirect("index.php?option=com_vbridge&mosmsg=".$database->getErrorMsg());
    }
    showConfig($option, $config);
    break;
    case "sync";
    $count1 = syncVBtoJoomla($config);
    $count2 = syncJoomlaToVB($config);
    //$count2 ="not ready";
    
    $database->setQuery("UPDATE #__vbridge_config SET check_user= 1 WHERE id ='1'");
    $database->query();
    if ($database->getErrorNum()) {
        mosRedirect("index.php?option=com_vbridge&mosmsg=".$database->getErrorMsg());
    }
    mosRedirect( "index2.php?option=$option", $mosLang->MSG_SUCCESS." : Mambo[".$count1."] / VB[".$count2."] ". $mosLang->MSG_INSERTED);
    break;
        
}

/**
 * Show Configuration
 *
 * @param string $option
 * @param array $config
 */
function showConfig($option, $config) {
    global $database;

    $database->setQuery( "SELECT template FROM #__templates_menu WHERE client_id='0' AND menuid='0'" );
    $cur_template = $database->loadResult();


    $configs['vb_redirect'] = mosHTML :: yesnoRadioList('vb_redirect', 'class="inputbox" size="1"', $config[0]->vb_redirect);
     $configs['vb_useextdb'] = mosHTML :: yesnoRadioList('vb_useextdb', 'class="inputbox" size="1"', $config[0]->vb_useextdb);
    vbridge_html::admin_showconfig($option, $config, $configs, $cur_template);
}

/**
 * Save the Configuration
 *
 * @param array $database
 */
function saveConfig ($database) {
    global $mosLang;

    $row = new vBridgeConfigDB($database);

    if (!$row->bind($_POST)) {
        mosRedirect( "index2.php", $row->getError() );
        //mosErrorAlert($row->getError());
    }

    if (!$row->store()) {
        mosRedirect( "index2.php", $row->getError() );
        //mosErrorAlert($row->getError());
    }

    mosRedirect( "index2.php?option=com_vbridge", $mosLang->MSG_SETTINGS_SAVED );
}


/**
 * Checks the Component Version
 *
 * @return $element
 */
function readComVersion() {
    global $mosConfig_absolute_path;
    require_once( $mosConfig_absolute_path . '/includes/domit/xml_domit_lite_include.php' );

    $thefile = $mosConfig_absolute_path . "/administrator/components/com_vbridge/vbridge.xml";

    $xmlDoc = new DOMIT_Lite_Document();
    $xmlDoc->resolveErrors( true );

    if (!$xmlDoc->loadXML( $thefile, false, true )) {
        continue;
    }
    
    $root = &$xmlDoc->documentElement;

    if ($root->getTagName() != 'mosinstall') {
        continue;
    }

    $element = &$root->getElementsByPath('version', 1); 
        
    return $element ? $element->getText() : '';
}

?>