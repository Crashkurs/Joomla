<?php
/**
* @version $Id: mod_vbridge_login.php,v 1.2 2005/10/25 10:15:23 predator Exp $
* @package Joomla! vBridge
* @copyright (C) 2005 www.wh-solution.com
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* Joomla is Free Software
*/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $database,$mosConfig_host, $mosConfig_user, $mosConfig_password, $mosConfig_db, $mosConfig_dbprefix;

$database->setQuery("SELECT id FROM #__menu WHERE link='index.php?option=com_vbridge'");
if ($database->loadResult()) {
    $Itemid = $database->loadResult();
}

$return = mosGetParam( $_SERVER, 'REQUEST_URI', null );
// converts & to &amp; for xtml compliance
$return = str_replace( '&', '&amp;', $return );

$registration_enabled 	= $mainframe->getCfg( 'allowUserRegistration' );
$message_login 			= $params->def( 'login_message', 0 );
$message_logout 		= $params->def( 'logout_message', 0 );
$pretext 	= $params->get( 'pretext' );
$posttext 	= $params->get( 'posttext' );
$login 		= $params->def( 'login', $return );
$logout 	= $params->def( 'logout', $return );
$name 		= $params->def( 'name', 1 );
$greeting 	= $params->def( 'greeting', 1 );

if ( $name ) {
	$query = "SELECT name FROM #__users WHERE id = ". $my->id;
	$database->setQuery( $query );
	$name = $database->loadResult();
} else {
	$name = $my->username;
}
$database->setQuery( "SELECT * FROM #__vbridge_config WHERE id='1'" );
$vb = null;
$database->loadObject( $vb ); 

if ( $my->id ) {
    $cookieuserid=$vb->vb_cookie."userid";	
    $vb_user = null;
    if ($vb->vb_useextdb == 1) {
		   $database2 = new database( $vb->vb_dbhost,$vb->vb_dbuser,$vb->vb_dbpass, $vb->vb_dbname, $vb->vb_prefix );
		   $database2->setQuery( "SELECT salt FROM {$vb->vb_prefix}user WHERE userid=".$_COOKIE[$cookieuserid]."" );
    	   $database2->loadObject( $vb_user );
	} else {
		   $database->setQuery( "SELECT salt FROM {$vb->vb_prefix}user WHERE userid=".$_COOKIE[$cookieuserid]."" );
		   $database->loadObject( $vb_user );
	}
    $logouthash = md5($_COOKIE[$cookieuserid] . $vb_user->salt . $vb->vb_license);
    ?>
    
	<form action="<?php echo sefRelToAbs( $vb->vb_url."/login.php?do=logout&logouthash=$logouthash&u=$_COOKIE[$cookieuserid]&lang=$mosConfig_lang&return=" . sefRelToAbs( $logout ) . "&message=$message_logout" ); ?>" method="post" name="login" > 
	<?php
	if ( $greeting ) {
		echo _HI;
		echo $name;
	}
	?>
	<br />
	<div align="center">
	<input type="submit" name="Submit" class="button" value="<?php echo _BUTTON_LOGOUT; ?>" />
	</div>

	<input type="hidden" name="op2" value="logout" />
	<input type="hidden" name="lang" value="<?php echo $mosConfig_lang; ?>" />
	<input type="hidden" name="return" value="<?php echo sefRelToAbs( $logout ); ?>" />
	<input type="hidden" name="message" value="<?php echo $message_logout; ?>" />
	</form>
	<?php
} else {
    if ($vb->cb_login ) {
	?>
	<form action="<?php echo sefRelToAbs("index.php?option=com_comprofiler&amp;task=login"); ?>" method="post" name="login">
	<?php
	} else {    
	?>
	<form action="<?php echo sefRelToAbs( 'index.php' ); ?>" method="post" name="login" >
	<?php
	}
	echo $pretext;
	?>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
	<tr>
		<td>
		<?php echo _USERNAME; ?>
		<br />
		<input name="username" type="text" class="inputbox" alt="username" size="10" />
		<br />
		<?php echo _PASSWORD; ?>
		<br />
		<input type="password" name="passwd" class="inputbox" size="10" alt="password" />
		<br />
		<input type="checkbox" name="remember" class="inputbox" value="yes" alt="Remember Me" /> 
		<?php echo _REMEMBER_ME; ?>
		<br />
		<input type="hidden" name="option" value="login" />
		<input type="submit" name="Submit" class="button" value="<?php echo _BUTTON_LOGIN; ?>" />
		</td>
	</tr>
	<tr>
	<?php 
	    if ($vb->cb_login ) {
		?>
	    <td>
		<a href="<?php echo sefRelToAbs( 'index.php?option=com_comprofiler&amp;task=lostPassword' ); ?>">
		<?php echo _LOST_PASSWORD; ?>
		</a>
		</td>
		<?php
	        
	    } else {    
		?>
		<td>
		<a href="<?php echo sefRelToAbs( 'index.php?option=com_registration&amp;task=lostPassword' ); ?>">
		<?php echo _LOST_PASSWORD; ?>
		</a>
		</td>
		<?php
	    }
	?>
	</tr>
	<?php
	if ( $registration_enabled ) {
	    if ($vb->cb_login ) {
	    ?>
		<tr>
			<td>
			<?php echo _NO_ACCOUNT; ?>
			<a href="<?php echo sefRelToAbs( 'index.php?option=com_comprofiler&amp;task=registers' ); ?>">
			<?php echo _CREATE_ACCOUNT; ?>
			</a>
			</td>
		</tr>
		<?php
	        
	    } else {  
	        if ($vb->vb_reg == 1) {
	         ?>
		<tr>
			<td>
			<?php echo _NO_ACCOUNT; ?>
			<a href="<?php echo sefRelToAbs( 'index.php?option=com_registration&amp;task=register' ); ?>">
			<?php echo _CREATE_ACCOUNT; ?>
			</a>
			</td>
		</tr>
		<?php   
	            
	        } else {  
		?>
		<tr>
			<td>
			<?php echo _NO_ACCOUNT; ?>
			<a href="<?php echo sefRelToAbs( "index.php?option=com_vbridge&amp;Itemid=$Itemid&amp;file=register.php"); ?>">
			<?php echo _CREATE_ACCOUNT; ?>
			</a>
			</td>
		</tr>
		<?php
	    }
	}
	}
	?>
	</table>
	<?php
	echo $posttext;
	?>
	
	<input type="hidden" name="op2" value="login" />
	<input type="hidden" name="lang" value="<?php echo $mosConfig_lang; ?>" />
	<input type="hidden" name="return" value="<?php echo sefRelToAbs( $login ); ?>" />
	<input type="hidden" name="message" value="<?php echo $message_login; ?>" />
	</form>
	<?php
}
?>