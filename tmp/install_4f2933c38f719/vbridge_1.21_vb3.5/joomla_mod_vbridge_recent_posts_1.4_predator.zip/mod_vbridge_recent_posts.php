<?php
/**
* @version $Id: mod_vbridge_recent_posts.php,v 1.4 2005/10/25 10:15:23 predator Exp $
* @package Joomla! vBridge
* @copyright www.wh-solution.com
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* Joomla is Free Software
*/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

global $Itemid, $mosConfig_sef, $mosConfig_host, $mosConfig_user, $mosConfig_password, $mosConfig_db, $mosConfig_dbprefix;

$moduleclass_sfx = $params->get( 'moduleclass_sfx' );

$use_database = ($params->get( 'use_database' )=="" ? 0 : $params->get( 'use_database' ));
$db_host = $params->get( 'db_host' );
$db_dbname = $params->get( 'db_dbname' );
$db_user = $params->get( 'db_user' );
$db_passwd = $params->get( 'db_passwd' );
$db_prefix = $params->get( 'db_prefix' );
$limit = ($params->get( 'limit' )=="" ? 5 : $params->get( 'limit' ));
$numchar = $params->get( 'numchar' );
$show_thread = ($params->get( 'show_thread' )=="" ? 1 : $params->get( 'show_thread' ));
$show_author = ($params->get( 'show_author' )=="" ? 1 : $params->get( 'show_author' ));
$show_views = ($params->get( 'show_views' )=="" ? 1 : $params->get( 'show_views' ));
$show_posts = ($params->get( 'show_posts' )=="" ? 1 : $params->get( 'show_posts' ));
$show_lastposts = ($params->get( 'show_lastposts' )=="" ? 1 : $params->get( 'show_lastposts' ));
$datetime = ($params->get( 'datetime' )=="" ? 1 : $params->get( 'datetime' ));
$use_vbridge = ($params->get( 'use_vbridge' )=="" ? 1 : $params->get( 'use_vbridge' ));
$vb_url = $params->get( 'vb_url' );
$boardstoshow = $params->get( 'boardstoshow' );

if ($limit == '') {
    die ('Please go to Joomla!-vBulletin Recent Topics module and click save to initialize parameters.');
}
$allowed_forums = explode(',', $boardstoshow);
$allowedforums = array_slice($allowed_forums, 0, 25);

$database->setQuery("SELECT id FROM #__menu WHERE link='index.php?option=com_vbridge' AND published='1'");
if ($database->loadResult()) {
    $Itemid = $database->loadResult();
}

$scripturl = $mosConfig_live_site."/index.php?option=com_vbridge&Itemid=".$Itemid;

$exclude_boards = array();
$output_method = 'echo';

$content ="";

if ($use_database == 1 ) {

    $database2 = new database( $db_host,$db_user,$db_passwd, $db_dbname, $db_prefix );

    $database2->setQuery("SELECT a. * , b.threadid"
    . "\n FROM {$db_prefix}post AS a, "
    . "\n {$db_prefix}thread AS b WHERE a.threadid = b.threadid"
    . "\n AND b.open = 1"
    . "\n AND b.visible = 1"
    . "\n AND a.dateline = b.lastpost"
    . "\n AND b.forumid IN (" . implode(',', $allowedforums) . ")"
    . "\n ORDER  BY a.dateline DESC ");
    $meslist = $database2->loadObjectList();


} else {
    $database->setQuery("SELECT a. * , b.threadid"
    . "\n FROM {$db_prefix}post AS a, "
    . "\n {$db_prefix}thread AS b WHERE a.threadid = b.threadid"
    . "\n AND b.open = 1"
    . "\n AND b.visible = 1"
    . "\n AND a.dateline = b.lastpost"
    . "\n AND b.forumid IN (" . implode(',', $allowedforums) . ")"
    . "\n ORDER  BY a.dateline DESC ");
    $meslist = $database->loadObjectList();
}

$enum=1;
$content .="<table cellpadding=\"1\" border=\"0\" width=\"100%\">";
$content .="<tr>";
if ($show_thread == 1) $content .="<td class=\"sectiontableheader\"><b>Thread</b></td>";
if ($show_author == 1) $content .="<td class=\"sectiontableheader\"><b>Author</b></td>";
if ($show_views == 1) $content .="<td class=\"sectiontableheader\"><b>Views</b></td>";
if ($show_posts == 1) $content .="<td class=\"sectiontableheader\"><b>Posts</b></td>";
if ($show_lastposts == 1) $content .="<td class=\"sectiontableheader\"><b>Last Post</b></td>";
$content .="</tr>";

foreach ($meslist as $mes){
    $thread=null;
    $forum=null;

    if ($enum != $limit) {

        if ($use_database == 1 ) {
            $database2->setQuery("SELECT * FROM {$db_prefix}thread WHERE threadid = '$mes->threadid'");
            $database2->loadObject( $thread );
            $database2->setQuery("SELECT * FROM {$db_prefix}forum WHERE forumid = '$thread->forumid'");
            $database2->loadObject( $forum );

        } else {

            $database->setQuery("SELECT * FROM {$db_prefix}thread WHERE threadid = '$mes->threadid'");
            $database->loadObject( $thread );
            $database->setQuery("SELECT * FROM {$db_prefix}forum WHERE forumid = '$thread->forumid'");
            $database->loadObject( $forum );
        }


        $threadtitle =$numchar != '' ? substr($thread->title,0,$numchar).(strlen($thread->title) > $numchar ? '...' : '') : $thread->title;
        $lasttitle =$numchar != '' ? substr($mes->title,0,$numchar).(strlen($mes->title) > $numchar ? '...' : '') : $mes->title;

        $content .="<tr>";

        if ($use_vbridge == 1 && $use_vbridge != '') {

            if ($show_thread == 1) $content .='<td><a href="'.sefRelToAbs($scripturl . '&file=showthread.php&amp;t='.$mes->threadid).'">'.$threadtitle.'</a><br />in: <a href="'.sefRelToAbs($scripturl . '&file=forumdisplay.php&amp;f='.$forum->forumid).'">'.$forum->title.'</a></td>';
            if ($show_author == 1) $content .='<td><a href="'.sefRelToAbs($scripturl . '&file=member.php&amp;u='.$thread->postuserid).'">'.$thread->postusername.'</a></td>';
            if ($show_views == 1) $content .='<td align=\"center\">'.$thread->views.'</td>';
            if ($show_posts == 1) $content .='<td align=\"center\">'.$thread->replycount.'</td>';
            if ($show_lastposts == 1) $content .='<td><a href="'.sefRelToAbs($scripturl . '&file=showthread.php&amp;goto=newpost&amp;t='.$mes->threadid).'">'. $lasttitle .'</a><br /> by '.$thread->lastposter.'';

        }else {
            if ($show_thread == 1) $content .='<td><a href="'.$vb_url . '/showthread.php?t='.$mes->threadid.'">'.$threadtitle.'</a><br />in: <a href="'.$vb_url . '/forumdisplay.php?f='.$forum->forumid.'">'.$forum->title.'</a></td>';
            if ($show_author == 1) $content .='<td><a href="'.$vb_url . '/member.php?u='.$thread->postuserid.'">'.$thread->postusername.'</a></td>';
            if ($show_views == 1) $content .='<td align=\"center\">'.$thread->views.'</td>';
            if ($show_posts == 1) $content .='<td align=\"center\">'.$thread->replycount.'</td>';
            if ($show_lastposts == 1) $content .='<td><a href="'.$vb_url . '/showthread.php?goto=newpost&amp;t='.$mes->threadid.'">'. $lasttitle .'</a><br /> by '.$thread->lastposter.'';
        }

        if ($datetime == 1 && $datetime != '') {
            $content .='<br /> at '.date('d.m.Y H:i', $thread->dateline).'';
        }
        $content .='</td>';

        $content .="</tr>";
        $enum++;
    }
}
$content .="</table>";
if ($use_vbridge) {
    $content .='<a href="'.sefRelToAbs($scripturl).'">Visit Forum</a>';
} else {
    $content .='<a href="'.$vb_url.'">Visit Forum</a>';
}

if ($use_database == 1 ) {
    $database = new database( $mosConfig_host, $mosConfig_user, $mosConfig_password, $mosConfig_db, $mosConfig_dbprefix );

}
?>