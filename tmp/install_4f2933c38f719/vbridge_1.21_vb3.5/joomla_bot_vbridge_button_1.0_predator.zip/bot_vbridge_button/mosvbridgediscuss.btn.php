<?php
/**
* @version $Id: mosvbridgediscuss.btn.php,v 1.0 2005/10/25 10:12:23 predator Exp $
* @package Joomla! vBridge
* @copyright (C) 2005 WH-Solution.com
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* Joomla! is Free Software
* Based on mic`s mossmfdiscuss.btn.php
*/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

$_MAMBOTS->registerFunction( 'onCustomEditorButton', 'botMosvBridgeDiscussButton' );

/**
* dicussion button
* @return array A two element array of ( imageName, textToInsert )
*/
function botMosvBridgeDiscussButton() {
	global $mosConfig_live_site;
	return array( 'mosvbridgediscuss.gif', '{mos_vbridge_discuss}' );
}
?>